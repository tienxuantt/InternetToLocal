
$(".content-item").on("click", function(){
  let action = $(this).attr("action");

  sendDataToClient(action);
});

// /////////////////////////////////////////////
function sendDataToClient_detail(data){
  sendDataToClient_inject(data);
}
function sendDataToClient(action){
  sendDataToWeb({action: action}, sendDataToClient_detail);
}

// chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
//     if (message == 'create_pam') {
//       setTimeout(function () {
//         sendDataToWeb({action: "edit_PAM"}, sendDataToClient_detail)
//       }, 5000);
//     } 
// });

