﻿-- Cập nhật chứng từ cuối vào tài sản                                     
UPDATE fixed_asset fa
INNER JOIN
( SELECT *
    FROM
    (
      SELECT fal1.fixed_asset_id, fal1.remaining_amount, fal1.orgprice,
      fal1.accum_depreciation_amount, fal1.depreciation_amount, fal1.depreciation_for_business_amount,
      ROW_NUMBER() OVER(PARTITION BY fal1.fixed_asset_id ORDER BY fal1.change_date DESC, fal1.created_date DESC) AS Rownum
      FROM fixed_asset_ledger fal1
      WHERE fal1.voucher_type <> 17
    ) G WHERE G.Rownum = 1
) T ON fa.fixed_asset_id = T.fixed_asset_id
SET fa.orgprice = T.orgprice,
    fa.accum_depreciation_amount = T.accum_depreciation_amount,
    fa.depreciation_amount = IF(fa.fixed_asset_type = 1, T.accum_depreciation_amount, if(fa.fixed_asset_type  = 2, 0, T.depreciation_amount)), 
    fa.depreciation_for_business_amount = IF(fa.fixed_asset_type = 1, 0, if(fa.fixed_asset_type  = 2, T.accum_depreciation_amount, T.depreciation_for_business_amount)),
    fa.remaining_amount = T.remaining_amount
WHERE 
fa.orgprice <> T.orgprice
OR  fa.accum_depreciation_amount <> T.accum_depreciation_amount
OR  fa.depreciation_amount <> IF(fa.fixed_asset_type = 1, T.accum_depreciation_amount, if(fa.fixed_asset_type  = 2, 0, T.depreciation_amount))
OR  fa.depreciation_for_business_amount <> IF(fa.fixed_asset_type = 1, 0, if(fa.fixed_asset_type  = 2, T.accum_depreciation_amount, T.depreciation_for_business_amount))
OR  fa.remaining_amount <> T.remaining_amount;
                                                                                                                                                                                                               
SELECT fa.fixed_asset_code, do.organization_code 
FROM 
(
    SELECT lb.*
    FROM ledger_budget lb INNER JOIN
      (
        SELECT * FROM
        (
          SELECT l.fixed_asset_id, IFNULL(l.voucher_id, '') AS voucher_id,
          ROW_NUMBER() OVER(PARTITION BY fixed_asset_id ORDER BY change_date DESC, created_date DESC) AS STT
          FROM ledger_budget l
          WHERE IFNULL(voucher_type, 1) IN (1,2,8)
        ) A WHERE A.STT = 1
      ) A2 ON lb.fixed_asset_id = A2.fixed_asset_id AND IFNULL(lb.voucher_id, '') = A2.voucher_id
) K1 INNER JOIN fixed_asset fa ON K1.fixed_asset_id = fa.fixed_asset_id
INNER JOIN dic_organization do ON K1.organization_id = do.organization_id
WHERE IFNULL(fa.orgprice, 0) > 0 AND IFNULL(K1.amount, 0) = 0
GROUP BY fa.fixed_asset_code, do.organization_code;

INSERT fa_jira_execute (organization_id, fixed_asset_id)
SELECT do.organization_id, fa.fixed_asset_id
FROM tbOrganizationLedgerHM A 
INNER JOIN dic_organization do on A.organization_id = do.organization_id
INNER JOIN fixed_asset fa ON A.organization_id = fa.organization_id and A.fixed_asset_id = fa.fixed_asset_id
GROUP BY do.organization_id, fa.fixed_asset_id;
                               
SELECT DATE_FORMAT('2022-10-19','%Y-%m-%d 23:59:59');
UPDATE fa_ledger_inventory fli set fli.change_date =  DATE_FORMAT(fli.change_date,'%Y-%m-%d 23:59:59') ;

-- Đánh lại các thông tin
DROP TEMPORARY TABLE IF EXISTS tbOrganizationFA;
CREATE TEMPORARY TABLE tbOrganizationFA
SELECT organization_id, fixed_asset_id 
FROM tbOrganizationLedgerHM
GROUP BY organization_id, fixed_asset_id;

DROP TEMPORARY TABLE IF EXISTS Temp_Jira_ReCallUpdateFAData;
CREATE TEMPORARY TABLE Temp_Jira_ReCallUpdateFAData
SELECT do.organization_code, fa.fixed_asset_code, fal.orgprice, fal.accum_depreciation_amount
FROM tbOrganizationFA A
INNER JOIN fixed_asset fa on A.organization_id = fa.organization_id and A.fixed_asset_id = fa.fixed_asset_id
INNER JOIN dic_organization do on A.organization_id = do.organization_id
INNER JOIN fixed_asset_ledger fal ON fal.voucher_type IN (1,8) AND fal.organization_id = do.organization_id AND A.fixed_asset_id = fal.fixed_asset_id;
   
CALL Proc_Jira_ReCallUpdateFAData('368529d4-17d2-4ce4-98d3-4181866f94a6');
CALL Proc_Jira_Backup_ChangeDate_Voucher('368529d4-17d2-4ce4-98d3-4181866f94a6','ae92cbd2-ec84-4049-b110-fff958f606b6', 1);
CALL Proc_Jira_Update_Depreciation_FixedAsset_From_GT('1041701','PH 1999',156424000,142345840);
CALL Proc_Jira_Update_Depreciation_FixedAsset_From_GT_ALL();
CALL Proc_Jira_GetScriptRevaluationByOrgan('1052623');
CALL Proc_Jira_Update_Revaluation_Orgprice('368529d4-17d2-4ce4-98d3-4181866f94a6');
CALL Proc_Jira_Update_Revaluation_OrgpriceByOrgan('368529d4-17d2-4ce4-98d3-4181866f94a6');
CALL Proc_Jira_UpdateRemoveHM_KS(null);
CALL Proc_Jira_UpdateCustomOrgan(10);
CALL Proc_Jira_UpdateRemoveHM_Wrapper(10);
CALL Proc_Jira_RemoveHMDuplicateLedger();
CALL Proc_Jira_KS_FARevaluationDiffLedger();

SELECT * FROM fa_jira_execute fje;
SELECT * FROM jira_asset_change_date jacd;
SELECT * FROM jira_fixed_asset_error jfae;
SELECT * FROM jira_fixed_asset_survey jfas;
SELECT * FROM dic_jira_fa_caculate djfc;

DELETE FROM license_info WHERE budget_code = '1013970';
INSERT INTO license_info ( order_descriptor, lastest_update_date, budget_code, account_object_name, account_object_address, subscriber_status, expired_license_status, created_date, created_by, modified_date, modified_by, is_data_convert, buy_new_or_upgrade) VALUES
('<OrderDescriptor>\r\n<ProductPackCode>QLTS.ORG</ProductPackCode>\r\n<Internal_Log>AMIS_SUMAN_Func_RefineProductPackCodeForSubscriber</Internal_Log>\r\n<StartDate>02/01/2023</StartDate>\r\n<Duration>12</Duration>\r\n<ExpiredDate>01/10/2023</ExpiredDate>\r\n<ApplicationURL>danang.qlts.vn</ApplicationURL>\r\n</OrderDescriptor>', 
'2023-11-07 16:23:16',
 '1013970',
 '', 1, NULL, '2023-06-06 15:00:59', NULL, NULL, NULL, NULL, 2);

update license_info li set li.order_descriptor = '<OrderDescriptor> <ProductPackCode>QLTS.ORG</ProductPackCode> <Internal_Log>AMIS_SUMAN_Func_RefineProductPackCodeForSubscriber</Internal_Log> <StartDate>01/01/2023</StartDate> <Duration>12</Duration> <ExpiredDate>30/09/2023</ExpiredDate> <ApplicationURL>phuyen.qlts.vn</ApplicationURL> </OrderDescriptor>'
WHERE li.budget_code = '1013970';

SELECT CONCAT("CALL Proc_Jira_Update_Depreciation_FixedAsset_From_GT('",do.organization_code,"','",fa.fixed_asset_code,"',",fal.orgprice,",",fal.accum_depreciation_amount,");") as script
FROM fixed_asset fa 
INNER JOIN fixed_asset_ledger fal on fa.organization_id = fal.organization_id AND fa.fixed_asset_id = fal.fixed_asset_id AND fal.voucher_type IN (1,8)
INNER JOIN dic_organization do on fa.organization_id = do.organization_id
WHERE fa.fixed_asset_id =  '0f32818b-5c89-4554-b991-78a39099ff95';

SELECT CONCAT("CALL Proc_Jira_Update_Depreciation_FixedAsset_From_GT_ALL('",do.organization_code,"','",fa.fixed_asset_code,"',",fal.orgprice,",",fal.depreciation_amount,",'",fal.depreciation_for_business_amount,"');") as script
FROM fixed_asset fa 
INNER JOIN fixed_asset_ledger fal on fa.organization_id = fal.organization_id AND fa.fixed_asset_id = fal.fixed_asset_id AND fal.voucher_type IN (1,8)
INNER JOIN dic_organization do on fa.organization_id = do.organization_id
WHERE fa.fixed_asset_id =  '086d6325-a953-4b87-9b14-478dbedbee0f';

SELECT concat("CALL Proc_Jira_ReCallUpdateFAData('",fal.organization_id,"');") as Data 
FROM fixed_asset_ledger fal
WHERE  fal.remaining_amount < 0 
GROUP BY fal.organization_id;

SELECT CONCAT("CALL Proc_Jira_Backup_ChangeDate_Voucher('",fal.voucher_id,"','",fal.fixed_asset_id,"', 1);") as script
FROM fixed_asset_ledger fal 
WHERE fal.remaining_amount < 0 AND fal.fixed_asset_id =  '1d225cd4-63e8-41ac-b219-2fbc0989ff95';

CALL Proc_Jira_Backup_ChangeDate_Voucher('111','222', 1);

SELECT concat("CALL Proc_Jira_ReCallUpdateFAData('",fal.fixed_asset_id,"');") as Data 
FROM fixed_asset fal
WHERE  fal.orgprice <> fal.accum_depreciation_amount + fal.remaining_amount  AND fal.organization_id = '3bf7e0d2-ee91-442d-a4eb-7c28443539cd'
GROUP BY fal.fixed_asset_id;

SELECT concat("Call Proc_Jira_Update_Revaluation_OrgpriceByFA('",a.voucher_id,"','",a.fixed_asset_id,"');") AS Data
FROM jira_fa_focus a 
ORDER BY a.fixed_asset_id;

CALL Proc_Jira_Update_HM_Value_FA('9acd2035-291d-42ba-9dc2-e839bc506149',46800000);

SELECT fal.fixed_asset_id FROM fixed_asset_ledger fal WHERE fal.depreciation_value < 0 AND fal.remaining_amount > 0 and fal.voucher_type = 5;

UPDATE equipment_ledger el fli set fli.change_date =  DATE_FORMAT(fli.change_date,'%Y-%m-%d 23:59:59') ;

UPDATE equipment_ledger_inventory eli
set eli.created_date = DATE_FORMAT(eli.created_date,'%Y-%m-%d 11:46:00')
WHERE eli.voucher_id = 'd51da295-ec12-4552-a01a-67d8e85d722f' AND eli.equipment_id = '5954aadc-50a2-4ba3-a54c-397c012b050b';

SELECT do.organization_code, el.equipment_id, el.equipment_code, el.change_date, el.created_date, eli.change_date as change2, eli.created_date created2 
FROM equipment_ledger el
INNER JOIN dic_organization do ON el.organization_id = do.organization_id
INNER JOIN equipment_ledger_inventory eli
ON el.organization_id = eli.organization_id AND el.equipment_id = eli.equipment_id
WHERE el.voucher_type = 2 AND DATE(el.change_date) = DATE(eli.change_date) AND el.created_date < eli.created_date
ORDER BY do.organization_code;

SELECT * FROM fixed_asset_revaluation far WHERE far.fixed_asset_id = '18158720-f934-47ac-b306-bd775118e42e';

SELECT * FROM convert_circular_history cch WHERE cch.fixed_asset_id = '58a8a922-5bfb-4308-9f89-0479301898f0';

CALL Proc_Jira_ReCallUpdateFAData('');

SELECT DATABASE(), SUM(A.Total), COUNT(*) AS organ
FROM 
(
    SELECT count(*) as Total, fa.organization_id FROM fixed_asset fa GROUP BY fa.organization_id 
) A; 

CALL Proc_JIRA_C03_CCTT_Category_FindDifference_NotInNextYear (timestamp('2022-01-01 00:00:00'), timestamp('2022-12-31 00:00:00'), timestamp('2023-01-01 00:00:00'), timestamp('2023-12-31 00:00:00'), '1075309', 1, 0, 1, '', '', 0, 0);

CALL Proc_JIRA_Accounting_C03_CCTT_Category_FindDifference_ByTime (timestamp('2022-01-01 00:00:00'), timestamp('2022-12-31 00:00:00'), timestamp('2023-01-01 00:00:00'), timestamp('2023-12-31 00:00:00'), '1075309', 1, 0, 1, '', '', 0, 0);

-- 1029131

SELECT * FROM user WHERE organization_code = '1029131';

UPDATE user u set u.organization_code = '1029131.100' WHERE id = 291558;

SELECT * FROM convert_circular cc;

SELECT * FROM user u WHERE u.organization_code = '1026817';

SELECT fa.depreciation_amount, fa.accum_depreciation_amount, fa.fixed_asset_code, fa.fixed_asset_name
 FROM fixed_asset fa WHERE  fa.organization_id = '083ebec8-b863-43c3-a671-47c3f368574e' AND fa.group_fixed_asset_category_id = 1 AND fa.depreciation_amount > 0 AND fa.software_start_time >= 2023;

UPDATE fixed_asset fa
set fa.depreciation_amount = 1605600000, fa.accum_depreciation_amount = 1605600000
WHERE fa.fixed_asset_id = '6a0fbf72-3527-44d8-ae39-2ca51a013add';

UPDATE fixed_asset_revaluation far
SET fixed_asset_revaluation_list = 
JSON_SET(
JSON_SET(
JSON_SET(
JSON_SET(
JSON_SET(
JSON_SET(
fixed_asset_revaluation_list, '$[0].new_data[0].depreciation_amount', 0
), '$[0].new_data[0].accum_depreciation_amount', 0
), '$[0].old_data[0].depreciation_amount', 0
), '$[0].old_data[0].accum_depreciation_amount', 0
), '$[0].change_data[0].accum_depreciation_amount', 0
), '$[0].change_data[0].depreciation_amount', 0
) WHERE far.fixed_asset_id = '6a0fbf72-3527-44d8-ae39-2ca51a013add';

UPDATE fixed_asset_ledger fal
set fal.depreciation_amount = 0, fal.accum_depreciation_amount = 0
WHERE fal.fixed_asset_id = '6a0fbf72-3527-44d8-ae39-2ca51a013add' and fal.voucher_type IN (1,8,2);

CALL Proc_Jira_ReCallUpdateFAData('6a0fbf72-3527-44d8-ae39-2ca51a013add');

SELECT A.fixed_asset_id
FROM 
(
    SELECT fal.fixed_asset_id, fal.public_asset_type
    FROM fixed_asset_ledger fal 
    WHERE fal.organization_id = '661c3828-7671-402c-91cb-ffeda69d33c2'
) A INNER JOIN
(
    SELECT fal.fixed_asset_id, fal.public_asset_type
    FROM fixed_asset_ledger fal 
    WHERE fal.organization_id = '661c3828-7671-402c-91cb-ffeda69d33c2'
) B ON A.fixed_asset_id = B.fixed_asset_id AND A.public_asset_type <> B.public_asset_type
group by A.fixed_asset_id;
                         

SELECT * FROM 
(
SELECT fal.fixed_asset_id, fal.fixed_asset_code, fal.public_asset_type, 0 AS voucher_type, '' AS voucher_code, '2050-01-01' AS change_date 
FROM fixed_asset fal
INNER JOIN
(
         SELECT A.fixed_asset_id
        FROM 
        (
            SELECT fal.fixed_asset_id, fal.public_asset_type
            FROM fixed_asset_ledger fal 
            WHERE fal.organization_id = '661c3828-7671-402c-91cb-ffeda69d33c2'
        ) A INNER JOIN
        (
            SELECT fal.fixed_asset_id, fal.public_asset_type
            FROM fixed_asset_ledger fal 
            WHERE fal.organization_id = '661c3828-7671-402c-91cb-ffeda69d33c2'
        ) B ON A.fixed_asset_id = B.fixed_asset_id AND A.public_asset_type <> B.public_asset_type
        group by A.fixed_asset_id
) K1 ON fal.fixed_asset_id = K1.fixed_asset_id
UNION all
SELECT fal.fixed_asset_id, fal.fixed_asset_code, fal.public_asset_type, fal.voucher_type, fal.voucher_code, fal.change_date 
FROM fixed_asset_ledger fal
INNER JOIN
(
         SELECT A.fixed_asset_id
        FROM 
        (
            SELECT fal.fixed_asset_id, fal.public_asset_type
            FROM fixed_asset_ledger fal 
            WHERE fal.organization_id = '661c3828-7671-402c-91cb-ffeda69d33c2'
        ) A INNER JOIN
        (
            SELECT fal.fixed_asset_id, fal.public_asset_type
            FROM fixed_asset_ledger fal 
            WHERE fal.organization_id = '661c3828-7671-402c-91cb-ffeda69d33c2'
        ) B ON A.fixed_asset_id = B.fixed_asset_id AND A.public_asset_type <> B.public_asset_type
        group by A.fixed_asset_id
) K2 ON fal.fixed_asset_id = K2.fixed_asset_id
) B 
ORDER BY B.fixed_asset_id,  B.change_date DESC;

SELECT * FROM convert_circular_history cch WHERE cch.fixed_asset_id = 'c5eb2913-e4fd-4d27-a75a-c4b7dbc4a57a';

UPDATE fixed_asset_ledger eli
set eli.change_date = DATE_FORMAT(eli.change_date,'%Y-%m-%d 16:00:00')
WHERE eli.voucher_id = 'fe1a3ee7-7fae-4e03-bbfb-ddca656eb7db' AND eli.fixed_asset_id = 'bbbbc0c1-8606-41b3-bbb4-e488c09bf175';

SELECT * FROM synchronization_log_report slr WHERE slr.synchronization_status <> 3 AND IFNULL(slr.is_exception,0) = 0 AND TIMESTAMPDIFF(MINUTE, slr.created_date, NOW()) > 60;

SELECT concat("CALL Proc_Jira_UpdateCCDC_NTHIEP('",fal.organization_id,"');") as Data 
FROM equipment  fal
GROUP BY fal.organization_id;

SELECT concat("CALL Proc_Jira_ReCallUpdateFAData('",fa.fixed_asset_id,"');") as Data 
FROM fixed_asset fa 
WHERE fa.orgprice = fa.remaining_amount AND fa.accum_depreciation_amount > 0 AND fa.organization_id = 'e826f769-af3e-4b83-9b89-776a3e16ea30'
GROUP BY fa.fixed_asset_id;

UPDATE fixed_asset_increment fai set fai.total_orgprice = 727003000  WHERE fai.voucher_id = 'f0f3130c-7b46-4f48-92ed-131a6a9d98d2';

SELECT * FROM fixed_asset fa WHERE YEAR(fa.purchase_date) < 2023 AND YEAR(fa.used_date) < 2023 AND YEAR(fa.increment_date) = 2023 AND fa.software_start_time = 2023;

SELECT concat("CALL Proc_Jira_UpdateDifferenceRemainingAmountLand_NTHIEP('",fal.organization_id,"');") as Data 
FROM fixed_asset  fal
GROUP BY fal.organization_id;

SELECT fa.fixed_asset_id 
FROM fixed_asset fa WHERE IFNULL(fa.fixed_asset_name,'') = '';


UPDATE fixed_asset fa
INNER JOIN dic_fixed_asset_category dfac ON fa.convert_circular_id = dfac.convert_circular_id AND fa.fixed_asset_category_id = dfac.fixed_asset_category_id
set fa.fixed_asset_name = dfac.fixed_asset_category_name
WHERE IFNULL(fa.fixed_asset_name, '') = '';

UPDATE fixed_asset_ledger fal
INNER JOIN fixed_asset fa ON fal.organization_id = fa.organization_id AND fal.fixed_asset_id = fa.fixed_asset_id
set fal.fixed_asset_name = fa.fixed_asset_name
WHERE IFNULL(fal.fixed_asset_name, '') = '';

UPDATE fa_ledger_inventory fal
INNER JOIN fixed_asset fa ON fal.organization_id = fa.organization_id AND fal.fixed_asset_id = fa.fixed_asset_id
set fal.fixed_asset_name = fa.fixed_asset_name
WHERE IFNULL(fal.fixed_asset_name, '') = '';

SHOW CREATE PROCEDURE Proc_Jira_Update_OrgpriceOther_ByOrgan2      ;

SELECT concat("SELECT fixed_asset_name, fixed_asset_code, fixed_asset_id FROM fixed_asset limit 3 ;","") as Data 
FROM fixed_asset  fal
LIMIT 3;;

SELECT CONCAT("UPDATE fixed_asset_ledger fal INNER JOIN fixed_asset fa ON fal.fixed_asset_id = fa.fixed_asset_id set fal.status_id = fa.status_id WHERE fal.status_id <> fa.status_id AND fal.organization_id = '",fa.organization_id,"';") as Data
FROM fixed_asset fa
GROUP BY fa.organization_id;

UPDATE fixed_asset_revaluation fal
SET fal.fixed_asset_revaluation_list = JSON_SET(fal.fixed_asset_revaluation_list,
 '$[0].new_data[0].depreciation_amount', 0,
 '$[0].new_data[0].accum_depreciation_amount', 0
 )
WHERE fal.voucher_id in( '44805bfa-3fbd-4790-a1c5-b8bdce6a02a8');

CALL Proc_Jira_ReCallUpdateFAData('5819f8ca-3ceb-47fc-b785-4793b08f2920');
