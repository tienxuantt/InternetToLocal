﻿SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_Update_FAMissCategoryID;

CREATE PROCEDURE Proc_Jira_Update_FAMissCategoryID (IN $fixed_asset_id varchar(36))
BEGIN

        DECLARE $convert_circular_id int DEFAULT 0;
        DECLARE $organization_id varchar(36) DEFAULT null;

        SELECT fa.convert_circular_id, fa.organization_id INTO $convert_circular_id, $organization_id FROM fixed_asset fa WHERE fa.fixed_asset_id = $fixed_asset_id;

        -- Lấy ra danh mục
        DROP TEMPORARY TABLE IF EXISTS tbCategoryFA;
        CREATE TEMPORARY TABLE tbCategoryFA
        SELECT * FROM 
        (
                SELECT 
                A.fixed_asset_category_id,
                A.fixed_asset_category_code,
                A.fixed_asset_category_name,
                ROW_NUMBER() OVER(PARTITION BY A.fixed_asset_category_master_id ORDER BY A.organization_id DESC) AS STT
                FROM dic_fixed_asset_category A 
                INNER JOIN dic_fixed_asset_category_master B
                ON A.fixed_asset_category_master_id = B.fixed_asset_category_master_id
                WHERE A.convert_circular_id = $convert_circular_id 
                AND (A.organization_id IS NULL OR A.organization_id = $organization_id)
        ) T WHERE T.STT = 1;

        -- Lấy ra tài sản bị mất loại
        DROP TEMPORARY TABLE IF EXISTS tbFAMissCategory;
        CREATE TEMPORARY TABLE tbFAMissCategory
        SELECT fa.organization_id, fa.fixed_asset_id, fa.fixed_asset_category_id, fa.fixed_asset_category_code, fa.fixed_asset_category_name, fa.convert_circular_id 
        FROM fixed_asset fa
        WHERE fa.fixed_asset_id = $fixed_asset_id;

        -- Lấy lại theo tên danh mục
        UPDATE tbFAMissCategory A
        INNER JOIN  tbCategoryFA B ON A.fixed_asset_category_name = B.fixed_asset_category_name
        set A.fixed_asset_category_id = B.fixed_asset_category_id,
        A.fixed_asset_category_code = B.fixed_asset_category_code;

       UPDATE fixed_asset fa
       INNER JOIN tbFAMissCategory fc on fa.organization_id = fc.organization_id and fa.fixed_asset_id = fc.fixed_asset_id 
       set fa.fixed_asset_category_id = fc.fixed_asset_category_id,
       fa.fixed_asset_category_code = fc.fixed_asset_category_code,
       fa.fixed_asset_category_name = fc.fixed_asset_category_name;

       UPDATE fixed_asset_ledger fa
       INNER JOIN tbFAMissCategory fc on fa.organization_id = fc.organization_id and fa.fixed_asset_id = fc.fixed_asset_id 
       set fa.fixed_asset_category_id = fc.fixed_asset_category_id,
       fa.fixed_asset_category_code = fc.fixed_asset_category_code,
       fa.fixed_asset_category_name = fc.fixed_asset_category_name;

        UPDATE fa_ledger_inventory fa
       INNER JOIN tbFAMissCategory fc on fa.organization_id = fc.organization_id and fa.fixed_asset_id = fc.fixed_asset_id 
       set fa.fixed_asset_category_id = fc.fixed_asset_category_id,
       fa.fixed_asset_category_code = fc.fixed_asset_category_code,
       fa.fixed_asset_category_name = fc.fixed_asset_category_name;

       UPDATE convert_circular_history cch
       INNER JOIN tbFAMissCategory fa on cch.organization_id = fa.organization_id AND cch.fixed_asset_id = fa.fixed_asset_id AND cch.convert_circular_id = fa.convert_circular_id
       set cch.fixed_asset_category_id_new = fa.fixed_asset_category_id,
       cch.fixed_asset_category_code_new = fa.fixed_asset_category_code;

END;

SELECT fa.fixed_asset_code, do.organization_code, concat("CALL Proc_Jira_Update_FAMissCategoryID('",fa.fixed_asset_id,"');") as Data  
FROM fixed_asset fa
INNER JOIN dic_organization do on fa.organization_id = do.organization_id
LEFT JOIN dic_fixed_asset_category dfac ON fa.fixed_asset_category_id = dfac.fixed_asset_category_id AND fa.convert_circular_id = dfac.convert_circular_id
WHERE dfac.fixed_asset_category_id IS NULL
GROUP BY fa.fixed_asset_id;

CALL Proc_Jira_Update_FAMissCategoryID('4b89033c-f6b2-4eaf-938b-0b51cda011cd');


