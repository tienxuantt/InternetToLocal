﻿SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_SplitVoucherIncrement;

CREATE PROCEDURE Proc_Jira_SplitVoucherIncrement (IN $organization_id varchar(36), IN $voucher_id varchar(36))
SQL SECURITY INVOKER
BEGIN

    DECLARE $i int DEFAULT 0;
    DECLARE $count int DEFAULT 0;
    DECLARE $voucher_code varchar(255);
    DECLARE $voucher_id_new varchar(36);
    DECLARE $fixed_asset_id varchar(36);
    DECLARE $purchaseDate datetime;
    DECLARE $orgprice decimal(19,4) DEFAULT 0;

  -- Lấy ra các tài sản chứng từ ghi tăng
  DROP TEMPORARY TABLE IF EXISTS tempVoucherIncrement;
  CREATE TEMPORARY TABLE tempVoucherIncrement
  SELECT * FROM fixed_asset_increment_detail faid
  WHERE faid.organization_id = $organization_id and faid.voucher_id = $voucher_id;

  SELECT
    COUNT(1) INTO $count
  FROM tempVoucherIncrement;

  WHILE $i < $count DO

    SELECT voucher_code INTO $voucher_code 
    FROM fixed_asset_increment 
    WHERE organization_id = $organization_id AND voucher_id = $voucher_id 
    LIMIT 1;

    SET $voucher_code = CONCAT($voucher_code, "_", $i  + 1);
    SET $voucher_id_new = UUID();

    SELECT a.fixed_asset_id, fa.purchase_date, fa.orgprice INTO $fixed_asset_id, $purchaseDate, $orgprice
    FROM tempVoucherIncrement a
    INNER JOIN fixed_asset fa ON a.organization_id = fa.organization_id AND a.fixed_asset_id = fa.fixed_asset_id
    LIMIT $i, 1;

    INSERT INTO fixed_asset_increment
    (
      voucher_id
     ,voucher_code
     ,voucher_date
     ,increment_date
     ,description
     ,total_orgprice
     ,fixed_asset_increment_list
     ,document_member_list
     ,organization_id
     ,created_date
     ,created_by
     ,modified_date
     ,modified_by
     ,is_data_convert
     ,generate_from_transfer
    )
    SELECT 
     $voucher_id_new
     ,$voucher_code
     ,$purchaseDate
     ,$purchaseDate
     ,description
     ,$orgprice AS total_orgprice
     ,fixed_asset_increment_list
     ,document_member_list
     ,organization_id
     ,created_date
     ,created_by
     ,modified_date
     ,modified_by
     ,is_data_convert
     ,generate_from_transfer
     FROM fixed_asset_increment fai 
     WHERE fai.organization_id = $organization_id AND fai.voucher_id = $voucher_id;
            
    UPDATE fixed_asset_increment_detail faid
    set faid.voucher_id = $voucher_id_new,
    faid.voucher_code = $voucher_code
    WHERE  faid.organization_id = $organization_id AND faid.voucher_id = $voucher_id AND faid.fixed_asset_id = $fixed_asset_id;

    UPDATE fixed_asset_ledger faid
    set faid.voucher_id = $voucher_id_new,
    faid.voucher_code = $voucher_code,
    faid.voucher_date = $purchaseDate,
    faid.change_date = $purchaseDate
    WHERE  faid.organization_id = $organization_id AND faid.voucher_id = $voucher_id AND faid.fixed_asset_id = $fixed_asset_id AND faid.voucher_type = 1;

    UPDATE fa_ledger_increment_and_decrement faid
    set faid.voucher_id = $voucher_id_new,
    faid.voucher_code = $voucher_code,
    faid.voucher_date = $purchaseDate,
    faid.change_date = $purchaseDate
    WHERE  faid.organization_id = $organization_id AND faid.voucher_id = $voucher_id AND faid.fixed_asset_id = $fixed_asset_id AND faid.voucher_type = 1;

    UPDATE fixed_asset fa
    SET fa.increment_date = $purchaseDate
    WHERE fa.fixed_asset_id = $fixed_asset_id;

    SET $i = $i + 1;
  END WHILE;

  DELETE FROM fixed_asset_increment WHERE organization_id = $organization_id AND voucher_id = $voucher_id;
    
  DROP TEMPORARY TABLE IF EXISTS tempVoucherIncrement;
END  ;

CALL Proc_Jira_SplitVoucherIncrement('c3bbc550-41f4-412e-a1e1-daa840b9cd56', '19084084-0ce2-462b-8645-79758e900e6f');

