﻿DROP PROCEDURE IF EXISTS Proc_Jira_KS_RevaluationDuplicate_ByFA;

CREATE PROCEDURE Proc_Jira_KS_RevaluationDuplicate_ByFA (IN $fixed_asset_id varchar(36), IN $type int)
BEGIN

        DROP TEMPORARY TABLE IF EXISTS tempFADelete;
        CREATE TEMPORARY TABLE tempFADelete    
        SELECT fal.organization_id, fal.fixed_asset_id, fal.voucher_id, ROW_NUMBER() OVER(PARTITION BY fal.fixed_asset_id ORDER BY fal.change_date DESC, fal.created_date DESC) AS STT 
        FROM fixed_asset_ledger fal 
        WHERE fal.voucher_type = 2 AND fal.fixed_asset_id = $fixed_asset_id;

        IF ($type = 0) THEN
            SELECT * FROM tempFADelete WHERE STT <> 1;
        end if;

        IF ($type = 1) THEN
             DELETE A 
             FROM fixed_asset_revaluation A
             INNER JOIN tempFADelete f ON A.organization_id = f.organization_id AND A.voucher_id = f.voucher_id AND A.fixed_asset_id = f.fixed_asset_id
             WHERE f.STT <> 1;

             DELETE A 
             FROM fa_ledger_change_info A
             INNER JOIN tempFADelete f ON A.organization_id = f.organization_id AND A.voucher_id = f.voucher_id AND A.fixed_asset_id = f.fixed_asset_id
             WHERE f.STT <> 1;

             DELETE A 
             FROM fa_ledger_revaluation_detail A
             INNER JOIN tempFADelete f ON A.organization_id = f.organization_id AND A.voucher_id = f.voucher_id AND A.fixed_asset_id = f.fixed_asset_id
             WHERE f.STT <> 1;

             DELETE A 
             FROM fixed_asset_ledger A
             INNER JOIN tempFADelete f ON A.organization_id = f.organization_id AND A.voucher_id = f.voucher_id AND A.fixed_asset_id = f.fixed_asset_id
             WHERE f.STT <> 1;
        end if;

END  ;


SELECT concat("CALL Proc_Jira_KS_RevaluationDuplicate_ByFA('",fal.fixed_asset_id,"', 1);") as Data 
FROM fixed_asset_ledger fal
INNER JOIN dic_organization do on fal.organization_id = do.organization_id
WHERE fal.voucher_type = 2
GROUP BY fal.organization_id, do.organization_code, fal.fixed_asset_id,fal.fixed_asset_code, fal.voucher_code, fal.orgprice, fal.accum_depreciation_amount, fal.remaining_amount
HAVING count(*) > 1;

CALL Proc_Jira_KS_RevaluationDuplicate_ByFA('e4fb3866-f054-4e94-8160-3cad54c6807b',1);