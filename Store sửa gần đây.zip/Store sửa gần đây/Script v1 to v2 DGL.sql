﻿DROP TABLE IF EXISTS data_v1_revaluation;
CREATE TABLE data_v1_revaluation(
id varchar(36),
organization_id varchar(36),
voucher_id varchar(36),
voucher_code varchar(50),
voucher_date datetime,
fixed_asset_id varchar(36),
fixed_asset_code varchar(50),
fixed_asset_revaluation_list longtext
);

DELETE FROM data_v1_revaluation;

SELECT count(*) FROM data_v1_revaluation;


IF OBJECT_ID('tempdb..#tmpBudgetTree') <> 0
    DROP TABLE #tmpBudgetTree;

-- Lấy budget_type của các nguồn
  WITH V
      AS
      (SELECT
            BC.BudgetCategoryID,
            BC.BudgetCategoryCode,
            BC.BudgetCategoryName,
            BC.MISACodeID,
			BC.BudgetCategoryID AS ShowBudgetID,
			BC.BudgetCategoryName AS ShowBudgetName,
			BC.BudgetCategoryCode AS ShowBudgetCode						
			    FROM dbo.BudgetCategory AS BC 
				WHERE BC.ParentID IS NULL
        UNION ALL
        SELECT
            BC.BudgetCategoryID,
            BC.BudgetCategoryCode,
            BC.BudgetCategoryName,
            BC.MISACodeID,
			V.ShowBudgetID,
			V.ShowBudgetName,
			V.ShowBudgetCode

        FROM dbo.BudgetCategory BC
          INNER JOIN V
            ON BC.ParentID = V.BudgetCategoryID
			  )
      SELECT
        BudgetCategoryID,
        BudgetCategoryCode,
        BudgetCategoryName,
        MISACodeID,
		V.ShowBudgetID,
		V.ShowBudgetName,
		V.ShowBudgetCode,
		CASE WHEN V.ShowBudgetCode IN (1,2,3,7) THEN 1 ELSE 2 END AS BudgetType
        INTO #tmpBudgetTree
		FROM V
		 GROUP BY  BudgetCategoryID,
        BudgetCategoryCode,
        BudgetCategoryName,
        MISACodeID,
		V.ShowBudgetID,
		V.ShowBudgetName,
		V.ShowBudgetCode;

SELECT REPLACE(CONCAT('INSERT data_v1_revaluation VALUES ','(uuid(), "', OrganizationID,'","', VoucherId,'","',VoucherCode,'","', FORMAT(VoucherDate , 'yyyy-MM-dd HH:mm:ss'),'","', FixedAssetID,'","', FixedAssetCode,'",@abc', FixedAssetRevaluationList, '@abc);'), '@abc',N'''') AS Data
FROM(
	SELECT FD.FADocumentID AS VoucherId,
		FD.FADocumentCode AS VoucherCode,
		FD.DocumentDate AS VoucherDate,
		FH.FixedAssetID,
		FH.FixedAssetCode,
		(
			SELECT
				(
					SELECT 
							CAST(A.OrgPrice AS DECIMAL(19, 4)) AS orgprice,
							CAST(A.Quantity AS DECIMAL(19, 4)) AS quantity,
							CAST(A.DepreciationAmount AS DECIMAL(19, 4)) AS depreciation_amount,
							CAST(A.RemainingAmount AS DECIMAL(19, 4)) AS remaining_amount,
							CAST(A.DepreciationRate AS DECIMAL(19, 4)) AS depreciation_rate,
							CAST(A.DepreciationYear AS DECIMAL(19, 4)) AS depreciation_year,
							CAST(A.RemainingNumberOfYear AS DECIMAL(19, 4)) AS remaining_number_of_year,
							CAST(ISNULL(A.DepreciationForBusinessRemainingTime,0) AS DECIMAL(19, 4))  AS depreciation_for_business_remaining_time,
							CAST(ISNULL(A.DepreciationForBusinessValue,0) AS DECIMAL(19, 4))  AS depreciation_for_business_value,
							CAST(ISNULL(A.DepreciationForBusinessAmount,0) AS DECIMAL(19, 4))  AS depreciation_for_business_amount,
							CAST(ISNULL(A.DepreciationForBusinessPrice,0) AS DECIMAL(19, 4))  AS depreciation_for_business_price,
							CAST(ISNULL(A.DepreciationForBusinessRemainingAmount,0) AS DECIMAL(19, 4))  AS depreciation_for_business_remaining_amount,
							A.HouseCategoryID AS house_category_id,
							A.HouseCategoryName AS house_category_name
					FOR JSON PATH
				) AS old_data,
				(
					SELECT
						CAST(A.OrgPrice + ISNULL(FH.OrgPrice, 0) AS DECIMAL(19, 4)) AS orgprice,
						CAST(A.Quantity + ISNULL(FH.Quantity, 0) AS INT) AS quantity,
						CAST(A.DepreciationAmount + ISNULL(FH.DepreciationAmount, 0) AS DECIMAL(19, 4)) AS depreciation_amount,
						CAST(A.RemainingAmount + ISNULL(FH.RemainingAmount, 0) AS DECIMAL(19, 4)) AS remaining_amount,
						CAST(A.DepreciationRate + ISNULL(FH.DepreciationRate, 0) AS DECIMAL(19, 4)) AS depreciation_rate,
						CAST(A.DepreciationYear + ISNULL(FH.DepreciationYear, 0) AS DECIMAL(19, 4)) AS depreciation_year,
						CAST(A.RemainingNumberOfYear + ISNULL(FH.RemainingNumberOfYear, 0) AS INT) AS remaining_number_of_year,
						CAST(ISNULL(A.DepreciationForBusinessRemainingTime,0)
							+ ISNULL(DD2.DepreciationForBusinessRemainingTime, 0) AS DECIMAL(19, 4)) AS depreciation_for_business_remaining_time,
						CAST(ISNULL(A.DepreciationForBusinessValue,0) + ISNULL(DD2.DepreciationValue, 0) AS DECIMAL(19, 4)) AS depreciation_for_business_value,
						CAST(ISNULL(A.DepreciationForBusinessAmount,0) + ISNULL(DD2.DepreciationAmount, 0) AS DECIMAL(19, 4)) AS depreciation_for_business_amount,
						CAST(ISNULL(A.DepreciationForBusinessPrice,0) + ISNULL(DD2.DepreciationPrice, 0) AS DECIMAL(19, 4)) AS depreciation_for_business_price,
						CAST(ISNULL(A.DepreciationForBusinessRemainingAmount,0)
							+ ISNULL(DD2.DepreciationPrice - DD2.DepreciationAmount, 0) AS DECIMAL(19, 4)) AS depreciation_for_business_remaining_amount,
							FH.HouseCategoryID AS house_category_id,
							HC.HouseCategoryName as house_category_name
					FOR JSON PATH
				) AS new_data,
				(
					SELECT
						CAST(FH.OrgPrice AS DECIMAL(19, 4)) AS orgprice,
						CAST(FH.Quantity AS INT) AS quantity,
						CAST(FH.DepreciationAmount AS DECIMAL(19, 4)) AS depreciation_amount,
						CAST(FH.RemainingAmount AS DECIMAL(19, 4)) AS remaining_amount,
						CAST(FH.DepreciationRate AS DECIMAL(19, 4)) AS depreciation_rate,
						CAST(FH.DepreciationYear AS DECIMAL(19, 4)) AS depreciation_year,
						CAST(FH.RemainingNumberOfYear AS INT) AS remaining_number_of_year,
						CAST(ISNULL(DD2.DepreciationForBusinessRemainingTime,0) AS DECIMAL(19, 4)) AS depreciation_for_business_remaining_time,
						CAST(ISNULL(DD2.DepreciationValue,0) AS DECIMAL(19, 4))  AS depreciation_for_business_value,
						CAST(ISNULL(DD2.DepreciationAmount,0) AS DECIMAL(19, 4))  AS depreciation_for_business_amount,
						CAST(ISNULL(DD2.DepreciationPrice,0) AS DECIMAL(19, 4))  AS depreciation_for_business_price,
						CAST((ISNULL(DD2.DepreciationPrice,0) - ISNULL(DD2.DepreciationAmount,0)) AS DECIMAL(19, 4))  AS depreciation_for_business_remaining_amount
					FOR JSON PATH
				) AS change_data
			FROM
			(
				SELECT Top 1  FH2.FixedAssetID,
				-- FH2.FADocumentID,
				FH2.ChangeDate,
				FH2.HouseCategoryID,
				G.HouseCategoryName,
						(
							SELECT LOWER(BC.BudgetCategoryID) AS budget_category_id,
									BC.BudgetCategoryName AS budget_category_name,
									BC.BudgetCategoryCode AS budget_category_code,
									CAST(SUM(FHB.Amount) AS DECIMAL(19, 4)) AS amount,
									TBT.BudgetType AS budget_type
							FROM dbo.FAHistory AS FH4
								INNER JOIN dbo.FAHistoryBudget AS FHB
									ON FHB.FAHistoryID = FH4.FAHistoryID
								LEFT JOIN dbo.BudgetCategory AS BC
									ON BC.BudgetCategoryID = FHB.BudgetCategoryID
								LEFT JOIN #tmpBudgetTree AS TBT
									ON TBT.BudgetCategoryID = BC.BudgetCategoryID
							WHERE FH4.FixedAssetID = FH.FixedAssetID
								AND FH4.ChangeDate < FH.ChangeDate
								AND FH4.FAHistoryID <> FH.FAHistoryID
								AND FH4.FixedAssetChangeCategoryID IN ( 1, 2, 8 )
							GROUP BY BC.BudgetCategoryID,
									BC.BudgetCategoryName,
									BC.BudgetCategoryCode,
									TBT.BudgetType
							FOR JSON PATH
						) AS OrgPriceInfor,
						CAST(SUM(F.OrgPrice) AS DECIMAL(19, 4)) AS OrgPrice,
						CAST(SUM(F.Quantity)  AS DECIMAL(19, 4)) AS Quantity,
						CAST(SUM(D.DepreciationAmount) AS DECIMAL(19, 4)) AS DepreciationAmount,
						CAST(SUM(D.RemainingAmount) AS DECIMAL(19, 4)) AS RemainingAmount,
						CAST(SUM(D.DepreciationRate) AS DECIMAL(19, 4)) AS DepreciationRate,
						CAST(SUM(F.DepreciationYear) AS DECIMAL(19, 4)) AS DepreciationYear,
						CAST(SUM(C.RemainingNumberOfYear) - ISNULL(MIN(B.SL), 0) + ISNULL(MAX(E.RemainingNumberOfYear),0) AS INT) AS RemainingNumberOfYear,
						CAST(SUM(F.Area) AS DECIMAL(19, 4)) AS Area,
						CAST(SUM(F.BuildArea) AS DECIMAL(19, 4)) AS BuildArea,
						CAST(SUM(F.TotalFloorArea) AS DECIMAL(19, 4)) AS TotalFloorArea,
						CAST(SUM(F.NumberOfFloor) AS INT) AS NumberOfFloor,
						CAST(SUM(F.IsWorkingOffice) AS DECIMAL(19, 4)) AS IsWorkingOffice,
						CAST(SUM(F.IsBusiness) AS DECIMAL(19, 4)) AS IsBusiness,
						CAST(SUM(F.IsJointVenture) AS DECIMAL(19, 4)) AS IsJointVenture,
						CAST(SUM(F.IsMixUsing) AS DECIMAL(19, 4)) AS IsMixUsing,
						CAST(SUM(F.IsBasisOfBusinessActivity) AS DECIMAL(19, 4)) AS IsBasisOfBusinessActivity,
						CAST(SUM(F.IsLeasing) AS DECIMAL(19, 4)) AS IsLeasing,
						CAST(SUM(F.IsHouse) AS DECIMAL(19, 4)) AS IsHouse,
						CAST(SUM(F.IsOccupied) AS DECIMAL(19, 4)) AS IsOccupied,
						CAST(SUM(F.IsVacant) AS DECIMAL(19, 4)) AS IsVacant,
						CAST(SUM(F.IsOther) AS DECIMAL(19, 4)) AS IsOther,
						CAST(MAX(DD.DepreciationForBusinessRemainingTime) AS DECIMAL(19, 4)) AS DepreciationForBusinessRemainingTime,
						CAST(MAX(DD.DepreciationValue) AS DECIMAL(19, 4)) AS DepreciationForBusinessValue,
						CAST(MAX(DD.DepreciationAmount) AS DECIMAL(19, 4)) AS DepreciationForBusinessAmount,
						CAST(MAX(DD.DepreciationPrice) AS DECIMAL(19, 4)) AS DepreciationForBusinessPrice,
						CAST(MAX(DD.DepreciationPrice - DD.DepreciationAmount) AS DECIMAL(19, 4)) AS DepreciationForBusinessRemainingAmount
				FROM dbo.FAHistory AS FH2
					LEFT JOIN dbo.DepreciationDistribution AS DD
						ON DD.FixedAssetID = FH2.FixedAssetID
							AND DD.FADocumentID = FH2.FADocumentID
					LEFT JOIN
					(
						SELECT FH3.FixedAssetID,
								COUNT(FH3.FixedAssetID) AS SL
						FROM dbo.FAHistory AS FH3
						WHERE FH3.FixedAssetID = FH.FixedAssetID
								AND FH3.FixedAssetChangeCategoryID = 5
								AND FH3.ChangeDate <= FH.ChangeDate
								AND FH3.FAHistoryID <> FH.FAHistoryID
						GROUP BY FH3.FixedAssetID
					) AS B
						ON B.FixedAssetID = FH2.FixedAssetID
					LEFT JOIN 
					(
						SELECT FH5.FixedAssetID, FH5.RemainingNumberOfYear FROM dbo.FAHistory AS FH5 
						WHERE FH5.FixedAssetChangeCategoryID IN (1,8)
					) C
					ON C.FixedAssetID = FH2.FixedAssetID
					LEFT JOIN 
					(
						SELECT FH6.FixedAssetID, SUM(FH6.RemainingAmount) RemainingAmount, 
						SUM(CASE WHEN FH6.FixedAssetChangeCategoryID IN (1,8,2) THEN FH6.DepreciationRate ELSE 0 END)  DepreciationRate,
						SUM(CASE WHEN FH6.FixedAssetChangeCategoryID IN (1,8,5,9) THEN FH6.DepreciationAmount ELSE 0 END)  DepreciationAmount
						FROM dbo.FAHistory AS FH6 
						WHERE FH6.FixedAssetChangeCategoryID IN (1,8,2,5,9) AND FH.FixedAssetID = FH6.FixedAssetID AND FH6.ChangeDate < FH.ChangeDate
						GROUP BY FH6.FixedAssetID
					) D
					ON FH.FixedAssetID = D.FixedAssetID
					LEFT JOIN
					(
						SELECT FH7.FixedAssetID,
								SUM(FH7.RemainingNumberOfYear) RemainingNumberOfYear
						FROM dbo.FAHistory AS FH7
						WHERE FH7.FixedAssetID = FH.FixedAssetID
								AND FH7.FixedAssetChangeCategoryID = 2
								AND FH7.ChangeDate < FH.ChangeDate
								AND FH7.FAHistoryID <> FH.FAHistoryID
						GROUP BY FH7.FixedAssetID
					) AS E
						ON E.FixedAssetID = FH2.FixedAssetID
					LEFT JOIN
					(
						SELECT FH8.FixedAssetID,
								SUM(FH8.OrgPrice) AS OrgPrice,
								SUM(FH8.Quantity) AS Quantity,
								SUM(FH8.DepreciationYear) AS DepreciationYear,
								SUM(FH8.Area) AS Area,
								SUM(FH8.TotalFloorArea) AS TotalFloorArea,
								SUM(FH8.BuildArea) AS BuildArea,
								SUM(FH8.NumberOfFloor) AS NumberOfFloor,
								SUM(FH8.IsWorkingOffice) AS IsWorkingOffice,
								SUM(FH8.IsBusiness) AS IsBusiness,
								SUM(FH8.IsJointVenture) AS IsJointVenture,
								SUM(FH8.IsMixUsing) AS IsMixUsing,
								SUM(FH8.IsBasisOfBusinessActivity) AS IsBasisOfBusinessActivity,
								SUM(FH8.IsLeasing) AS IsLeasing,
								SUM(FH8.IsHouse) AS IsHouse,
								SUM(FH8.IsOccupied) AS IsOccupied,
								SUM(FH8.IsVacant) AS IsVacant,
								SUM(FH8.IsOther) AS IsOther
						FROM dbo.FAHistory AS FH8
						WHERE FH8.FixedAssetID = FH.FixedAssetID
								AND FH8.FixedAssetChangeCategoryID IN (1,8,2)
								AND FH8.ChangeDate <= FH.ChangeDate
								AND FH8.FAHistoryID <> FH.FAHistoryID
						GROUP BY FH8.FixedAssetID
					) AS F
						ON F.FixedAssetID = FH2.FixedAssetID							
					LEFT JOIN dbo.HouseCategory G ON FH2.HouseCategoryID = G.HouseCategoryID
				WHERE 
					FH2.FixedAssetID = FH.FixedAssetID
						AND FH2.FixedAssetChangeCategoryID IN ( 1, 2, 5, 9, 8 )
						AND FH2.ChangeDate <= FH.ChangeDate
						AND FH.FAHistoryID <> FH2.FAHistoryID
				GROUP BY FH2.FixedAssetID, FH2.OrgPrice,FH2.ChangeDate, 			   FH2.HouseCategoryID,
				G.HouseCategoryName
				order by FH2.ChangeDate DESC
			) AS A
			FOR JSON PATH
		) AS FixedAssetRevaluationList,
		FD.OrganizationID
	FROM dbo.FADocument AS FD
	INNER JOIN dbo.FAHistory AS FH
		ON FH.FADocumentID = FD.FADocumentID
	LEFT JOIN dbo.ReasonCategory AS RC
		ON RC.ReasonCategoryID = FH.ReasonCategoryID
	LEFT JOIN dbo.DepreciationDistribution AS DD2
		ON DD2.FixedAssetID = FH.FixedAssetID
			AND FD.FADocumentID = DD2.FADocumentID
	LEFT JOIN dbo.FixedAsset AS FA ON FH.FixedAssetID = FA.FixedAssetID		
	LEFT JOIN dbo.HouseCategory HC ON FH.HouseCategoryID = HC.HouseCategoryID
	WHERE  FD.FixedAssetChangeCategoryID = 2   
	
) a