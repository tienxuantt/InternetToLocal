﻿SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_Update_Quantity_TotalMoney_Equipment;

CREATE PROCEDURE Proc_Jira_Update_Quantity_TotalMoney_Equipment(IN $equipment_id varchar(36), IN $quantity decimal(19,4), IN $total_money decimal(19,4))
BEGIN

    DECLARE $Count int DEFAULT 0;
    DECLARE $i int DEFAULT 1;
    DECLARE $distribute_type int DEFAULT 1;
    DECLARE $quantity_current decimal(19,4) DEFAULT 0;
    DECLARE $total_money_current decimal(19,4) DEFAULT 0;


    DROP TEMPORARY TABLE IF EXISTS tbUpdateDataEQ;
    CREATE TEMPORARY TABLE tbUpdateDataEQ (
      STT int,
      voucher_id varchar(36),
      equipment_id varchar(36),
      voucher_type int,
      change_date datetime,
      pre_quantity decimal(19, 4),
      quantity decimal(19, 4),
      price decimal(19, 4),
      pre_total_money decimal(19, 4),
      total_money decimal(19, 4),
      distribution_remaning_amount decimal(19, 4),
      distribution_amount_per_time decimal(19, 4),
      distribution_amount decimal(19, 4)
    ) COLLATE utf8mb4_0900_as_ci;

    -- Lấy ra kì phân bổ
    SET $distribute_type = (SELECT e.distribution_type FROM equipment e WHERE e.equipment_id = $equipment_id LIMIT 1);

    DROP TEMPORARY TABLE IF EXISTS tblEquipmentTempOrigin;
    CREATE TEMPORARY TABLE tblEquipmentTempOrigin AS
    SELECT *,
    ROW_NUMBER() OVER (PARTITION BY equipment_id ORDER BY A.change_date, A.created_date) AS STT
    FROM 
    (
      SELECT equipment_id,equipment_code,voucher_id,voucher_code,voucher_type,change_date,pre_quantity,quantity,price,pre_total_money,total_money,distribution_amount,distribution_remaning_amount,distribution_amount_per_time,equipment_category_id,old_department_id,department_id,new_department_id,vendor_id,incremental_date,tracking_date,distribution_type,distribution_time,distribution_rate,distribution_remaning_time,organization_id,status_id,0 as difference_quantity,difference_orgprice,0 as inventory_quantity,0 AS inventory_orgprice, created_date
      FROM equipment_ledger
      WHERE equipment_id = $equipment_id
      UNION ALL
      SELECT 
      equipment_id,equipment_code,voucher_id,voucher_code,voucher_type,change_date,0 as pre_quantity,quantity,price,0 as pre_total_money,total_money,distribution_amount,distribution_remaning_amount,distribution_amount_per_time,equipment_category_id,old_department_id,department_id,NULL as new_department_id,vendor_id,incremental_date,tracking_date,distribution_type,distribution_time,distribution_rate,distribution_remaning_time,organization_id,status_id,difference_quantity,difference_orgprice,inventory_quantity,inventory_orgprice, eli.created_date
      FROM equipment_ledger_inventory eli
      WHERE equipment_id = $equipment_id
    ) A; 

    SELECT
    COUNT(1) INTO $Count
    FROM tblEquipmentTempOrigin;

    WHILE $i <= $Count DO
  
      IF $i = 1 THEN
        INSERT INTO tbUpdateDataEQ (STT, voucher_id, equipment_id, voucher_type, change_date, pre_quantity, quantity, price, pre_total_money, total_money, distribution_remaning_amount, distribution_amount_per_time, distribution_amount)
          SELECT
            STT,
            voucher_id,
            equipment_id,
            voucher_type,
            change_date,
            0 AS pre_quantity,
            ROUND($quantity) AS quantity,
            IF($quantity > 0, ROUND(ROUND($total_money)/$quantity), 0) price,
            0 AS pre_total_money,
            ROUND($total_money) as total_money,
            IF($distribute_type = 1, 0, ROUND(IFNULL(distribution_remaning_amount,0))) AS distribution_remaning_amount,
            IF($distribute_type = 1, $total_money, ROUND(IFNULL(distribution_amount_per_time,0))) AS distribution_amount_per_time,
            IF($distribute_type = 1, $total_money, ROUND(IFNULL(distribution_amount,0))) AS distribution_amount
          FROM tblEquipmentTempOrigin
          WHERE STT = $i;
      ELSE
        DROP TEMPORARY TABLE IF EXISTS tbCacheDataEQ;
        CREATE TEMPORARY TABLE tbCacheDataEQ
        SELECT
          *
        FROM tbUpdateDataEQ
        WHERE STT = $i - 1;

        -- Lấy ra số lượng hiện tại
        SET $quantity_current =   
        (
            SELECT  if(A.voucher_type IN (4,5), B.quantity, A.quantity) AS quantity  
            FROM tblEquipmentTempOrigin A
            LEFT JOIN tbCacheDataEQ B ON 1 = 1
            WHERE A.STT = $i LIMIT 1
        );

        -- Lấy ra số tiền hiện tại
        SET $total_money_current =   
        (
            SELECT  ROUND(IFNULL(if(A.voucher_type IN (4,5), B.total_money, A.total_money),0)) AS total_money  
            FROM tblEquipmentTempOrigin A
            LEFT JOIN tbCacheDataEQ B ON 1 = 1
            WHERE A.STT = $i LIMIT 1
        );

       INSERT INTO tbUpdateDataEQ (STT, voucher_id, equipment_id, voucher_type, change_date, pre_quantity, quantity, price, pre_total_money, total_money, distribution_remaning_amount, distribution_amount_per_time, distribution_amount)
       SELECT
          A.STT,
          A.voucher_id,
          A.equipment_id,
          A.voucher_type,
          A.change_date,
          CASE WHEN B.voucher_type IN (1,6,7) THEN IFNULL(B.pre_quantity,0) + IFNULL(B.quantity,0)
               WHEN B.voucher_type IN (2,3) THEN IFNULL(B.pre_quantity,0) - IFNULL(B.quantity,0) 
               ELSE B.quantity
          END AS pre_quantity,
          $quantity_current AS quantity,
          IF($quantity_current > 0, ROUND($total_money_current/$quantity_current), 0) price,
          CASE WHEN B.voucher_type IN (1,6,7) THEN IFNULL(B.pre_total_money,0) + IFNULL(B.total_money,0)
               WHEN B.voucher_type IN (2,3) THEN IFNULL(B.pre_total_money,0) - IFNULL(B.total_money,0) 
               ELSE B.total_money
          END AS pre_total_money,
          $total_money_current AS total_money,
          CASE WHEN $distribute_type = 1 AND B.voucher_type IN (1,6,7) THEN IFNULL(B.pre_total_money,0) + IFNULL(B.total_money,0) + $total_money_current
               WHEN $distribute_type = 1 AND B.voucher_type IN (2,3) THEN IFNULL(B.pre_total_money,0) - IFNULL(B.total_money,0)   + $total_money_current
               WHEN $distribute_type = 1 AND B.voucher_type IN (4,5) THEN IFNULL(A.total_money,0)
               ELSE A.distribution_remaning_amount
          END AS distribution_remaning_amount,
          CASE WHEN $distribute_type = 1 AND B.voucher_type IN (1,6,7) THEN IFNULL(B.pre_total_money,0) + IFNULL(B.total_money,0) + $total_money_current
               WHEN $distribute_type = 1 AND B.voucher_type IN (2,3) THEN IFNULL(B.pre_total_money,0) - IFNULL(B.total_money,0)   + $total_money_current
               WHEN $distribute_type = 1 AND B.voucher_type IN (4,5) THEN $total_money_current
               ELSE A.distribution_amount_per_time
          END AS distribution_amount_per_time,
          A.distribution_amount
        FROM tblEquipmentTempOrigin A
        LEFT JOIN tbCacheDataEQ B ON 1 = 1
        WHERE A.STT = $i;
  
      END IF;

      -- Cập nhật vào equipment
      IF $i = $Count THEN

          UPDATE equipment e
          INNER JOIN
          (
                SELECT el.equipment_id, 
                SUM(ROUND(IF(el.voucher_type IN (1,6,7), el.quantity, (-1)*el.quantity))) AS quantity,
                SUM(ROUND(IF(el.voucher_type IN (1,6,7), el.total_money, (-1)*el.total_money))) AS total_money
                FROM tbUpdateDataEQ el
                WHERE el.voucher_type IN (1,2,3,6,7)
                GROUP BY el.equipment_id
          ) B ON e.equipment_id = B.equipment_id
          set e.quantity = B.quantity,
          e.price = if(B.quantity > 0, ROUND(B.total_money/B.quantity), e.price) ,
          e.total_money = IF(B.quantity = 0, 0, B.total_money),
          e.distribution_remaning_amount =  IF(B.quantity = 0, 0, e.distribution_remaning_amount),
          e.distribution_amount =  IF(B.quantity = 0, 0, e.distribution_amount)
          WHERE e.equipment_id = $equipment_id;

      END IF;
  
      SET $i = $i + 1;
    END WHILE;

    -- Nếu không còn ledger nào
    IF ($Count = 0) THEN
         UPDATE equipment e
         set 
          e.quantity = $quantity,
          e.price = if($quantity > 0, ROUND($total_money/$quantity), 0) ,
          e.total_money = IF($quantity = 0, 0, $total_money),
          e.distribution_remaning_amount =  IF($quantity = 0, 0, e.distribution_remaning_amount),
          e.distribution_amount =  IF($quantity = 0, 0, e.distribution_amount)
          WHERE e.equipment_id = $equipment_id;
    end if;

    -- Update Detail 
    UPDATE equipment_increment_detail A
    INNER JOIN tbUpdateDataEQ B ON A.voucher_id = B.voucher_id AND A.equipment_id = B.equipment_id
    SET 
    A.pre_quantity = B.pre_quantity,
    A.quantity = B.quantity,
    A.price = B.price,
    A.pre_total_money = B.pre_total_money,
    A.total_money = B.total_money,
    A.distribution_remaning_amount = B.distribution_remaning_amount,
    A.distribution_amount_per_time = B.distribution_amount_per_time,
    A.distribution_amount = B.distribution_amount
    WHERE A.equipment_id = $equipment_id;

    UPDATE equipment_transfer_detail A
    INNER JOIN tbUpdateDataEQ B ON A.voucher_id = B.voucher_id AND A.equipment_id = B.equipment_id
    SET 
    A.pre_quantity = B.pre_quantity,
    A.quantity = B.quantity,
    A.price = B.price,
    A.pre_total_money = B.pre_total_money,
    A.total_money = B.total_money,
    A.distribution_remaning_amount = B.distribution_remaning_amount,
    A.distribution_amount_per_time = B.distribution_amount_per_time,
    A.distribution_amount = B.distribution_amount
    WHERE A.equipment_id = $equipment_id;

    UPDATE equipment_distribution_detail A
    INNER JOIN tbUpdateDataEQ B ON A.voucher_id = B.voucher_id AND A.equipment_id = B.equipment_id
    SET 
    A.quantity = B.quantity,
    A.total_money = B.total_money,
    A.distribution_remaning_amount = B.distribution_remaning_amount,
    A.distribution_amount_per_time = B.distribution_amount_per_time,
    A.distribution_amount = B.distribution_amount
    WHERE A.equipment_id = $equipment_id;

    UPDATE equipment_ledger_inventory A
    INNER JOIN tbUpdateDataEQ B ON A.voucher_id = B.voucher_id AND A.equipment_id = B.equipment_id
    SET 
    A.quantity = B.quantity,
    A.price = B.price,
    A.total_money = B.total_money,
    A.inventory_quantity = IFNULL(B.quantity,0) - IFNULL(A.difference_quantity, 0),
    A.inventory_orgprice = IFNULL(B.total_money,0) - IFNULL(A.difference_orgprice, 0),
    A.distribution_remaning_amount = B.distribution_remaning_amount,
    A.distribution_amount_per_time = B.distribution_amount_per_time,
    A.distribution_amount = B.distribution_amount
    WHERE A.equipment_id = $equipment_id;

    UPDATE equipment_decrement_detail A
    INNER JOIN tbUpdateDataEQ B ON A.voucher_id = B.voucher_id AND A.equipment_id = B.equipment_id
    SET 
    A.pre_quantity = B.pre_quantity,
    A.quantity = B.quantity,
    A.price = B.price,
    A.pre_total_money = B.pre_total_money,
    A.total_money = B.total_money,
    A.distribution_remaning_amount = 0,
    A.distribution_amount_per_time = 0,
    A.distribution_amount = 0
    WHERE A.equipment_id = $equipment_id;

    -- Cập nhật ledger
    UPDATE equipment_ledger A
    INNER JOIN tbUpdateDataEQ B ON A.voucher_id = B.voucher_id AND A.equipment_id = B.equipment_id
    SET
    A.pre_quantity = IF(A.voucher_type = 5, 0, B.pre_quantity),
    A.quantity = B.quantity,
    A.price = B.price,
    A.pre_total_money = IF(A.voucher_type = 5, 0, B.pre_total_money),
    A.total_money = B.total_money,
    A.distribution_remaning_amount = B.distribution_remaning_amount,
    A.distribution_amount_per_time = B.distribution_amount_per_time,
    A.distribution_amount = B.distribution_amount
    WHERE A.equipment_id = $equipment_id;

    DROP TEMPORARY TABLE IF EXISTS tblEquipmentTempOrigin;
    
END;
