﻿ SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_UpdateChangeDateLedgerError;

CREATE PROCEDURE Proc_Jira_UpdateChangeDateLedgerError (IN $organization_id varchar(36))
SQL SECURITY INVOKER
BEGIN

        UPDATE fixed_asset_ledger fad
        INNER JOIN
        (
             SELECT fal.organization_id, fal.voucher_id, MAX(fal.change_date)  AS change_date, MAX(fal.created_date) AS created_date
             FROM fixed_asset_ledger fal
             WHERE fal.organization_id = $organization_id
             GROUP BY fal.organization_id, fal.voucher_id
        ) B ON B.organization_id = fad.organization_id AND B.voucher_id = fad.voucher_id
        set fad.change_date = B.change_date,
        fad.created_date = B.created_date
        WHERE fad.organization_id = $organization_id;

        UPDATE fa_ledger_inventory fad
        INNER JOIN
        (
             SELECT fal.organization_id, fal.voucher_id, MAX(fal.change_date)  AS change_date, MAX(fal.created_date) AS created_date
             FROM fa_ledger_inventory fal
             WHERE fal.organization_id = $organization_id
             GROUP BY fal.organization_id, fal.voucher_id
        ) B ON B.organization_id = fad.organization_id AND B.voucher_id = fad.voucher_id
        set fad.change_date = B.change_date,
        fad.created_date = B.created_date
        WHERE fad.organization_id = $organization_id;

END;


SELECT concat("Call Proc_Jira_UpdateChangeDateLedgerError('",a.organization_id,"');") AS Data
FROM fixed_asset a 
GROUP BY a.organization_id;

Call Proc_Jira_UpdateChangeDateLedgerError('44db30fd-b15c-4eb7-b813-4d2bcfc2fdea');