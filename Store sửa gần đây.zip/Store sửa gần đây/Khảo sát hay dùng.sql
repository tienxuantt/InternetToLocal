﻿SELECT fa1.fixed_asset_id 
FROM  fixed_asset fa1
INNER JOIN (
  SELECT
  SUM(IF(fa.status_id = 1, 1,0)) AS TotalDangSuDung,
  SUM(IF(fa.status_id = 2, 1,0)) AS TotalChuaGhiTang,
  SUM(IF(fa.status_id = 3, 1,0)) AS TotalDaGhiGiam,
  COUNT(*) AS Total,
  fa.parent_id
  FROM fixed_asset fa
  WHERE fa.parent_id IS NOT NULL
  GROUP BY fa.parent_id
) K ON fa1.fixed_asset_id = K.parent_id
WHERE fa1.is_parent = 1
AND
(
 (fa1.status_id = 3 AND K.Total <> K.TotalDaGhiGiam)
 OR
 (fa1.status_id = 2 AND K.Total <> K.TotalChuaGhiTang)
 OR
 (fa1.status_id = 1 AND (K.TotalDaGhiGiam = K.Total OR K.TotalChuaGhiTang = K.Total))
);

update fixed_asset fa1
INNER JOIN (
  SELECT
  SUM(IF(fa.status_id = 1, 1,0)) AS TotalDangSuDung,
  SUM(IF(fa.status_id = 2, 1,0)) AS TotalChuaGhiTang,
  SUM(IF(fa.status_id = 3, 1,0)) AS TotalDaGhiGiam,
  COUNT(*) AS Total,
  fa.parent_id
  FROM fixed_asset fa
  WHERE fa.parent_id IS NOT NULL
  GROUP BY fa.parent_id
) K ON fa1.fixed_asset_id = K.parent_id
SET fa1.status_id = CASE WHEN K.TotalDangSuDung > 0 THEN 1
                         WHEN K.TotalDaGhiGiam = K.Total THEN 3
                         WHEN K.TotalChuaGhiTang = K.Total THEN 2 ELSE fa1.status_id END
WHERE fa1.is_parent = 1
AND
(
 (fa1.status_id = 3 AND K.Total <> K.TotalDaGhiGiam)
 OR
 (fa1.status_id = 2 AND K.Total <> K.TotalChuaGhiTang)
 OR
 (fa1.status_id = 1 AND (K.TotalDaGhiGiam = K.Total OR K.TotalChuaGhiTang = K.Total))
);

SELECT concat("CALL Proc_Jira_ReCallUpdateFAData('",fa.fixed_asset_id,"');") as Data 
from fixed_asset fa 
inner JOIN 
(
    select fal.organization_id, fal.fixed_asset_id, fal.remaining_amount, fal.orgprice, 
    row_number() over(partition by fixed_asset_id order by change_date desc, created_date desc, fal.fixed_asset_ledger_id DESC) rn 
    from fixed_asset_ledger fal
    WHERE fal.voucher_type <> 17
) tm on fa.organization_id = tm.organization_id and fa.fixed_asset_id = tm.fixed_asset_id and tm.rn = 1
INNER JOIN dic_organization do on fa.organization_id = do.organization_id 
where ifnull(fa.remaining_amount, 0) <> ifnull(tm.remaining_amount, 0) and ifnull(fa.is_parent, 0) = 0 
GROUP BY fa.fixed_asset_id;

SELECT * 
FROM synchronization_log_report slr WHERE slr.synchronization_status <> 3 AND IFNULL(slr.is_exception,0) = 0 AND TIMESTAMPDIFF(MINUTE, slr.created_date, NOW()) > 60;

-- KS ledger cuoi
SELECT fa.fixed_asset_code, do.organization_code, fa.orgprice, tm.orgprice AS orgprice_2,fa.accum_depreciation_amount, tm.accum_depreciation_amount AS accum_2, fa.remaining_amount,  tm.remaining_amount AS remaining_2 
from fixed_asset fa 
inner JOIN 
(
    select fal2.organization_id, fal2.fixed_asset_id, fal2.remaining_amount, fal2.orgprice, fal2.accum_depreciation_amount,
    row_number() over(partition by fal2.fixed_asset_id order by fal2.change_date desc, fal2.created_date desc) rn 
    from (
        SELECT fal.organization_id, fal.fixed_asset_id, fal.remaining_amount, fal.orgprice, fal.accum_depreciation_amount, fal.change_date, fal.created_date, fal.fixed_asset_ledger_id
        FROM fixed_asset_ledger fal 
        WHERE fal.voucher_type <> 17
        UNION ALL
        SELECT fli.organization_id, fli.fixed_asset_id, fli.remaining_amount, fli.orgprice, fli.accum_depreciation_amount, fli.change_date, fli.created_date, fli.fixed_asset_ledger_id 
        FROM fa_ledger_inventory fli
    ) fal2
) tm on fa.organization_id = tm.organization_id and fa.fixed_asset_id = tm.fixed_asset_id and tm.rn = 1
INNER JOIN dic_organization do on fa.organization_id = do.organization_id 
where ifnull(fa.is_parent, 0) = 0 AND fa.status_id <> 2
AND 
( 
ifnull(fa.orgprice, 0) <> ifnull(tm.orgprice, 0) 
OR ifnull(fa.accum_depreciation_amount, 0) <> ifnull(tm.accum_depreciation_amount, 0) 
OR ifnull(fa.remaining_amount, 0) <> ifnull(tm.remaining_amount, 0)) 
ORDER BY do.organization_code;

SELECT concat("CALL Proc_Jira_ReCallUpdateFAData('",fa.fixed_asset_id,"');") as Data 
from fixed_asset fa 
inner JOIN 
(
    select fal2.organization_id, fal2.fixed_asset_id, fal2.remaining_amount, fal2.orgprice, fal2.accum_depreciation_amount,
    row_number() over(partition by fal2.fixed_asset_id order by fal2.change_date desc, fal2.created_date desc) rn 
    from (
        SELECT fal.organization_id, fal.fixed_asset_id, fal.remaining_amount, fal.orgprice, fal.accum_depreciation_amount, fal.change_date, fal.created_date, fal.fixed_asset_ledger_id
        FROM fixed_asset_ledger fal 
        WHERE fal.voucher_type <> 17
        UNION ALL
        SELECT fli.organization_id, fli.fixed_asset_id, fli.remaining_amount, fli.orgprice, fli.accum_depreciation_amount, fli.change_date, fli.created_date, fli.fixed_asset_ledger_id 
        FROM fa_ledger_inventory fli
    ) fal2
) tm on fa.organization_id = tm.organization_id and fa.fixed_asset_id = tm.fixed_asset_id and tm.rn = 1
INNER JOIN dic_organization do on fa.organization_id = do.organization_id 
where ifnull(fa.is_parent, 0) = 0 AND fa.status_id <> 2
AND 
( 
ifnull(fa.orgprice, 0) <> ifnull(tm.orgprice, 0) 
OR ifnull(fa.accum_depreciation_amount, 0) <> ifnull(tm.accum_depreciation_amount, 0) 
OR ifnull(fa.remaining_amount, 0) <> ifnull(tm.remaining_amount, 0)) 
GROUP BY fa.fixed_asset_id;

SELECT fa.fixed_asset_type, fa.depreciation_amount, fa.depreciation_for_business_amount, fa.accum_depreciation_amount FROM fixed_asset fa WHERE fa.fixed_asset_id = '0813d1e8-105d-45f3-aab2-a369de1ebebc';

SELECT fa.fixed_asset_id, fa.fixed_asset_code, fa.fixed_asset_type, fa.depreciation_amount, fa.depreciation_for_business_amount, fa.accum_depreciation_amount
 FROM fixed_asset fa WHERE
(fa.fixed_asset_type = 1 AND fa.depreciation_for_business_amount > 0)
OR
(fa.fixed_asset_type = 2 AND fa.depreciation_amount > 0);

UPDATE fixed_asset fa
set fa.depreciation_amount = IF(fa.fixed_asset_type = 2, 0, fa.depreciation_amount) ,
fa.depreciation_for_business_amount = IF(fa.fixed_asset_type = 1, 0, fa.depreciation_for_business_amount)
WHERE
(fa.fixed_asset_type = 1 AND fa.depreciation_for_business_amount > 0)
OR
(fa.fixed_asset_type = 2 AND fa.depreciation_amount > 0);

UPDATE fixed_asset_ledger fa
set fa.depreciation_amount = IF(fa.fixed_asset_type = 2, 0, fa.depreciation_amount) ,
fa.depreciation_for_business_amount = IF(fa.fixed_asset_type = 1, 0, fa.depreciation_for_business_amount)
WHERE
(fa.fixed_asset_type = 1 AND fa.depreciation_for_business_amount > 0)
OR
(fa.fixed_asset_type = 2 AND fa.depreciation_amount > 0);

select fa.fixed_asset_code, do.organization_code
from fixed_asset fa 
INNER JOIN dic_organization do on fa.organization_id = do.organization_id 
WHERE 
ifnull(fa.is_parent, 0) = 0 and fa.status_id <> 2 and (round(fa.orgprice) - round(fa.accum_depreciation_amount) <> round(fa.remaining_amount)) 
ORDER BY do.organization_code;

WITH cte_history
AS
(SELECT
      fal.organization_id,
      fal.fixed_asset_id,
      fal.fixed_asset_code,
      fal.voucher_type,
      fal.change_date,
      fal.created_date,
      fal.voucher_id,
      fal.depreciation_amount,
      ROW_NUMBER() OVER (PARTITION BY organization_id, fixed_asset_id
      ORDER BY fal.change_date, fal.created_date, fal.voucher_type) rn
    FROM fixed_asset_ledger fal
    WHERE voucher_type <> 17
)
SELECT
  CONCAT("CALL Proc_Jira_ReCallUpdateFAData('", ch.fixed_asset_id, "');") AS Data
FROM cte_history ch
  LEFT JOIN cte_history ch1
    ON ch.organization_id = ch1.organization_id
    AND ch.fixed_asset_id = ch1.fixed_asset_id
    AND ch1.rn = ch.rn - 1
WHERE ch.voucher_type = 3
AND ch.depreciation_amount < ch1.depreciation_amount
GROUP BY ch.fixed_asset_id;

SELECT fa.fixed_asset_code, fa.depreciation_year, B.depreciation_year AS year_2, do.organization_code 
FROM  fixed_asset fa
INNER JOIN dic_organization do on fa.organization_id = do.organization_id
INNER JOIN 
(
      SELECT
      fal.organization_id,
      fal.fixed_asset_id,
      fal.voucher_id,
      fal.depreciation_year,
      ROW_NUMBER() OVER (PARTITION BY  fixed_asset_id ORDER BY fal.change_date DESC, fal.created_date DESC) rn
    FROM fixed_asset_ledger fal
    WHERE voucher_type = 2
) B on B.organization_id = fa.organization_id AND fa.fixed_asset_id = B.fixed_asset_id AND B.rn = 1
INNER JOIN fixed_asset_revaluation far ON fa.fixed_asset_id = far.fixed_asset_id AND B.voucher_id = far.voucher_id
WHERE YEAR(far.revaluation_date) = 2023 AND fa.depreciation_year <> far.fixed_asset_revaluation_list ->> '$[0].new_data[0].depreciation_year'
ORDER BY do.organization_code;

UPDATE  fixed_asset fa
INNER JOIN 
(
      SELECT
      fal.organization_id,
      fal.fixed_asset_id,
      fal.voucher_id,
      fal.depreciation_year,
      ROW_NUMBER() OVER (PARTITION BY  fixed_asset_id ORDER BY fal.change_date DESC, fal.created_date DESC) rn
    FROM fixed_asset_ledger fal
    WHERE voucher_type = 2
) B on B.organization_id = fa.organization_id AND fa.fixed_asset_id = B.fixed_asset_id AND B.rn = 1
INNER JOIN fixed_asset_revaluation far ON fa.fixed_asset_id = far.fixed_asset_id AND B.voucher_id = far.voucher_id
set fa.depreciation_year =  far.fixed_asset_revaluation_list ->> '$[0].new_data[0].depreciation_year'
WHERE ifnull( far.fixed_asset_revaluation_list, '') <> ''  AND  YEAR(far.revaluation_date) = 2023 AND JSON_VALID(far.fixed_asset_revaluation_list) = 1 AND fa.depreciation_year <> far.fixed_asset_revaluation_list ->> '$[0].new_data[0].depreciation_year';

UPDATE fixed_asset_ledger fal
INNER JOIN fixed_asset_revaluation far on fal.organization_id = far.organization_id and fal.voucher_id = far.voucher_id AND fal.fixed_asset_id = far.fixed_asset_id
set fal.depreciation_year = IF(far.fixed_asset_revaluation_list -> '$[0].new_data[0].depreciation_year' = 'null', 0,far.fixed_asset_revaluation_list -> '$[0].new_data[0].depreciation_year' )  
WHERE fal.voucher_type = 2 AND JSON_VALID(far.fixed_asset_revaluation_list) = 1 AND  fal.depreciation_year <> far.fixed_asset_revaluation_list ->> '$[0].new_data[0].depreciation_year';

SELECT far.fixed_asset_revaluation_list FROM fixed_asset_ledger fal
INNER JOIN fixed_asset_revaluation far on fal.organization_id = far.organization_id and fal.voucher_id = far.voucher_id AND fal.fixed_asset_id = far.fixed_asset_id
WHERE far.fixed_asset_revaluation_list -> '$[0].new_data[0].depreciation_year' = 'null' and fal.voucher_type = 2 AND JSON_VALID(far.fixed_asset_revaluation_list) = 1 AND  fal.depreciation_year <> far.fixed_asset_revaluation_list ->> '$[0].new_data[0].depreciation_year';

SHOW CREATE PROCEDURE A;


SELECT round(count(*)/1000) as Total 
FROM fixed_asset_ledger fal 
INNER JOIN 
(SELECT * FROM convert_circular cc ORDER BY cc.convert_circular_id DESC LIMIT 2) B
ON fal.convert_circular_id = B.convert_circular_id;

 SELECT fal.organization_id, fal.fixed_asset_id, fal.fixed_asset_code, fal.fixed_asset_name, fal.voucher_id, fal.voucher_code, fal.voucher_type, fal.change_date,fal.orgprice,fal.accum_depreciation_amount,fal.depreciation_for_business_amount, fal.depreciation_amount, fal.remaining_amount, 
 fal.difference_orgprice, fal.difference_quantity, fal.difference_depreciation_amount, fal.difference_remaining_amount, fal.difference_depreciation_year, fal.difference_depreciation_for_business_remaining_amount, fal.fixed_asset_category_id, fal.department_id,fal.quantity, fal.unit, fal.production_year,  fal.fixed_asset_type, fal.purchase_date, fal.increment_date, fal.software_start_time, fal.used_date, fal.depreciation_start_date, fal.number_of_year,fal.depreciation_rate, fal.remaining_number_of_year, fal.depreciation_end_date, fal.depreciation_for_business_value,  fal.public_asset_type,fal.depreciation_value, fal.convert_circular_id, fal.business_activity_id, fal.created_date 
 FROM fixed_asset_ledger fal
 ORDER BY fal.organization_id, fal.fixed_asset_id, fal.change_date, fal.created_date;

DELETE FROM fa_jira_execute;

INSERT fa_jira_execute (fixed_asset_id)
SELECT dfacm.fixed_asset_category_master_id FROM dic_fixed_asset_category_master dfacm
WHERE dfacm.fixed_asset_category_code = 'III';

INSERT fa_jira_execute (fixed_asset_id)
SELECT fixed_asset_category_master_id
FROM dic_fixed_asset_category_master dfacm
LEFT JOIN  fa_jira_execute B ON dfacm.fixed_asset_category_master_id = B.fixed_asset_id
INNER JOIN fa_jira_execute ddmi ON dfacm.parent_id = ddmi.fixed_asset_id
WHERE B.fixed_asset_id is NULL;

INSERT fa_jira_execute (fixed_asset_id)
SELECT fixed_asset_category_master_id
FROM dic_fixed_asset_category_master dfacm
LEFT JOIN  fa_jira_execute B ON dfacm.fixed_asset_category_master_id = B.fixed_asset_id
INNER JOIN fa_jira_execute ddmi ON dfacm.parent_id = ddmi.fixed_asset_id
WHERE B.fixed_asset_id is NULL;

INSERT fa_jira_execute (fixed_asset_id)
SELECT fixed_asset_category_master_id
FROM dic_fixed_asset_category_master dfacm
LEFT JOIN  fa_jira_execute B ON dfacm.fixed_asset_category_master_id = B.fixed_asset_id
INNER JOIN fa_jira_execute ddmi ON dfacm.parent_id = ddmi.fixed_asset_id
WHERE B.fixed_asset_id is NULL;

INSERT fa_jira_execute (fixed_asset_id)
SELECT fixed_asset_category_master_id
FROM dic_fixed_asset_category_master dfacm
LEFT JOIN  fa_jira_execute B ON dfacm.fixed_asset_category_master_id = B.fixed_asset_id
INNER JOIN fa_jira_execute ddmi ON dfacm.parent_id = ddmi.fixed_asset_id
WHERE B.fixed_asset_id is NULL;

INSERT fa_jira_execute (fixed_asset_id)
SELECT fixed_asset_category_master_id
FROM dic_fixed_asset_category_master dfacm
LEFT JOIN  fa_jira_execute B ON dfacm.fixed_asset_category_master_id = B.fixed_asset_id
INNER JOIN fa_jira_execute ddmi ON dfacm.parent_id = ddmi.fixed_asset_id
WHERE B.fixed_asset_id is NULL;

INSERT fa_jira_execute (fixed_asset_id)
SELECT fixed_asset_category_master_id
FROM dic_fixed_asset_category_master dfacm
LEFT JOIN  fa_jira_execute B ON dfacm.fixed_asset_category_master_id = B.fixed_asset_id
INNER JOIN fa_jira_execute ddmi ON dfacm.parent_id = ddmi.fixed_asset_id
WHERE B.fixed_asset_id is NULL;

INSERT fa_jira_execute (fixed_asset_id)
SELECT fixed_asset_category_master_id
FROM dic_fixed_asset_category_master dfacm
LEFT JOIN  fa_jira_execute B ON dfacm.fixed_asset_category_master_id = B.fixed_asset_id
INNER JOIN fa_jira_execute ddmi ON dfacm.parent_id = ddmi.fixed_asset_id
WHERE B.fixed_asset_id is NULL;

UPDATE dic_fixed_asset_category dfac
INNER JOIN fa_jira_execute fje ON dfac.fixed_asset_category_master_id = fje.fixed_asset_id
set dfac.orgprice_min = 5000000, dfac.orgprice_max = 10000000;


SELECT fa.fixed_asset_id, fa.fixed_asset_code, do.organization_code 
FROM fixed_asset fa
INNER JOIN dic_organization do on fa.organization_id = do.organization_id
INNER JOIN dic_fixed_asset_category dfac ON  dfac.organization_id IS NULL AND fa.fixed_asset_category_id = dfac.fixed_asset_category_id AND fa.convert_circular_id = dfac.convert_circular_id
INNER JOIN dic_fixed_asset_category dfac1 ON fa.organization_id = dfac1.organization_id  AND dfac1.fixed_asset_category_master_id = dfac.fixed_asset_category_master_id AND fa.convert_circular_id = dfac1.convert_circular_id 
WHERE dfac.fixed_asset_category_id <> dfac1.fixed_asset_category_id
ORDER BY do.organization_code;

DROP TEMPORARY TABLE IF EXISTS tempFAError;
CREATE TEMPORARY TABLE tempFAError
SELECT fa.fixed_asset_id, dfac1.fixed_asset_category_id, dfac1.fixed_asset_category_code, dfac1.fixed_asset_category_name
FROM fixed_asset fa
INNER JOIN dic_organization do on fa.organization_id = do.organization_id
INNER JOIN dic_fixed_asset_category dfac ON  dfac.organization_id IS NULL AND fa.fixed_asset_category_id = dfac.fixed_asset_category_id AND fa.convert_circular_id = dfac.convert_circular_id
INNER JOIN dic_fixed_asset_category dfac1 ON fa.organization_id = dfac1.organization_id  AND dfac1.fixed_asset_category_master_id = dfac.fixed_asset_category_master_id AND fa.convert_circular_id = dfac1.convert_circular_id 
WHERE dfac.fixed_asset_category_id <> dfac1.fixed_asset_category_id;

UPDATE fixed_asset fa
INNER JOIN  tempFAError B ON fa.fixed_asset_id = B.fixed_asset_id
set fa.fixed_asset_category_id = B.fixed_asset_category_id,
fa.fixed_asset_category_code = B.fixed_asset_category_code,
fa.fixed_asset_category_name = B.fixed_asset_category_name;

UPDATE fixed_asset_ledger fa
INNER JOIN  tempFAError B ON fa.fixed_asset_id = B.fixed_asset_id
set fa.fixed_asset_category_id = B.fixed_asset_category_id,
fa.fixed_asset_category_code = B.fixed_asset_category_code,
fa.fixed_asset_category_name = B.fixed_asset_category_name;

UPDATE fa_ledger_inventory fa
INNER JOIN  tempFAError B ON fa.fixed_asset_id = B.fixed_asset_id
set fa.fixed_asset_category_id = B.fixed_asset_category_id,
fa.fixed_asset_category_code = B.fixed_asset_category_code,
fa.fixed_asset_category_name = B.fixed_asset_category_name;


SELECT cch.* 
FROM dic_fixed_asset_category_master cch 
inner JOIN dic_fixed_asset_category dfac ON dfac.fixed_asset_category_master_id = dfac.fixed_asset_category_master_id 
WHERE dfac.organization_id is NULL OR dfac.organization_id = {0};

SELECT fa.organization_id FROM fixed_asset fa LIMIT 10;
