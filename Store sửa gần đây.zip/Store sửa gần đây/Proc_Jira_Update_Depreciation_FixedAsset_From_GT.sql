﻿DROP PROCEDURE IF EXISTS Proc_Jira_Update_Depreciation_FixedAsset_From_GT;

CREATE PROCEDURE Proc_Jira_Update_Depreciation_FixedAsset_From_GT(IN $FixedAssetID varchar(36), IN $OrgPrice decimal(19, 4), IN $AccumDepreciationAmount decimal(19, 4))
SQL SECURITY INVOKER
BEGIN
  DECLARE $Count int DEFAULT 0;
  DECLARE $i int DEFAULT 1;
  DECLARE $STT_GT int DEFAULT 100;
  DECLARE $VoucherType int DEFAULT 0;
  DECLARE $OrgpriceFA decimal(19, 4) DEFAULT 0;
  DECLARE $SumBudget decimal(19, 4) DEFAULT 0;
  DECLARE $LedgerBudgetID varchar(36);
  DECLARE $OrganizationID varchar(36);
 
 SELECT fa.organization_id INTO $OrganizationID FROM fixed_asset fa WHERE  fa.fixed_asset_id = $FixedAssetID LIMIT 1;

  -- Các ban ghi chuyen loai
  DROP TEMPORARY TABLE IF EXISTS tbChangeInfor;
  CREATE TEMPORARY TABLE tbChangeInfor
  SELECT cch.organization_id, cch.fixed_asset_id, cch.change_category_id AS voucher_id
  FROM fixed_asset_change_category cch
  WHERE cch.organization_id = $OrganizationID AND cch.fixed_asset_id = $FixedAssetID;

  DROP TEMPORARY TABLE IF EXISTS tbUpdateData;
  CREATE TEMPORARY TABLE tbUpdateData (
    STT int,
    fixed_asset_ledger_id bigint,
    fixed_asset_id varchar(36),
    voucher_id varchar(36),
    voucher_code varchar(100),
    voucher_type int,
    change_date datetime,
    orgprice decimal(19, 4),
    voucher_price decimal(19, 4),
    depreciation_value decimal(19, 4),
    accum_depreciation_amount decimal(19, 4),
    remaining_amount decimal(19, 4)
  ) COLLATE utf8mb4_0900_as_ci;

  DROP TEMPORARY TABLE IF EXISTS tbOrginData2;
  CREATE TEMPORARY TABLE tbOrginData2
  SELECT
    *,
    ROW_NUMBER() OVER (PARTITION BY fixed_asset_id ORDER BY A.change_date, A.created_date) AS STT
  FROM (SELECT
      lg.fixed_asset_ledger_id,
      lg.fixed_asset_id,
      lg.voucher_id,
      lg.voucher_code,
      lg.voucher_type,
      lg.change_date,
      lg.created_date,
      lg.orgprice,
      CASE WHEN lg.voucher_type = 9 THEN IFNULL(lg.depreciation_for_business_value, 0) ELSE IF(lg.voucher_type = 5, IFNULL(lg.depreciation_value, 0), 0) END AS voucher_price,
      CASE WHEN lg.voucher_type = 9 THEN IFNULL(lg.depreciation_for_business_value, 0) ELSE IF(lg.voucher_type = 5, IFNULL(lg.depreciation_value, 0), 0) END AS depreciation_value,
      if(lg.voucher_type <> 2, lg.accum_depreciation_amount, IFNULL(lg.depreciation_amount,0) + IFNULL(lg.depreciation_for_business_amount,0)) AS accum_depreciation_amount,
      lg.remaining_amount
    FROM fixed_asset_ledger lg
    LEFT JOIN tbChangeInfor CI ON lg.organization_id = CI.organization_id AND lg.voucher_id = CI.voucher_id AND lg.fixed_asset_id = CI.fixed_asset_id
    WHERE 
    lg.organization_id = $OrganizationID
    AND lg.fixed_asset_id = $FixedAssetID
    AND (lg.voucher_type <> 17 OR CI.organization_id IS NOT NULL)
    UNION ALL
    SELECT
      fixed_asset_ledger_id,
      fixed_asset_id,
      voucher_id,
      voucher_code,
      voucher_type,
      change_date,
      created_date,
      orgprice,
      depreciation_value AS voucher_price,
      depreciation_value,
      accum_depreciation_amount,
      remaining_amount
    FROM fa_ledger_inventory
    WHERE organization_id = $OrganizationID
    AND fixed_asset_id = $FixedAssetID) A;

    SET $STT_GT = (SELECT STT FROM tbOrginData2 WHERE voucher_type in (1,8) ORDER BY STT LIMIT 1);

   -- Xóa b? ch?ng t? tru?c ghi tang
   DELETE FROM  tbOrginData2 WHERE STT <  $STT_GT;

  DROP TEMPORARY TABLE IF EXISTS tbOrginData;
  CREATE TEMPORARY TABLE tbOrginData
  SELECT
    A.fixed_asset_ledger_id,
    A.fixed_asset_id,
    A.voucher_id,
    A.voucher_code,
    A.voucher_type,
    A.change_date,
    A.created_date,
    A.orgprice,
    A.voucher_price,
    A.depreciation_value,
    A.accum_depreciation_amount,
    A.remaining_amount,
    ROW_NUMBER() OVER (PARTITION BY fixed_asset_id ORDER BY A.change_date, A.created_date) AS STT 
    FROM tbOrginData2 A;

IF EXISTS (SELECT 1 FROM tbOrginData od WHERE od.voucher_type in (1,8) AND od.STT = 1) THEN
BEGIN

    SELECT
    COUNT(1) INTO $Count
    FROM tbOrginData;

  WHILE $i <= $Count DO

    IF $i = 1 THEN
      INSERT INTO tbUpdateData (STT, fixed_asset_ledger_id, fixed_asset_id, voucher_id, voucher_code, voucher_type, change_date, orgprice, voucher_price, depreciation_value, accum_depreciation_amount, remaining_amount)
        SELECT
          STT,
          fixed_asset_ledger_id,
          fixed_asset_id,
          voucher_id,
          voucher_code,
          voucher_type,
          change_date,
          $OrgPrice as orgprice,
          voucher_price,
          depreciation_value,
          $AccumDepreciationAmount AS accum_depreciation_amount,
          IFNULL($OrgPrice, 0) - $AccumDepreciationAmount AS remaining_amount
        FROM tbOrginData
        WHERE STT = $i;

      IF $i = $Count THEN

        -- C?p nh?t tài s?n
        UPDATE fixed_asset A
        INNER JOIN tbUpdateData B ON A.fixed_asset_id = B.fixed_asset_id
        SET A.orgprice = B.orgprice,
            A.accum_depreciation_amount = B.accum_depreciation_amount,
            A.depreciation_amount = CASE WHEN A.fixed_asset_type = 1 THEN B.accum_depreciation_amount WHEN A.fixed_asset_type = 2 THEN 0 WHEN A.fixed_asset_type = 3 THEN A.depreciation_amount END,
            A.depreciation_for_business_amount = CASE WHEN A.fixed_asset_type = 1 THEN 0 WHEN A.fixed_asset_type = 2 THEN B.accum_depreciation_amount WHEN A.fixed_asset_type = 3 THEN A.depreciation_for_business_amount END,
            A.remaining_amount = B.remaining_amount
        WHERE A.organization_id = $OrganizationID;

        -- C?p nh?t detail ghi tang
        UPDATE fixed_asset_increment_detail A
        INNER JOIN fixed_asset fa on A.organization_id = fa.organization_id and A.fixed_asset_id = fa.fixed_asset_id
        INNER JOIN tbUpdateData B ON A.fixed_asset_id = B.fixed_asset_id
        SET A.orgprice = B.orgprice
        WHERE A.organization_id = $OrganizationID;
      END IF;

    ELSE
      DROP TEMPORARY TABLE IF EXISTS tbCacheData;
      CREATE TEMPORARY TABLE tbCacheData
      SELECT
        *
      FROM tbUpdateData
      WHERE STT = $i - 1;

      SELECT
        voucher_type INTO $VoucherType
      FROM tbOrginData
      WHERE STT = $i;

      IF ($VoucherType IN (2, 10, 17)) THEN
        INSERT INTO tbUpdateData (STT, fixed_asset_ledger_id, fixed_asset_id, voucher_id, voucher_code, voucher_type, change_date, orgprice, voucher_price, depreciation_value, accum_depreciation_amount, remaining_amount)
          SELECT
            A.STT,
            A.fixed_asset_ledger_id,
            A.fixed_asset_id,
            A.voucher_id,
            A.voucher_code,
            A.voucher_type,
            A.change_date,
            IF($VoucherType IN (17, 10), B.orgprice, A.orgprice) AS orgprice,
            A.voucher_price,
            0 AS depreciation_value,
            IF($VoucherType IN (17, 10), B.accum_depreciation_amount, A.accum_depreciation_amount),
            IF($VoucherType IN (17, 10), B.remaining_amount, IFNULL(A.orgprice, 0) - IFNULL(A.accum_depreciation_amount, 0)) AS remaining_amount
          FROM tbOrginData A
            LEFT JOIN tbCacheData B
              ON 1 = 1
          WHERE A.STT = $i;
      ELSE
        INSERT INTO tbUpdateData (STT, fixed_asset_ledger_id, fixed_asset_id, voucher_id, voucher_code, voucher_type, change_date, orgprice, voucher_price, depreciation_value, accum_depreciation_amount, remaining_amount)
          SELECT
            A.STT,
            A.fixed_asset_ledger_id,
            A.fixed_asset_id,
            A.voucher_id,
            A.voucher_code,
            A.voucher_type,
            A.change_date,
            B.orgprice,
            A.voucher_price,
            A.depreciation_value,
            IFNULL(B.accum_depreciation_amount, 0) + IFNULL(A.depreciation_value, 0) AS accum_depreciation_amount,
            IFNULL(B.remaining_amount, 0) - IFNULL(A.depreciation_value, 0) AS remaining_amount
          FROM tbOrginData A
            LEFT JOIN tbCacheData B
              ON 1 = 1
          WHERE A.STT = $i;
      END IF;

      IF $i = $Count THEN

        UPDATE fixed_asset A
        INNER JOIN tbUpdateData B
          ON A.fixed_asset_id = B.fixed_asset_id
        SET A.orgprice = B.orgprice,
            A.accum_depreciation_amount = B.accum_depreciation_amount,
            A.depreciation_amount = CASE WHEN A.fixed_asset_type = 1 THEN B.accum_depreciation_amount WHEN A.fixed_asset_type = 2 THEN 0 WHEN A.fixed_asset_type = 3 THEN A.depreciation_amount END,
            A.depreciation_for_business_amount = CASE WHEN A.fixed_asset_type = 1 THEN 0 WHEN A.fixed_asset_type = 2 THEN B.accum_depreciation_amount WHEN A.fixed_asset_type = 3 THEN A.depreciation_for_business_amount END,
            A.remaining_amount = B.remaining_amount
        WHERE A.organization_id = $OrganizationID
        AND B.STT = $Count;

      END IF;
    END IF;

    SET $i = $i + 1;
    SET $VoucherType = 0;
  END WHILE;

  -- C?p nh?t ledger to
  UPDATE fixed_asset_ledger A
  INNER JOIN (SELECT
      *
    FROM tbUpdateData
    WHERE voucher_type <> 10) B
    ON A.organization_id = $OrganizationID
    AND A.fixed_asset_ledger_id = B.fixed_asset_ledger_id
  SET A.orgprice = B.orgprice,
      A.accum_depreciation_amount = B.accum_depreciation_amount,
      A.depreciation_amount = CASE WHEN A.fixed_asset_type = 1 THEN IF(A.voucher_type = 2, A.depreciation_amount, B.accum_depreciation_amount )  WHEN A.fixed_asset_type = 2 THEN 0 WHEN A.fixed_asset_type = 3 THEN A.depreciation_amount END,
      A.depreciation_for_business_amount = CASE WHEN A.fixed_asset_type = 1 THEN 0 WHEN A.fixed_asset_type = 2 THEN IF(A.voucher_type = 2, A.depreciation_for_business_amount, B.accum_depreciation_amount ) WHEN A.fixed_asset_type = 3 THEN A.depreciation_for_business_amount END,
      A.remaining_amount = B.remaining_amount
  WHERE A.organization_id = $OrganizationID;

  -- C?p nh?t ledger ki?m kê
  UPDATE fa_ledger_inventory A
  INNER JOIN (SELECT * FROM tbUpdateData WHERE voucher_type = 10) B
    ON A.organization_id = $OrganizationID
    AND A.fixed_asset_ledger_id = B.fixed_asset_ledger_id
  SET A.orgprice = B.orgprice,
      A.inventory_orgprice = IFNULL(B.orgprice,0) - IFNULL(A.difference_orgprice,0),
      A.inventory_remaining_amount = IFNULL(B.remaining_amount,0) - IFNULL(A.difference_remaining_amount,0),
      A.accum_depreciation_amount = B.accum_depreciation_amount,
      A.depreciation_amount = CASE WHEN A.fixed_asset_type = 1 THEN B.accum_depreciation_amount WHEN A.fixed_asset_type = 2 THEN 0 WHEN A.fixed_asset_type = 3 THEN A.depreciation_amount END,
      A.depreciation_for_business_amount = CASE WHEN A.fixed_asset_type = 1 THEN 0 WHEN A.fixed_asset_type = 2 THEN B.accum_depreciation_amount WHEN A.fixed_asset_type = 3 THEN A.depreciation_for_business_amount END,
      A.remaining_amount = B.remaining_amount,
      A.depreciation_value = 0,
      A.depreciation_for_business_value = 0
  WHERE A.organization_id = $OrganizationID;

    -- Detail ghi tang
    UPDATE fixed_asset_increment_detail  A
    INNER JOIN fixed_asset fa ON fa.organization_id = $OrganizationID AND A.fixed_asset_id = fa.fixed_asset_id
    INNER JOIN (SELECT * FROM tbUpdateData WHERE voucher_type = 1) B
    ON A.organization_id = $OrganizationID AND A.voucher_id = B.voucher_id AND A.fixed_asset_id = B.fixed_asset_id
   SET A.orgprice = B.orgprice,
      A.accum_depreciation_amount = B.accum_depreciation_amount,
      A.remaining_amount = B.remaining_amount,
      A.depreciation_value = 0,
      A.depreciation_for_business_value = 0
   WHERE A.organization_id = $OrganizationID;  

    -- Detail Hao mon
    UPDATE fixed_asset_depreciation_detail  A
    INNER JOIN (SELECT * FROM tbUpdateData WHERE voucher_type = 5) B
    ON A.organization_id = $OrganizationID AND A.voucher_id = B.voucher_id AND A.fixed_asset_id = B.fixed_asset_id
   SET A.orgprice = B.orgprice,
      A.first_remaining_amount = IFNULL(B.remaining_amount,0) + IFNULL(B.depreciation_value,0),
      A.depreciation_value = IFNULL(B.depreciation_value, 0),
      A.depreciation_for_business_value = 0
   WHERE A.organization_id = $OrganizationID;  

    -- Detail KH
    UPDATE fixed_asset_depreciation_business_detail  A
    INNER JOIN (SELECT * FROM tbUpdateData WHERE voucher_type = 9) B
    ON A.organization_id = $OrganizationID AND A.voucher_id = B.voucher_id AND A.fixed_asset_id = B.fixed_asset_id
   SET A.orgprice = B.orgprice,
      A.first_remaining_amount = IFNULL(B.remaining_amount,0) + IFNULL(B.depreciation_value,0),
      A.depreciation_for_business_remaining_amount =  IFNULL(B.remaining_amount,0) + IFNULL(B.depreciation_value,0),
      A.depreciation_for_business_value = IFNULL(B.depreciation_value, 0),
      A.depreciation_value = 0
   WHERE A.organization_id = $OrganizationID;  

    -- Detail Ghi giam
    UPDATE fixed_asset_decrement_detail  A
    INNER JOIN fixed_asset fa ON fa.organization_id = $OrganizationID AND A.fixed_asset_id = fa.fixed_asset_id
    INNER JOIN (SELECT * FROM tbUpdateData WHERE voucher_type = 6) B
    ON A.organization_id = $OrganizationID AND A.voucher_id = B.voucher_id AND A.fixed_asset_id = B.fixed_asset_id
   SET A.orgprice = B.orgprice,
      A.accum_depreciation_amount = B.accum_depreciation_amount,
      A.depreciation_amount = CASE WHEN fa.fixed_asset_type = 1 THEN B.accum_depreciation_amount WHEN fa.fixed_asset_type = 2 THEN 0 WHEN fa.fixed_asset_type = 3 THEN A.depreciation_amount END,
      A.depreciation_for_business_amount = CASE WHEN fa.fixed_asset_type = 1 THEN 0 WHEN fa.fixed_asset_type = 2 THEN B.accum_depreciation_amount WHEN fa.fixed_asset_type = 3 THEN A.depreciation_for_business_amount END,
      A.remaining_amount = B.remaining_amount,
      A.depreciation_value = 0,
      A.depreciation_for_business_value = 0
   WHERE A.organization_id = $OrganizationID;      

   #region Update Master

    -- Update GT
    UPDATE fixed_asset_increment fad
    INNER JOIN (SELECT
                fadd.organization_id,
                fadd.voucher_id,
                SUM(ROUND(fadd.orgprice)) AS TotalMoney
            FROM fixed_asset_increment_detail fadd
            WHERE  fadd.organization_id = $OrganizationID AND IFNULL(fadd.is_parent,0) = 0
            GROUP BY fadd.organization_id,
                     fadd.voucher_id
            ) B
            ON B.organization_id = fad.organization_id AND B.voucher_id = fad.voucher_id
        SET fad.total_orgprice = B.TotalMoney
        WHERE fad.organization_id = $OrganizationID
        AND fad.total_orgprice <> B.TotalMoney;

 -- Update GG
    UPDATE fixed_asset_decrement fad
    INNER JOIN (SELECT
                fadd.organization_id,
                fadd.voucher_id,
                SUM(ROUND(fadd.orgprice)) AS TotalMoney
            FROM fixed_asset_decrement_detail fadd
            WHERE  fadd.organization_id = $OrganizationID AND IFNULL(fadd.is_parent,0) = 0
            GROUP BY fadd.organization_id,
                     fadd.voucher_id
            ) B
            ON B.organization_id = fad.organization_id AND B.voucher_id = fad.voucher_id
        SET fad.total_orgprice = B.TotalMoney
        WHERE fad.organization_id = $OrganizationID
        AND fad.total_orgprice <> B.TotalMoney;

    -- Update HM
    UPDATE fixed_asset_depreciation fad
    INNER JOIN (SELECT
                fadd.organization_id,
                fadd.voucher_id,
                SUM(ROUND(fadd.depreciation_value)) AS TotalMoney
            FROM fixed_asset_depreciation_detail fadd
            WHERE  fadd.organization_id = $OrganizationID AND IFNULL(fadd.is_parent,0) = 0
            GROUP BY fadd.organization_id,
                     fadd.voucher_id
            ) B
            ON B.organization_id = fad.organization_id AND B.voucher_id = fad.voucher_id
        SET fad.total_price = B.TotalMoney
        WHERE fad.organization_id = $OrganizationID
        AND fad.total_price <> B.TotalMoney;

    -- Update KH
    UPDATE fixed_asset_depreciation_business fad
        INNER JOIN (SELECT
                fadd.organization_id,
                fadd.voucher_id,
                SUM(ROUND(fadd.depreciation_for_business_value)) AS TotalMoney
            FROM fixed_asset_depreciation_business_detail fadd
            WHERE fadd.organization_id = $OrganizationID AND IFNULL(fadd.is_parent,0) = 0
            GROUP BY fadd.organization_id,
                     fadd.voucher_id) B
            ON B.organization_id = fad.organization_id
            AND B.voucher_id = fad.voucher_id
        SET fad.total_price = B.TotalMoney
        WHERE fad.organization_id = $OrganizationID 
        AND fad.total_price <> B.TotalMoney;

  #endregion

  -- L?y nguyên giá c?a tài s?n
  set $OrgpriceFA = (SELECT orgprice FROM fixed_asset fa WHERE fa.fixed_asset_id = $FixedAssetID);

  -- Ledger budget c?a tài s?n
  DROP TEMPORARY TABLE IF EXISTS tbLedgerBudgetFA;
  CREATE TEMPORARY TABLE tbLedgerBudgetFA
  SELECT lb.*
  FROM ledger_budget lb 
  INNER JOIN
  (
    SELECT * FROM
    (
      SELECT l.fixed_asset_id, IFNULL(l.voucher_id, '') AS voucher_id,
      ROW_NUMBER() OVER(PARTITION BY fixed_asset_id ORDER BY change_date DESC, created_date DESC) AS STT
      FROM ledger_budget l
      WHERE l.fixed_asset_id = $FixedAssetID AND IFNULL(voucher_type, 1) IN (1,2,8)
    ) A WHERE A.STT = 1
  ) A2 ON lb.fixed_asset_id = A2.fixed_asset_id AND IFNULL(lb.voucher_id, '') = A2.voucher_id;

  -- N?u nguyên giá khác v?i t?ng trong ledger budget thì c?p nh?t l?i
  IF (select SUM(ifnull(amount,0)) FROM tbLedgerBudgetFA) <> $OrgpriceFA THEN
      BEGIN

                 -- C?p nh?t d?i v?i tru?ng h?p ch? có m?t ngu?n
                 IF (SELECT count(*) FROM tbLedgerBudgetFA) = 1 THEN
                 BEGIN
                    UPDATE  tbLedgerBudgetFA set amount = $OrgpriceFA;

                    UPDATE ledger_budget lb 
                    INNER JOIN tbLedgerBudgetFA lbf ON lb.organization_id = lbf.organization_id AND lb.ledger_budget_id = lbf.ledger_budget_id
                    set lb.amount = lbf.amount;
                 END;
                 END IF;

                -- Tru?ng h?p có nhi?u ngu?n
                IF (SELECT count(*) FROM tbLedgerBudgetFA) > 1 THEN
                 BEGIN
                    SET $LedgerBudgetID = (SELECT ledger_budget_id FROM tbLedgerBudgetFA ORDER BY amount DESC LIMIT 1);

                    SET $SumBudget =  (SELECT sum(ifnull(amount,0)) FROM tbLedgerBudgetFA WHERE ledger_budget_id <> $LedgerBudgetID);

                    UPDATE ledger_budget lb 
                    set lb.amount = ifnull($OrgpriceFA,0) - ifnull($SumBudget,0)
                    WHERE lb.ledger_budget_id =  $LedgerBudgetID;

                 END;
                 END IF;
                 
      END;
  END IF;

  DROP TEMPORARY TABLE IF EXISTS tbCacheData;
  DROP TEMPORARY TABLE IF EXISTS tbLedgerBudgetFA;
  
END; 
END IF;
  
DROP TEMPORARY TABLE IF EXISTS tbUpdateData;
DROP TEMPORARY TABLE IF EXISTS tbOrginData;
DROP TEMPORARY TABLE IF EXISTS tbOrginData2;
DROP TEMPORARY TABLE IF EXISTS tbChangeInfor;

END;

