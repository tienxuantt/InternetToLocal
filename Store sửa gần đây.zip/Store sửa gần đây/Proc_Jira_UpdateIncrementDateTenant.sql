﻿SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_UpdateIncrementDateTenant;

CREATE PROCEDURE Proc_Jira_UpdateIncrementDateTenant ()
SQL SECURITY INVOKER
BEGIN

    DROP TEMPORARY TABLE IF EXISTS tbOrganization;
    CREATE TEMPORARY TABLE tbOrganization 
    SELECT fal.organization_id, fal.voucher_id
    FROM fixed_asset_ledger fal
    INNER JOIN (
        SELECT fal.organization_id, fal.voucher_id, fal.voucher_type, fal.fixed_asset_id, fal.change_date FROM fixed_asset_ledger fal WHERE fal.voucher_type not IN (1,8,2,17)
        union ALL
        SELECT fal.organization_id, fal.voucher_id, fal.voucher_type, fal.fixed_asset_id, fal.change_date FROM fa_ledger_inventory fal 
    )  B ON fal.organization_id = B.organization_id AND B.fixed_asset_id = fal.fixed_asset_id 
    WHERE fal.voucher_type IN (1,8) AND fal.change_date > B.change_date
    GROUP BY fal.organization_id, fal.voucher_id;
    
    UPDATE fixed_asset_increment fai
    INNER JOIN tbOrganization o ON fai.organization_id = o.organization_id AND  fai.voucher_id = o.voucher_id
    set fai.voucher_date = CONCAT(YEAR(fai.voucher_date), '-01-01'),
    fai.increment_date =  CONCAT(YEAR(fai.increment_date), '-01-01');

    UPDATE fixed_asset fa
    INNER JOIN
    (
       SELECT faid.* FROM fixed_asset_increment_detail faid INNER JOIN tbOrganization o ON faid.organization_id = o.organization_id AND  faid.voucher_id = o.voucher_id
    )  T ON fa.organization_id = T.organization_id AND fa.fixed_asset_id = T.fixed_asset_id
    set fa.increment_date = CONCAT(YEAR(fa.increment_date), '-01-01');

    UPDATE fixed_asset_ledger fal
    INNER JOIN tbOrganization o ON fal.organization_id = o.organization_id and fal.voucher_id = o.voucher_id
    set fal.change_date =  CONCAT(YEAR(fal.change_date), '-01-01'),
    fal.voucher_date = CONCAT(YEAR( fal.voucher_date), '-01-01');

    DROP TEMPORARY TABLE IF EXISTS tbOrganization;

END;


CALL Proc_Jira_UpdateIncrementDateTenant();