﻿-- Tài sản
SELECT fa.fixed_asset_id, fa.fixed_asset_code,fa.fixed_asset_type, fa.group_fixed_asset_category_id, fa.orgprice,  fa.depreciation_for_business_amount, fa.depreciation_amount, 
fa.accum_depreciation_amount, fa.remaining_amount, fa.fixed_asset_name,   fa.convert_circular_id, fa.public_asset_type, fa.organization_id, fa.quantity, fa.parent_id,  fa.is_parent, fa.fixed_asset_category_id, 
fa.fixed_asset_category_code, fa.fixed_asset_category_name, fa.department_id, fa.department_name, fa.status_id, fa.purchase_date, fa.increment_date, fa.used_date, fa.software_start_time, fa.depreciation_for_business_price, fa.depreciation_for_business_time, fa.depreciation_for_business_remaining_time, fa.depreciation_for_business_remaining_amount, fa.price, 
fa.created_date, fa.department_code, fa.work_year, fa.decrement_date, fa.is_tranfer, fa.is_peculiarity, fa.status_sync , fa.orgprice_from_budget, fa.orgprice_from_other
FROM fixed_asset fa where fixed_asset_id = '5fbc5198-a6b0-4c29-bb11-b1be1ce3c1b1';

-- Ghi tăng - Detail
SELECT faid.fixed_asset_id, faid.fixed_asset_code, faid.fixed_asset_name, faid.voucher_id, faid.voucher_code, faid.organization_id, faid.department_id, faid.department_name, faid.fixed_asset_category_id, faid.fixed_asset_category_name, faid.orgprice, faid.depreciation_amount, faid.depreciation_for_business_amount, faid.accum_depreciation_amount, faid.remaining_amount, faid.depreciation_year, faid.depreciation_value, faid.depreciation_for_business_value, faid.quantity, faid.public_asset_type, faid.created_date 
FROM fixed_asset_increment_detail faid ;
-- HM - Detail
SELECT fadd.fixed_asset_id, fadd.fixed_asset_code, fadd.orgprice, fadd.voucher_id, fadd.voucher_code, fadd.voucher_date, fadd.organization_id, fadd.department_id, fadd.department_name, fadd.fixed_asset_category_id, fadd.fixed_asset_category_name, fadd.first_remaining_amount, fadd.depreciation_rate, fadd.depreciation_year, fadd.depreciation_business_year, fadd.depreciation_value, fadd.depreciation_for_business_value, fadd.depreciation_amount, fadd.depreciation_for_business_amount, fadd.accum_depreciation_amount, fadd.remaining_amount, fadd.quantity, fadd.public_asset_type, fadd.fixed_asset_type, fadd.remaining_number_of_year, fadd.parent_id, fadd.is_parent 
FROM fixed_asset_depreciation_detail fadd;
-- KH - Detail
SELECT fadbd.fixed_asset_id, fadbd.fixed_asset_code, fadbd.fixed_asset_name, fadbd.first_remaining_amount, fadbd.orgprice, fadbd.remaining_amount, fadbd.voucher_id, fadbd.voucher_code, fadbd.organization_id, fadbd.department_id, fadbd.department_name, fadbd.fixed_asset_category_id, fadbd.fixed_asset_category_name, fadbd.depreciation_for_business_remaining_amount, fadbd.depreciation_for_business_price, fadbd.depreciation_for_business_time, fadbd.depreciation_for_business_value, fadbd.depreciation_value, fadbd.depreciation_amount, fadbd.depreciation_for_business_amount, fadbd.accum_depreciation_amount, fadbd.quantity, fadbd.public_asset_type, fadbd.fixed_asset_type, fadbd.created_date 
FROM fixed_asset_depreciation_business_detail fadbd where fixed_asset_id = '30a59a4f-d0af-4086-a5ab-e6cd6c403333';

-- Ghi tăng - Ledger to 
SELECT fal.fixed_asset_id, fal.fixed_asset_code, fal.fixed_asset_type, fal.orgprice, fal.depreciation_year, fal.depreciation_value, fal.depreciation_for_business_value, fal.depreciation_amount, 
fal.depreciation_for_business_amount, fal.accum_depreciation_amount, fal.remaining_amount  , fal.depreciation_for_business_price, fal.depreciation_for_business_remaining_amount
FROM fixed_asset_ledger fal WHERE  fal.fixed_asset_id = 'a327c616-a6ea-417c-8bb0-7f9ec77cd7fa';

SELECT * FROM fixed_asset_revaluation far WHERE far.voucher_id = 'abd8020f-a7ee-4fdd-9a55-60e09c8f9e09';

-- Ghi tăng - Master
SELECT fai.voucher_id, fai.voucher_code, fai.voucher_date, fai.increment_date, fai.total_orgprice, fai.organization_id, fai.created_date 
FROM fixed_asset_increment fai;

SELECT * FROM fa_ledger_revaluation_detail flrd WHERE flrd.fixed_asset_id = '5fbc5198-a6b0-4c29-bb11-b1be1ce3c1b1';

SELECT fadd.fixed_asset_id, fadd.fixed_asset_code, fadd.orgprice, fadd.depreciation_rate, fadd.depreciation_year
FROM fixed_asset_depreciation_detail fadd WHERE fadd.orgprice = 0 AND fadd.depreciation_rate > 0 AND fadd.depreciation_year > 0;

UPDATE fixed_asset_depreciation_detail fadd
set fadd.orgprice = IFNULL(fadd.depreciation_year,0) / fadd.depreciation_rate
WHERE IFNULL(fadd.orgprice,0) = 0 AND fadd.depreciation_rate > 0 AND fadd.depreciation_year > 0;

UPDATE fixed_asset_ledger fal
INNER JOIN fixed_asset_depreciation_detail fadd ON fal.organization_id = fadd.organization_id AND fal.voucher_id = fadd.voucher_id and fal.fixed_asset_id = fadd.fixed_asset_id
set fal.orgprice = fadd.orgprice
WHERE fal.orgprice <> fadd.orgprice AND fal.voucher_type = 5;

SELECT fal.fixed_asset_id 
FROM fixed_asset_ledger fal 
WHERE fal.voucher_type IN (1,8) AND IFNULL(fal.orgprice,0) <> IFNULL(fal.accum_depreciation_amount,0) + IFNULL(fal.remaining_amount,0);

UPDATE fixed_asset_ledger fal
set fal.remaining_amount = IFNULL(fal.orgprice,0) - IFNULL(fal.accum_depreciation_amount,0)
WHERE fal.voucher_type IN (1,8) AND IFNULL(fal.orgprice,0) <> IFNULL(fal.accum_depreciation_amount,0) + IFNULL(fal.remaining_amount,0);

SELECT far.revaluation_type 
FROM fixed_asset_revaluation far
INNER JOIN (
SELECT fal.voucher_id, fal.organization_id, fal.fixed_asset_id FROM fixed_asset_ledger fal WHERE fal.difference_orgprice = 0
) T ON T.organization_id = far.organization_id and far.fixed_asset_id = T.fixed_asset_id;

SELECT * FROM fixed_asset_ledger fal WHERE fal.voucher_type = 2 AND fal.orgprice = 0;

SELECT * FROM 
(
SELECT fal.fixed_asset_id, fal.voucher_id, fal.orgprice, fal.accum_depreciation_amount, fal.remaining_amount, fal.voucher_type, 
row_number() OVER(PARTITION BY fixed_asset_id ORDER BY DATE(fal.change_date), fal.created_date) AS STT
FROM fixed_asset_ledger fal
) T WHERE T.STT = 1 AND T.voucher_type = 2 AND T.orgprice = 0;

SELECT fal.fixed_asset_id, fal.voucher_id, fal.voucher_type, fal.change_date,  fal.orgprice, fal.accum_depreciation_amount, fal.remaining_amount, fal.voucher_type, 
row_number() OVER(PARTITION BY fixed_asset_id ORDER BY DATE(fal.change_date), fal.created_date) AS STT
FROM fixed_asset_ledger fal WHERE fal.fixed_asset_id = '094c66a8-521e-4f04-92e7-24f83dd4e033';
SELECT * FROM fixed_asset_increment_detail faid WHERE faid.fixed_asset_id = '1be89c5c-43d9-474d-8092-9c4f508b9dbe';
SELECT * FROM fixed_asset_revaluation far;

UPDATE fixed_asset_ledger fal
INNER JOIN fixed_asset_increment_detail faid 
ON fal.organization_id = faid.organization_id and fal.voucher_id = faid.voucher_id and fal.fixed_asset_id = faid.fixed_asset_id AND fal.voucher_type IN (1,8)
set fal.orgprice = faid.orgprice, fal.accum_depreciation_amount = faid.accum_depreciation_amount, fal.remaining_amount = faid.remaining_amount
WHERE ifnull(fal.orgprice,0) = 0;

SELECT fal.fixed_asset_code, fal.fixed_asset_id, fal.organization_id, fal.voucher_type, fal.change_date, B.voucher_type AS voucher_type2, B.change_date AS  change_date2
FROM fixed_asset_ledger fal
INNER JOIN (
    SELECT * FROM fixed_asset_ledger fal WHERE fal.voucher_type not IN (1,8,2,17)
)  B ON fal.organization_id = B.organization_id AND B.fixed_asset_id = fal.fixed_asset_id 
WHERE fal.voucher_type IN (1,8) AND fal.change_date > B.change_date;


SELECT fal.fixed_asset_code, fal.fixed_asset_id, fal.organization_id, fal.software_start_time, fal.voucher_type, fal.change_date, B.voucher_type AS voucher_type2, B.change_date AS  change_date2
FROM fixed_asset_ledger fal
INNER JOIN (
    SELECT * FROM fixed_asset_ledger fal WHERE fal.voucher_type not IN (1,8,2,17)
)  B ON fal.organization_id = B.organization_id AND B.fixed_asset_id = fal.fixed_asset_id 
WHERE fal.voucher_type IN (1,8) AND fal.change_date > B.change_date;

-- --------------------------------------------- --------------------------------------------- --------------------------------------------- --------------------------------------------- --------------------------------------------- -------------------------------------------
-- Cập nhật HM
 UPDATE fixed_asset_ledger fal
 set fal.depreciation_value = 0
 WHERE fal.voucher_type = 5 AND fal.voucher_id = '2cfdb1b1-6fe3-4254-9c06-f4043b2ac862' and fal.fixed_asset_id = '9a0c042b-b03a-4d49-80d2-47214266436a';

 UPDATE fixed_asset_depreciation_detail fal
 set fal.depreciation_value = 0
 WHERE fal.voucher_id = '2cfdb1b1-6fe3-4254-9c06-f4043b2ac862' and fal.fixed_asset_id = '9a0c042b-b03a-4d49-80d2-47214266436a';

 UPDATE fixed_asset_ledger fal
 set fal.depreciation_value = 0, fal.accum_depreciation_amount = 120230000, fal.remaining_amount = 0
 WHERE fal.voucher_type IN (1,8) AND fal.fixed_asset_id = '5c0fd49b-5892-4fd0-a83e-1e563068f100';

 UPDATE fixed_asset_ledger fal
 set fal.depreciation_value = 0, fal.accum_depreciation_amount = fal.orgprice, fal.remaining_amount = 0
 WHERE fal.voucher_type = 2 and fal.remaining_amount < 0 AND fal.voucher_id = '1027353b-5a7c-4eec-a9ab-3ccff7679aa9'

-- Cập nhật KH
 UPDATE fixed_asset_ledger fal
 set fal.depreciation_for_business_value =413.059
 WHERE fal.voucher_type = 9 AND fal.voucher_id = '13aa82c5-14d9-42e0-a166-fc53f59b7161' and fal.fixed_asset_id = '086d6325-a953-4b87-9b14-478dbedbee0f' AND fal.remaining_amount < 0;

SELECT concat("CALL Proc_Jira_ReCallUpdateFAData('",fal.fixed_asset_id,"');") as script 
FROM fixed_asset_ledger fal
WHERE fal.voucher_type = 2 and fal.remaining_amount < 0 AND fal.organization_id = '815f0097-df84-4216-8903-fc6338c0bb0d'
GROUP BY fal.fixed_asset_id;

SELECT CONCAT("CALL Proc_Jira_Update_Depreciation_FixedAsset_From_GT('",do.organization_code,"','",fa.fixed_asset_code,"',",fal.orgprice,",",fal.accum_depreciation_amount,");") as script
FROM fixed_asset fa 
INNER JOIN fixed_asset_ledger fal on fa.organization_id = fal.organization_id AND fa.fixed_asset_id = fal.fixed_asset_id AND fal.voucher_type IN (1,8)
INNER JOIN dic_organization do on fa.organization_id = do.organization_id
WHERE fa.fixed_asset_id =  '29b622c6-2292-4caa-bbcf-64ef0b5850b8';

DELETE FROM fa_jira_execute;
INSERT  fa_jira_execute (organization_id, fixed_asset_id, type)
SELECT fa.organization_id, fa.fixed_asset_id, 0 AS type
FROM fixed_asset fa 
WHERE fa.remaining_amount < 0 AND IFNULL(fa.is_parent,0) = 0 AND fa.status_id <> 2
GROUP BY fa.organization_id, fa.fixed_asset_id;

SELECT * FROM fa_jira_execute;
DELETE FROM fa_jira_execute;

SELECT CONCAT("CALL Proc_Jira_Update_Depreciation_FixedAsset_From_GT('",do.organization_code,"','",fa.fixed_asset_code,"',",fal.orgprice,",",fal.accum_depreciation_amount,");") as script
FROM fixed_asset fa 
INNER JOIN fa_jira_execute B ON fa.organization_id = B.organization_id and fa.fixed_asset_id = B.fixed_asset_id
INNER JOIN fixed_asset_ledger fal on fa.organization_id = fal.organization_id AND fa.fixed_asset_id = fal.fixed_asset_id AND fal.voucher_type IN (1,8)
INNER JOIN dic_organization do on fa.organization_id = do.organization_id;

UPDATE fixed_asset_ledger fal
INNER JOIN fa_jira_execute fje on fal.organization_id = fje.organization_id and fal.fixed_asset_id = fje.fixed_asset_id
INNER JOIN fixed_asset_depreciation_detail fadd on fal.organization_id = fadd.organization_id and fal.voucher_id = fadd.voucher_id AND fal.fixed_asset_id = fadd.fixed_asset_id
set fal.depreciation_value = fadd.first_remaining_amount
WHERE fal.voucher_type = 5 AND fal.remaining_amount < 0;

UPDATE fixed_asset_ledger fal
INNER JOIN fa_jira_execute fje on fal.organization_id = fje.organization_id and fal.fixed_asset_id = fje.fixed_asset_id
INNER JOIN fixed_asset_depreciation_business_detail fadd on fal.organization_id = fadd.organization_id and fal.voucher_id = fadd.voucher_id AND fal.fixed_asset_id = fadd.fixed_asset_id
set fal.depreciation_for_business_value = fadd.first_remaining_amount
WHERE fal.voucher_type = 9 AND fal.remaining_amount < 0;

UPDATE fixed_asset_ledger fal
INNER JOIN fa_jira_execute fje on fal.organization_id = fje.organization_id and fal.fixed_asset_id = fje.fixed_asset_id
set fal.depreciation_value = 0,
fal.depreciation_for_business_value = 0,
fal.accum_depreciation_amount = 0
WHERE fal.voucher_type IN (1,8) AND fal.remaining_amount < 0 AND fal.organization_id = '23cc8d22-4758-4043-9cc3-381d29365ba4';

SELECT CONCAT("CALL Proc_Jira_Update_Depreciation_FixedAsset_From_GT('",do.organization_code,"','",fa.fixed_asset_code,"',",fal.orgprice,",",fal.accum_depreciation_amount,");") as script
FROM fixed_asset fa 
INNER JOIN fa_jira_execute B ON fa.organization_id = B.organization_id and fa.fixed_asset_id = B.fixed_asset_id
INNER JOIN fixed_asset_ledger fal on fa.organization_id = fal.organization_id AND fa.fixed_asset_id = fal.fixed_asset_id AND fal.voucher_type IN (1,8)
INNER JOIN dic_organization do on fa.organization_id = do.organization_id 
WHERE B.fixed_asset_id =  '7416e9aa-e061-4a76-a7c2-87f932a3eec4' ;

SELECT fa.fixed_asset_code , do.organization_code, fa.software_start_time
FROM fixed_asset fa 
INNER JOIN dic_organization do ON fa.organization_id = do.organization_id
WHERE fa.remaining_amount < 0 AND IFNULL(fa.is_parent,0) = 0 AND fa.status_id <> 2
ORDER BY do.organization_code;

UPDATE fixed_asset_ledger fal
INNER JOIN fa_jira_execute fje on fal.organization_id = fje.organization_id and fal.fixed_asset_id = fje.fixed_asset_id
set fal.depreciation_value =0
WHERE fal.voucher_type = 5 AND fal.remaining_amount < 0 AND fal.fixed_asset_id = '5ac31243-11dc-40ab-8f6a-6e5e5c60f28e';


UPDATE fixed_asset fa set fa.remaining_amount = 0 WHERE fa.organization_id = '2c7d341c-f546-4cfd-b33a-b02429d6695a'  AND fa.remaining_amount < 0;

CALL Proc_Jira_ReCallUpdateFAData('18db1c38-5160-422f-9850-2963bccef05b');

CALL Proc_Jira_Update_Revaluation_OrgpriceByOrgan('e91e35b5-1da1-446f-b195-4c4e95b1a314');

SELECT concat("CALL Proc_Jira_Update_Revaluation_OrgpriceByOrgan('",fa.organization_id,"');") as script
FROM fixed_asset fa 
WHERE fa.remaining_amount < 0 AND IFNULL(fa.is_parent,0) = 0 AND fa.status_id <> 2
GROUP BY fa.organization_id;

UPDATE fixed_asset fa
set fa.remaining_amount = 0 WHERE fa.organization_id = '4ff4e2a7-4202-45ce-9059-b2a6c8ba23bc' AND fa.remaining_amount < 0;

SELECT concat("CALL Proc_Jira_ReCallUpdateFAData('",fal.fixed_asset_id,"');") as script 
FROM fa_jira_execute fal
GROUP BY fal.fixed_asset_id;

UPDATE fixed_asset_ledger fal
INNER JOIN fa_jira_execute fje on fal.organization_id = fje.organization_id and fal.fixed_asset_id = fje.fixed_asset_id AND fal.voucher_type = 5
set fal.depreciation_value = 0
WHERE fal.remaining_amount < 0;


SELECT * FROM fixed_asset_revaluation far WHERE far.voucher_id = 'da91619d-886e-4f3e-9f57-ff52d1ce0bfa';

SELECT * FROM db_option do WHERE do.option_id = 'FAManageWithBarcode' AND do.option_value <> 0 AND do.description <> 'Loại mã vạch';

SELECT do.organization_code,  B.* 
FROM 
(
SELECT * FROM db_option do WHERE do.option_id = 'FAManageWithBarcode' AND do.option_value = 'TRUE'
) A INNER JOIN
(
     SELECT * FROM db_option do WHERE do.option_id = 'TypeCode' AND do.option_value = 0
) B on A.organization_id = B.organization_id
INNER JOIN dic_organization do on A.organization_id = do.organization_id;

-- Ghi tăng - Ledger to 
SELECT fal.fixed_asset_id, fal.fixed_asset_code, fal.fixed_asset_type, fal.orgprice, fal.depreciation_year, fal.depreciation_value, fal.depreciation_for_business_value, fal.depreciation_amount, 
fal.depreciation_for_business_amount, fal.accum_depreciation_amount, fal.remaining_amount  , fal.depreciation_for_business_price, fal.depreciation_for_business_remaining_amount
FROM fixed_asset_ledger fal WHERE fal.voucher_type = 1 and fal.depreciation_year = 0 AND fal.organization_id = '9b44664e-cb9a-4697-840f-825dc41dc1b4';


SELECT fal.fixed_asset_id
FROM fixed_asset_ledger fal
WHERE  fal.depreciation_year = 0 and fal.voucher_type = 1  AND fal.organization_id = '9b44664e-cb9a-4697-840f-825dc41dc1b4'
GROUP BY fal.fixed_asset_id;

UPDATE fixed_asset fa
INNER JOIN 
(
    SELECT fal.fixed_asset_id
    FROM fixed_asset_ledger fal
    WHERE  fal.depreciation_year = 0 and fal.voucher_type = 1  AND fal.organization_id = '9b44664e-cb9a-4697-840f-825dc41dc1b4'
    GROUP BY fal.fixed_asset_id
) B on B.fixed_asset_id = fa.fixed_asset_id
set fa.depreciation_year =  round(IFNULL(fa.orgprice,0)*IFNULL(fa.depreciation_rate,0));

UPDATE fixed_asset_ledger fa
INNER JOIN 
(
    SELECT fal.fixed_asset_id
    FROM fixed_asset_ledger fal
    WHERE  fal.depreciation_year = 0 and fal.voucher_type = 1  AND fal.organization_id = '9b44664e-cb9a-4697-840f-825dc41dc1b4'
    GROUP BY fal.fixed_asset_id
) B on B.fixed_asset_id = fa.fixed_asset_id
set fa.depreciation_year =  round(IFNULL(fa.orgprice,0)*IFNULL(fa.depreciation_rate,0)),
fa.depreciation_value = round(IFNULL(fa.orgprice,0)*IFNULL(fa.depreciation_rate,0));

SELECT fa.depreciation_rate, fa.orgprice 
FROM fixed_asset fa
INNER JOIN 
(
    SELECT fal.fixed_asset_id
    FROM fixed_asset_ledger fal
    WHERE  fal.depreciation_year = 0 and fal.voucher_type = 1  AND fal.organization_id = '9b44664e-cb9a-4697-840f-825dc41dc1b4'
    GROUP BY fal.fixed_asset_id
) B ON B.fixed_asset_id = fa.fixed_asset_id;
                                           
INSERT fa_jira_execute (organization_id, fixed_asset_id, TYPE)
SELECT UUID(), A.fixed_asset_id, 0 AS Type
FROM 
(
    SELECT fal.organization_id, fal.fixed_asset_id, fal.change_date, fal.created_date, fal.remaining_amount, fal.fixed_asset_code FROM fixed_asset_ledger fal WHERE fal.voucher_type = 5
) A 
INNER JOIN
(
    SELECT fli.organization_id, fli.fixed_asset_id, fli.change_date, fli.created_date, fli.remaining_amount FROM fa_ledger_inventory fli 
) B ON 
A.organization_id = B.organization_id
AND A.fixed_asset_id = B.fixed_asset_id 
AND  DATE(A.change_date) = DATE(B.change_date)
AND A.remaining_amount  <> B.remaining_amount
GROUP BY A.organization_id, A.fixed_asset_id;


SELECT * FROM fa_jira_execute fje WHERE fje.type = 1;

update equipment e set bar_code = e.id WHERE e.bar_code IS NULL;

SELECT * FROM jira_fixed_asset_survey jfas;

SELECT CONCAT('INSERT jira_fixed_asset_survey (fixed_asset_id) VALUES (uuid());','') AS Data;

DELETE FROM jira_fixed_asset_survey;

UPDATE fixed_asset_ledger fal
set  fal.depreciation_for_business_value =  198080
WHERE fal.voucher_id = '4af46127-9a8e-41a1-b59e-271ba15a0cb2' AND fal.fixed_asset_id = 'dcf2094d-267f-48a8-ba27-41939ea2cf25';

UPDATE fixed_asset_depreciation_business_detail fal
set fal.depreciation_for_business_value = 198080
WHERE fal.voucher_id = '4af46127-9a8e-41a1-b59e-271ba15a0cb2' AND fal.fixed_asset_id = 'dcf2094d-267f-48a8-ba27-41939ea2cf25';

CALL Proc_Jira_ReCallUpdateFAData('dcf2094d-267f-48a8-ba27-41939ea2cf25');


UPDATE equipment e
set e.bar_code = e.id WHERE ifnull(e.bar_code,0) = 0;

SELECT e.bar_code FROM equipment e;

SELECT * FROM equipment e WHERE e.bar_code;

SELECT bar_code FROM equipment e WHERE e.equipment_id = '839da30d-c84a-4a07-a829-1082bdb6e5ca';

SELECT fa.fixed_asset_code, do.organization_code
FROM jira_fa_focus a 
INNER JOIN fixed_asset fa ON a.fixed_asset_id = fa.fixed_asset_id
INNER JOIN dic_organization do on a.organization_id = do.organization_id;

SELECT fal.fixed_asset_code, do.organization_code 
FROM fixed_asset_ledger fal 
INNER JOIN dic_organization do on fal.organization_id = do.organization_id
WHERE fal.depreciation_for_business_value < 0 AND fal.remaining_amount > 0 and fal.voucher_type = 9
ORDER BY do.organization_code;

SELECT fal.fixed_asset_code, do.organization_code 
FROM fixed_asset_ledger fal 
INNER JOIN dic_organization do on fal.organization_id = do.organization_id
WHERE fal.depreciation_for_business_value < 0 AND fal.remaining_amount > 0 and fal.voucher_type = 9
group by fal.fixed_asset_code, do.organization_code
ORDER BY do.organization_code;

SELECT concat("CALL Proc_Jira_Update_HM_Value_FA('",fal.fixed_asset_id,"',",max(fal.depreciation_value),");") AS Data 
FROM fixed_asset_ledger fal 
INNER JOIN
(
    SELECT fal.fixed_asset_id
    FROM fixed_asset_ledger fal 
    WHERE fal.depreciation_value < 0 AND fal.remaining_amount > 0 and fal.voucher_type = 5
    GROUP BY fal.fixed_asset_id
) B ON  B.fixed_asset_id = fal.fixed_asset_id
WHERE  fal.voucher_type = 5
GROUP BY fal.fixed_asset_id;

SELECT * FROM license_info li WHERE li.budget_code = '1010396';

SELECT  concat("CALL Proc_Jira_ReCallUpdateFAData('",fal.fixed_asset_id,"');") as Data 
FROM fixed_asset_ledger fal
INNER JOIN fixed_asset_depreciation_detail fadd on fal.organization_id = fadd.organization_id and fal.voucher_id = fadd.voucher_id AND fal.fixed_asset_id = fadd.fixed_asset_id
WHERE fal.depreciation_value <> fadd.depreciation_value AND fal.voucher_type = 5
GROUP BY fadd.fixed_asset_id;

SELECT fa.status_id FROM fixed_asset fa WHERE fa.fixed_asset_id = '99dbea1d-6f50-4bd6-9c42-20b3575e6850';

UPDATE fixed_asset_ledger fal
INNER JOIN fixed_asset_depreciation_detail fadd on fal.organization_id = fadd.organization_id and fal.voucher_id = fadd.voucher_id AND fal.fixed_asset_id = fadd.fixed_asset_id
set fal.depreciation_value = fadd.depreciation_value
WHERE fal.depreciation_value <> fadd.depreciation_value AND fadd.organization_id = 'b4751a17-288d-42e5-9f2a-01532b6ce8bf';

CALL Proc_Jira_ReCallUpdateFAData('66adf0f2-abdc-4410-88e2-cd8ac3cdf222');

update fixed_asset fa1
INNER JOIN (
  SELECT
  SUM(IF(fa.status_id = 1, 1,0)) AS TotalDangSuDung,
  SUM(IF(fa.status_id = 2, 1,0)) AS TotalChuaGhiTang,
  SUM(IF(fa.status_id = 3, 1,0)) AS TotalDaGhiGiam,
  COUNT(*) AS Total,
  fa.parent_id
  FROM fixed_asset fa
  WHERE fa.parent_id IS NOT NULL
  GROUP BY fa.parent_id
) K ON fa1.fixed_asset_id = K.parent_id
SET fa1.status_id = CASE WHEN K.TotalDangSuDung > 0 THEN 1
                         WHEN K.TotalDaGhiGiam = K.Total THEN 3
                         WHEN K.TotalChuaGhiTang = K.Total THEN 2 ELSE fa1.status_id END
WHERE fa1.is_parent = 1
AND
(
 (fa1.status_id = 3 AND K.Total <> K.TotalDaGhiGiam)
 OR
 (fa1.status_id = 2 AND K.Total <> K.TotalChuaGhiTang)
 OR
 (fa1.status_id = 1 AND (K.TotalDaGhiGiam = K.Total OR K.TotalChuaGhiTang = K.Total))
);

UPDATE equipment_ledger_inventory A
INNER JOIN
(
    SELECT eli.organization_id, eli.voucher_id, MIN(eli.created_date) AS created_date 
    FROM equipment_ledger_inventory eli
    GROUP BY eli.organization_id, eli.voucher_id
) B  ON A.organization_id = B.organization_id AND A.voucher_id = B.voucher_id
set A.created_date = B.created_date
WHERE A.created_date <> B.created_date;

UPDATE equipment_ledger A
INNER JOIN
(
    SELECT eli.organization_id, eli.voucher_id, MAX(eli.created_date) AS created_date 
    FROM equipment_ledger eli
    WHERE eli.voucher_type = 2
    GROUP BY eli.organization_id, eli.voucher_id
) B  ON A.voucher_type = 2 AND A.organization_id = B.organization_id AND A.voucher_id = B.voucher_id
set A.created_date = B.created_date
WHERE A.voucher_type = 2 AND A.created_date <> B.created_date;

  UPDATE fixed_asset_ledger fal
  set fal.change_date = CASE WHEN fal.voucher_type IN (1,8) THEN DATE_FORMAT(fal.change_date,'%Y-%m-%d 12:00:00')
                                                    WHEN fal.voucher_type IN (9) THEN DATE_FORMAT(fal.change_date,'%Y-%m-%d 14:00:00')
                                                    WHEN fal.voucher_type IN (5) THEN DATE_FORMAT(fal.change_date,'%Y-%m-%d 16:00:00')
                                         END 
  WHERE fal.organization_id = $OrganizationID AND fal.voucher_type IN (1,5,8,9);

  UPDATE fa_ledger_inventory fal
  set fal.change_date = DATE_FORMAT(fal.change_date,'%Y-%m-%d 23:59:59')
  WHERE fal.organization_id = $OrganizationID;

UPDATE fixed_asset_ledger fad
INNER JOIN
(
     SELECT fal.organization_id, fal.voucher_id, MAX(fal.change_date)  AS change_date, MAX(fal.created_date) AS created_date
     FROM fixed_asset_ledger fal
     WHERE fal.voucher_type = 5
     GROUP BY fal.organization_id, fal.voucher_id
) B ON B.organization_id = fad.organization_id AND B.voucher_id = fad.voucher_id
set fad.change_date = B.change_date,
fad.created_date = B.created_date
WHERE fad.voucher_type = 5;

UPDATE fixed_asset_ledger fad
INNER JOIN
(
     SELECT fal.organization_id, fal.voucher_id, MAX(fal.change_date)  AS change_date, MAX(fal.created_date) AS created_date
     FROM fixed_asset_ledger fal
     WHERE fal.voucher_type = 9
     GROUP BY fal.organization_id, fal.voucher_id
) B ON B.organization_id = fad.organization_id AND B.voucher_id = fad.voucher_id
set fad.change_date = B.change_date,
fad.created_date = B.created_date
WHERE fad.voucher_type = 9;

select fa.fixed_asset_code, do.organization_code
from fixed_asset fa 
inner JOIN 
(
    select fal.organization_id, fal.fixed_asset_id, fal.remaining_amount, 
    row_number() over(partition by fixed_asset_id order by change_date desc, created_date desc, fal.fixed_asset_ledger_id DESC) rn 
    from fixed_asset_ledger fal
    WHERE fal.voucher_type <> 17
) tm on fa.organization_id = tm.organization_id and fa.fixed_asset_id = tm.fixed_asset_id and tm.rn = 1
INNER JOIN dic_organization do on fa.organization_id = do.organization_id 
where ifnull(fa.remaining_amount, 0) <> ifnull(tm.remaining_amount, 0) and ifnull(fa.is_parent, 0) = 0
GROUP BY fa.fixed_asset_code, do.organization_code;

SELECT * FROM user WHERE organization_id = 'd8b29f2d-8129-4aac-81b7-2ac471014c3f';

SELECT * FROM fixed_asset fa WHERE fa.organization_id = 'd8b29f2d-8129-4aac-81b7-2ac471014c3f';
SELECT * FROM activity_diary ad WHERE ad.organization_id = 'd8b29f2d-8129-4aac-81b7-2ac471014c3f';

SELECT * FROM fixed_asset_revaluation far WHERE far.description LIKE '%thông tư%';

SELECT * FROM fixed_asset_revaluation far WHERE far.description LIKE '%chuẩn hóa%';


DROP TEMPORARY TABLE IF EXISTS tbFixedAssetByVoucher;
CREATE TEMPORARY TABLE tbFixedAssetByVoucher
SELECT * FROM fixed_asset_ledger fal
WHERE fal.organization_id = $organ AND fal.voucher_id = $voucher_id;

DROP TEMPORARY TABLE IF EXISTS tbFixedAssetByOrgan;
CREATE TEMPORARY TABLE tbFixedAssetByOrgan
SELECT * FROM fixed_asset_ledger fal
WHERE fal.organization_id = $organ;

SELECT * 
FROM tbFixedAssetByVoucher a 
INNER JOIN  tbFixedAssetByOrgan b on a.organization_id = b.organization_id AND a.fixed_asset_id = b.fixed_asset_id
WHERE b.change_date > a.change_date ;

UPDATE fixed_asset fa set fa.quantity = 1 WHERE fa.fixed_asset_id = '94d7e227-bf56-4966-9437-e13f4729a023';

UPDATE fixed_asset_ledger fal INNER JOIN fixed_asset fa on fal.organization_id = fa.organization_id and fal.fixed_asset_id = fa.fixed_asset_id
set fal.quantity = fa.quantity
WHERE fa.quantity = 1 AND fa.organization_id ='8d2acb37-a59e-4b06-9dec-8ef277f1dc68' AND fal.quantity <> fa.quantity;

UPDATE fa_ledger_inventory fal INNER JOIN fixed_asset fa on fal.organization_id = fa.organization_id and fal.fixed_asset_id = fa.fixed_asset_id
set fal.quantity = fa.quantity
WHERE fa.quantity = 1 AND fa.organization_id ='8d2acb37-a59e-4b06-9dec-8ef277f1dc68' AND fal.quantity <> fa.quantity;

UPDATE fixed_asset_revaluation fal
SET fal.fixed_asset_revaluation_list = JSON_SET(fal.fixed_asset_revaluation_list,
 '$[0].new_data[0].depreciation_amount', 0,
 '$[0].old_data[0].depreciation_amount', 954570000,
 '$[0].change_data[0].depreciation_amount', -954570000,
 '$[0].new_data[0].accum_depreciation_amount', 0,
 '$[0].old_data[0].accum_depreciation_amount', 954570000,
 '$[0].change_data[0].accum_depreciation_amount', -954570000,
 '$[0].new_data[0].remaining_amount', 954570000,
 '$[0].old_data[0].remaining_amount', 0,
 '$[0].change_data[0].remaining_amount', 954570000
 )
WHERE fal.voucher_id = '60555475-16ef-43c1-8c1f-1ed42605621d';

UPDATE fixed_asset_ledger fal
set fal.depreciation_amount = 0, fal.accum_depreciation_amount = 0, fal.difference_depreciation_amount =  -954570000, fal.difference_remaining_amount = 954570000
WHERE fal.voucher_type = 2 AND fal.voucher_id = '60555475-16ef-43c1-8c1f-1ed42605621d';

CALL Proc_Jira_ReCallUpdateFAData('3a0ac966-7d45-4986-84c5-3e15240b4dff');

SELECT * FROM dic_organization do WHERE do.reporting_organization_code = '1040811';

SELECT * FROM user u INNER JOIN qlts_management.sharedconfig b ON tenant_id = b.tenant_id WHERE IFNULL(tenant_code,'') = '';

CALL Proc_Jira_ReCallUpdateFAData('7d1337a6-4f1d-4225-bbe2-ee056b75746d');

CALL Proc_Jira_Update_Depreciation_FixedAsset_From_GT('1018749', 'MA', 6000000, 4040000);

UPDATE user u set last_login_time = null WHERE tenant_id =  'ad04d936-2371-11ec-867c-005056b2173d' ;

SELECT fal.fixed_asset_ledger_id, fal.orgprice, fal.difference_orgprice FROM fixed_asset_ledger fal WHERE fal.voucher_type IN (2,8,1) and fal.fixed_asset_id = '';


CALL Proc_Jira_Update_Depreciation_FixedAsset_From_GT('1039635', 'ĐAT', 295160000, 0);

UPDATE fixed_asset_revaluation fal
SET fal.fixed_asset_revaluation_list = JSON_SET(fal.fixed_asset_revaluation_list,
 '$[0].new_data[0].depreciation_amount', 0,
 '$[0].old_data[0].depreciation_amount', 20,
 '$[0].change_data[0].depreciation_amount',-20,
 '$[0].new_data[0].accum_depreciation_amount',0,
 '$[0].old_data[0].accum_depreciation_amount', 20,
 '$[0].change_data[0].accum_depreciation_amount', -20,
 '$[0].new_data[0].remaining_amount', 72079000000,
 '$[0].old_data[0].remaining_amount', 36999999980,
 '$[0].change_data[0].remaining_amount', 35079000020
 )
WHERE fal.voucher_id = '733313c0-e16c-450f-a395-5200e6ff2846';

UPDATE fixed_asset_ledger fal
SET fal.accum_depreciation_amount = 0,
depreciation_amount = 0,
fal.difference_depreciation_amount = -20,
fal.difference_remaining_amount = 35079000020,
fal.remaining_amount = 72079000000 
WHERE voucher_id = '733313c0-e16c-450f-a395-5200e6ff2846';

CALL Proc_Jira_ReCallUpdateFAData('1fc954a5-07ed-4eac-aa30-90e0bcc3c8d1');

SELECT * FROM fixed_asset fa WHERE fa.organization_id = '23087417-b1f6-43bc-82ad-b9b9a26d2064' AND fa.fixed_asset_code = 'MĐB PTTH';

CALL Proc_Jira_Update_Depreciation_FixedAsset_From_GT('1079692', 'TS43', 4620000, 4620000);

SELECT * FROM 
(
SELECT fal.voucher_code, fal.change_date, fal.created_date, fal.fixed_asset_ledger_id 
FROM fixed_asset_ledger fal 
WHERE fal.fixed_asset_id = 'e9766e73-e17e-4d6a-9cf0-591ca57fcf76'
UNION ALL
SELECT fal.voucher_code, fal.change_date, fal.created_date, fal.fixed_asset_ledger_id 
FROM fa_ledger_inventory fal 
WHERE fal.fixed_asset_id = 'e9766e73-e17e-4d6a-9cf0-591ca57fcf76'
) A
ORDER BY A.change_date DESC, A.created_date DESC , A.fixed_asset_ledger_id DESC;

SELECT CAST(argument AS char)  AS Data
FROM mysql.general_log
WHERE  argument LIKE 'CALL%'
ORDER BY event_time DESC
LIMIT 0, 1000;


UPDATE fixed_asset fa
INNER JOIN (SELECT
    fixed_asset_id,
    organization_id,
    remaining_number_of_year,
    ROW_NUMBER() OVER (PARTITION BY fixed_asset_id
    ORDER BY change_date DESC, created_date DESC) AS rn
  FROM fixed_asset_ledger) l
  ON fa.fixed_asset_id = l.fixed_asset_id
  AND fa.organization_id = l.organization_id
  AND fa.status_id != 3
  AND l.rn = 1
  AND fa.depreciation_year > 0 
  AND fa.remaining_number_of_year != l.remaining_number_of_year
  AND CEILING(fa.remaining_amount / fa.depreciation_year) != fa.remaining_number_of_year
  AND CEILING(fa.remaining_amount / fa.depreciation_year) = l.remaining_number_of_year
SET fa.remaining_number_of_year = l.remaining_number_of_year,
    fa.modified_date = NOW(),
    fa.modified_by = CONCAT('fix-jira-38830-', fa.remaining_number_of_year);

SELECT * FROM license_info li WHERE li.budget_code = '121';

UPDATE license_info li
set li.order_descriptor = '<OrderDescriptor><ProductPackCode>QLTS.ORG</ProductPackCode><Internal_Log>AMIS_SUMAN_Func_RefineProductPackCodeForSubscriber</Internal_Log><StartDate>30/01/2024</StartDate><Duration>12</Duration><ExpiredDate>29/04/2025</ExpiredDate><ApplicationURL>kiengiang.qlts.vn</ApplicationURL></OrderDescriptor>'
WHERE li.budget_code = '121';

SELECT fal.fixed_asset_id 
FROM fixed_asset_ledger fal
WHERE IFNULL(fal.orgprice,0) <> IFNULL(fal.orgprice_from_budget, 0) + IFNULL(fal.orgprice_from_other, 0);

UPDATE fixed_asset_ledger fal
set fal.orgprice_from_other = 0
WHERE  IFNULL(fal.orgprice,0) = IFNULL(fal.orgprice_from_budget, 0) ;


SELECT fal.fixed_asset_id
FROM fixed_asset_ledger fal
INNER JOIN 
(SELECT * FROM convert_circular cc ORDER BY cc.convert_circular_id DESC LIMIT 1) B 
ON fal.convert_circular_id = B.convert_circular_id
LEFT JOIN dic_fixed_asset_category dfac on fal.organization_id = dfac.organization_id AND fal.fixed_asset_category_id = dfac.fixed_asset_category_id
LEFT JOIN dic_fixed_asset_category dfac1 ON dfac1.organization_id is NULL AND fal.fixed_asset_category_id = dfac1.fixed_asset_category_id
WHERE YEAR(fal.change_date) >= B.effect_year AND fal.depreciation_rate <> COALESCE(dfac.depreciation_rate, dfac1.depreciation_rate);

UPDATE fixed_asset_ledger fal
INNER JOIN 
(SELECT * FROM convert_circular cc ORDER BY cc.convert_circular_id DESC LIMIT 1) B
ON fal.convert_circular_id = B.convert_circular_id
LEFT JOIN dic_fixed_asset_category dfac on fal.organization_id = dfac.organization_id AND fal.fixed_asset_category_id = dfac.fixed_asset_category_id
LEFT JOIN dic_fixed_asset_category dfac1 ON dfac1.organization_id is NULL AND fal.fixed_asset_category_id = dfac1.fixed_asset_category_id
set fal.depreciation_rate = COALESCE(dfac.depreciation_rate, dfac1.depreciation_rate)
WHERE YEAR(fal.change_date) >= B.effect_year AND  fal.depreciation_rate <> COALESCE(dfac.depreciation_rate, dfac1.depreciation_rate);

UPDATE fixed_asset fa
set fa.quantity = 1 
WHERE fa.organization_id = 'c85413e1-cd2c-4994-935b-56b0990aeb5d' and fa.quantity = 0;

UPDATE fixed_asset_ledger fal
INNER JOIN fixed_asset fa on fal.organization_id = fa.organization_id AND fal.fixed_asset_id = fa.fixed_asset_id
set fal.quantity = fa.quantity
WHERE fa.organization_id = 'c85413e1-cd2c-4994-935b-56b0990aeb5d' AND fal.quantity = 0;

UPDATE fa_ledger_inventory fal
INNER JOIN fixed_asset fa on fal.organization_id = fa.organization_id AND fal.fixed_asset_id = fa.fixed_asset_id
set fal.quantity = fa.quantity
WHERE fa.organization_id = 'c85413e1-cd2c-4994-935b-56b0990aeb5d' AND fal.quantity = 0;

UPDATE dic_fixed_asset_category dfac
set dfac.orgprice_min = 5000000, dfac.orgprice_max = 1000000;

SELECT * FROM fixed_asset_change_category facc;

SELECT * FROM db_option do WHERE do.option_id = 'ConfirmPaySuccess';

UPDATE db_option do
set do.option_value = 'true'
WHERE do.option_id = 'ConfirmPaySuccess';

SELECT count(*) as Total
FROM fixed_asset_ledger fal
WHERE fal.voucher_type = 2
GROUP BY fal.organization_id, fal.fixed_asset_id, fal.voucher_code, fal.orgprice, fal.accum_depreciation_amount, fal.remaining_amount
HAVING count(*) > 1;

SELECT fal.fixed_asset_code, do.organization_code, count(*) 
FROM fixed_asset_ledger fal
INNER JOIN dic_organization do on fal.organization_id = do.organization_id
WHERE fal.voucher_type = 2
GROUP BY fal.organization_id, do.organization_code, fal.fixed_asset_id,fal.fixed_asset_code, fal.voucher_code, fal.orgprice, fal.accum_depreciation_amount, fal.remaining_amount
HAVING count(*) > 1
ORDER BY do.organization_code;


SELECT do.organization_code as 'Mã QHNS', 
do.organization_name AS 'Tên đơn vị', 
max(fa.TotalFA) AS 'Tổng Tài sản',
SUM(if(MONTH(ad.created_date) = 3 AND YEAR(ad.created_date) = 2024, 1, 0)) AS 'Tổng action tháng 03/2024' ,
SUM(if(MONTH(ad.created_date) = 2 AND YEAR(ad.created_date) = 2024, 1, 0)) AS 'Tổng action tháng 02/2024' ,
SUM(if(MONTH(ad.created_date) = 1 AND YEAR(ad.created_date) = 2024, 1, 0)) AS 'Tổng action tháng 01/2024' ,
SUM(if(MONTH(ad.created_date) = 12 AND YEAR(ad.created_date) = 2023, 1, 0)) AS 'Tổng action tháng 12/2023' ,
SUM(if(MONTH(ad.created_date) = 11 AND YEAR(ad.created_date) = 2023, 1, 0)) AS 'Tổng action tháng 11/2023' ,
SUM(if(MONTH(ad.created_date) = 10 AND YEAR(ad.created_date) = 2023, 1, 0)) AS 'Tổng action tháng 10/2023' ,
SUM(if(MONTH(ad.created_date) = 9 AND YEAR(ad.created_date) = 2023, 1, 0)) AS 'Tổng action tháng 09/2023' ,
SUM(if(MONTH(ad.created_date) = 8 AND YEAR(ad.created_date) = 2023, 1, 0)) AS 'Tổng action tháng 08/2023' ,
SUM(if(MONTH(ad.created_date) = 7 AND YEAR(ad.created_date) = 2023, 1, 0)) AS 'Tổng action tháng 07/2023' ,
SUM(if(MONTH(ad.created_date) = 6 AND YEAR(ad.created_date) = 2023, 1, 0)) AS 'Tổng action tháng 06/2023' 
FROM dic_organization do
LEFT JOIN 
(SELECT fa.organization_id, COUNT(1) as TotalFA FROM fixed_asset fa WHERE IFNULL(fa.is_parent,0) = 0 GROUP BY fa.organization_id) fa 
ON do.organization_id = fa.organization_id
LEFT JOIN activity_diary ad on do.organization_id = ad.organization_id
GROUP BY do.organization_code, do.organization_name;

UPDATE fixed_asset fa
set fa.fixed_asset_name = 'Nhà làm việc',
fa.orgprice = 565724000
WHERE fa.fixed_asset_id = '9affa8b3-cec4-4ea4-91df-508228d7a420';

SELECT * FROM user u WHERE u.organization_id = '12b63fa3-3712-43a1-b2c8-e014a0e83e69';

SELECT * FROM fixed_asset fa WHERE fa.organization_id = '12b63fa3-3712-43a1-b2c8-e014a0e83e69';

CALL Proc_Jira_Update_Depreciation_FixedAsset_From_GT('087c7952-fd0b-418b-ab03-efcc616e06bb', 250000000,225000000);

SELECT o.organization_code
FROM dic_organization o 
left join user a on a.organization_id = o.organization_id
where a.organization_id  is null;

UPDATE fixed_asset fa
LEFT JOIN dic_fixed_asset_category dfac ON fa.organization_id = dfac.organization_id and fa.fixed_asset_category_id = dfac.fixed_asset_category_id
LEFT JOIN dic_fixed_asset_category dfac1 ON dfac1.organization_id IS NULL AND fa.fixed_asset_category_id = dfac1.fixed_asset_category_id
set fa.public_asset_type = 
CASE WHEN ifnull(dfac.group_fixed_asset_category_id, dfac1.group_fixed_asset_category_id) = 1 THEN 1
        WHEN ifnull(dfac.group_fixed_asset_category_id, dfac1.group_fixed_asset_category_id) = 2 THEN 2
        WHEN ifnull(dfac.group_fixed_asset_category_id, dfac1.group_fixed_asset_category_id) = 4 THEN 3
        WHEN ifnull(dfac.group_fixed_asset_category_id, dfac1.group_fixed_asset_category_id) NOT IN (1,2,4) AND ifnull(fa.orgprice,0) >= 500000000 THEN 4
        WHEN ifnull(dfac.group_fixed_asset_category_id, dfac1.group_fixed_asset_category_id) NOT IN (1,2,4) AND ifnull(fa.orgprice,0) < 500000000 THEN 0
END
WHERE ifnull(dfac.group_fixed_asset_category_id, dfac1.group_fixed_asset_category_id) is NOT NULL AND IFNULL(fa.is_parent,0) = 0 AND
( 
    ( ifnull(dfac.group_fixed_asset_category_id, dfac1.group_fixed_asset_category_id) = 1 AND fa.public_asset_type <> 1)
    OR
    (ifnull(dfac.group_fixed_asset_category_id, dfac1.group_fixed_asset_category_id) = 2 AND fa.public_asset_type <> 2)
    OR
    (ifnull(dfac.group_fixed_asset_category_id, dfac1.group_fixed_asset_category_id) = 4 AND fa.public_asset_type <> 3)
    OR
    (ifnull(dfac.group_fixed_asset_category_id, dfac1.group_fixed_asset_category_id) NOT IN (1,2,4) AND ifnull(fa.orgprice,0) >= 500000000 AND fa.public_asset_type <> 4)
    OR
    (ifnull(dfac.group_fixed_asset_category_id, dfac1.group_fixed_asset_category_id) NOT IN (1,2,4) AND ifnull(fa.orgprice,0) < 500000000 AND fa.public_asset_type <> 0)
    OR
    fa.public_asset_type IS NULL
);

SELECT * FROM convert_circular cc;
SELECT * FROM dic_fixed_asset_category dfac WHERE dfac.convert_circular_id = 4;

SELECT * FROM 
(
SELECT dfac.* ,
row_number() OVER(PARTITION BY dfac.fixed_asset_category_master_id ORDER BY dfac.organization_id DESC) AS STT
FROM dic_fixed_asset_category dfac
INNER JOIN dic_fixed_asset_category_master dfacm on dfacm.fixed_asset_category_master_id = dfac.fixed_asset_category_master_id
WHERE dfac.organization_id is null OR dfac.organization_id = 'a1260f39-356e-4134-a5af-c3551b4f8a8d'
) A 
WHERE A.STT = 1;

SELECT * FROM dic_fixed_asset_category dfac
LEFT JOIN dic_fixed_asset_category_master dfacm on dfac.fixed_asset_category_master_id = dfacm.fixed_asset_category_master_id
WHERE dfacm.fixed_asset_category_master_id is NULL

select * from user
where misa_id is not null and misa_id <> '' and is_verified = 0
and email not like '%qlts.vn%'
order by created_date desc;

UPDATE user u
set u.is_verified = 1
WHERE misa_id is not null and misa_id <> '' and is_verified = 0
and email not like '%qlts.vn%';

SELECT fa.convert_circular_id FROM fixed_asset fa WHERE fa.fixed_asset_name LIKE '%Phần mềm kiểm định chất lượng%' AND fa.organization_id = '724997bb-aa62-45c7-80c3-b657cf6ba111';

SELECT * FROM convert_circular_history cch WHERE cch.convert_circular_id = 5 and cch.organization_id ='724997bb-aa62-45c7-80c3-b657cf6ba111' ORDER BY cch.created_date LIMIT 3;

SELECT * FROM user u WHERE u.organization_code = '1091550';

SELECT * FROM convert_circular cc;
SELECT * FROM convert_circular_history cch WHERE cch.fixed_asset_id = '3f9f275b-d9d4-4222-a3e5-26340245a206';
SELECT fa.convert_circular_id, fa.fixed_asset_category_id, fa.status_id, fa.software_start_time FROM fixed_asset fa WHERE fa.fixed_asset_id = '3f9f275b-d9d4-4222-a3e5-26340245a206';
SELECT * FROM dic_fixed_asset_category dfac WHERE dfac.fixed_asset_category_id = '73b52140-b3eb-4ce8-9a26-d4c8e868e20b';

SELECT * FROM dic_fixed_asset_category_master dfacm WHERE dfacm.fixed_asset_category_master_id = 'e71b15ad-932d-4a16-b9de-bbd09b8112a2';
SELECT * FROM dic_fixed_asset_category_master dfacm WHERE dfacm.fixed_asset_category_master_id = 'e71b15ad-932d-4a16-b9de-bbd09b8112a2';

SELECT fa.decrement_date, fa.fixed_asset_code, fa.convert_circular_id, fa.fixed_asset_category_id, fa.status_id, fa.software_start_time, fixed_asset_name 
FROM fixed_asset fa WHERE fa.fixed_asset_id = '3f9f275b-d9d4-4222-a3e5-26340245a206';


