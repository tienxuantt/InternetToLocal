﻿SET NAMES 'utf8';
DROP PROCEDURE IF EXISTS Proc_Jira_UpdateFirstRemainingAmountLedgerFA;

CREATE PROCEDURE Proc_Jira_UpdateFirstRemainingAmountLedgerFA (IN $Voucher_id varchar(36), IN $FixedAssetID varchar(36))
BEGIN

  DECLARE $STT_Current int DEFAULT 0;
  DECLARE $revaluation_type int DEFAULT 0;
  DECLARE $fixed_asset_type int DEFAULT 0;
  DECLARE $OrgPrice decimal(19, 4) DEFAULT 0;
  DECLARE $Accum decimal(19, 4) DEFAULT 0;
  DECLARE $AccumLedger decimal(19, 4) DEFAULT 0;
  DECLARE $Remaining decimal(19, 4) DEFAULT 0;

  SET group_concat_max_len = 18446744073709551615;

  DROP TEMPORARY TABLE IF EXISTS tbOrginLedgerData;
  CREATE TEMPORARY TABLE tbOrginLedgerData
  SELECT
    *,
    ROW_NUMBER() OVER (PARTITION BY fixed_asset_id
    ORDER BY A.change_date, A.created_date) AS STT
  FROM (SELECT
      lg.voucher_id,
      lg.fixed_asset_id,
      lg.change_date,
      lg.created_date,
      lg.orgprice,
      lg.accum_depreciation_amount,
      lg.remaining_amount
    FROM fixed_asset_ledger lg
    WHERE lg.fixed_asset_id = $FixedAssetID
    AND lg.voucher_type <> 17
    UNION ALL
    SELECT
      voucher_id,
      fixed_asset_id,
      change_date,
      created_date,
      orgprice,
      accum_depreciation_amount,
      remaining_amount
    FROM fa_ledger_inventory
    WHERE fixed_asset_id = $FixedAssetID) A;

  -- Lấy ra STT hiện tại
  SET $STT_Current = (SELECT
      STT
    FROM tbOrginLedgerData
    WHERE voucher_id = $Voucher_id LIMIT 1);

  -- Lấy ra bản ghi trước đó
  SELECT
    orgprice,
    accum_depreciation_amount,
    remaining_amount INTO $OrgPrice, $Accum, $Remaining
  FROM tbOrginLedgerData
  WHERE STT = $STT_Current - 1
  LIMIT 1;
         
  UPDATE fixed_asset_depreciation_detail fadd
  set fadd.first_remaining_amount = ifnull($Remaining,0)
  WHERE fadd.voucher_id = $Voucher_id AND fadd.fixed_asset_id = $FixedAssetID;

  DROP TEMPORARY TABLE IF EXISTS tbOrginLedgerData;
        
END;