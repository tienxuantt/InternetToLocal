﻿SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_GetScriptUpdateOrgprice;

CREATE PROCEDURE Proc_Jira_GetScriptUpdateOrgprice (IN $OrganizationID varchar(36), IN $FixedAssetID varchar(36))
SQL SECURITY INVOKER
BEGIN

    DECLARE $OrgPrice decimal(19,4) DEFAULT 0;
    DECLARE $FirstRemain decimal(19,4) DEFAULT 0;
    DECLARE $Accum decimal(19,4) DEFAULT 0;

    DROP TEMPORARY TABLE IF EXISTS tbOrginData;
    CREATE TEMPORARY TABLE tbOrginData
    SELECT
        *,
        ROW_NUMBER() OVER (PARTITION BY fixed_asset_id ORDER BY DATE(A.change_date), A.created_date
        ) AS STT
    FROM (SELECT
            A.organization_id,
            fixed_asset_ledger_id,
            A.fixed_asset_id,
            voucher_id,
            voucher_code,
            voucher_type,
            change_date,
            created_date,
            orgprice,
            CASE WHEN voucher_type = 9 THEN IFNULL(depreciation_for_business_value, 0) ELSE IF(voucher_type = 5, IFNULL(depreciation_value, 0), 0) END AS voucher_price,
            CASE WHEN voucher_type = 9 THEN IFNULL(depreciation_for_business_value, 0) ELSE IF(voucher_type = 5, IFNULL(depreciation_value, 0), 0) END AS depreciation_value,
            accum_depreciation_amount,
            remaining_amount
        FROM fixed_asset_ledger  A
        WHERE voucher_type <> 17 AND A.organization_id = $OrganizationID and A.fixed_asset_id = $FixedAssetID
        UNION ALL
        SELECT
            A.organization_id,
            fixed_asset_ledger_id,
            A.fixed_asset_id,
            voucher_id,
            voucher_code,
            voucher_type,
            change_date,
            created_date,
            orgprice,
            depreciation_value AS voucher_price,
            depreciation_value,
            accum_depreciation_amount,
            remaining_amount
        FROM fa_ledger_inventory A  
        WHERE A.organization_id = $OrganizationID and A.fixed_asset_id = $FixedAssetID
        ) A;

        DROP TEMPORARY TABLE IF EXISTS tbOrginDataLedger;
        CREATE TEMPORARY TABLE tbOrginDataLedger
        SELECT fadd.* 
        FROM fixed_asset_depreciation_detail fadd
        INNER JOIN tbOrginData B ON fadd.organization_id = B.organization_id AND fadd.voucher_id = B.voucher_id and fadd.fixed_asset_id = B.fixed_asset_id
        WHERE B.STT IN (2,3) AND ifnull(fadd.orgprice,0) > 0
        ORDER BY B.STT
        LIMIT 1; 

        INSERT tbOrginDataSum(SCRIPT)
        SELECT Concat("CALL Proc_Jira_Update_Depreciation_FixedAsset('",do.organization_code,"', '",fa.fixed_asset_code,"', ",ifnull(a.orgprice,0),", ",IFNULL(a.orgprice,0) - IFNULL(a.first_remaining_amount,0),");") AS SCRIPT
        FROM tbOrginDataLedger a
        INNER JOIN dic_organization do ON a.organization_id = do.organization_id
        INNER JOIN fixed_asset fa ON a.organization_id = fa.organization_id and a.fixed_asset_id = fa.fixed_asset_id;
                                       
    DROP TEMPORARY TABLE IF EXISTS tbOrginData;
    DROP TEMPORARY TABLE IF EXISTS tbOrginDataLedger;
END;


SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_GetScriptUpdateOrgpriceTenant;

CREATE PROCEDURE Proc_Jira_GetScriptUpdateOrgpriceTenant ()
SQL SECURITY INVOKER
BEGIN
    DECLARE $i int DEFAULT 0;
    DECLARE $count int DEFAULT 0;
    DECLARE $organID varchar(36) DEFAULT '';
    DECLARE $fixedAssetID varchar(36) DEFAULT '';

    DROP TEMPORARY TABLE IF EXISTS tbOrginDataSum;
    CREATE TEMPORARY TABLE tbOrginDataSum
    SELECT 'CALL Proc_Jira_GetScriptUpdateOrgprice($organID, $fixedAssetID); CALL Proc_Jira_GetScriptUpdateOrgprice($organID, $fixedAssetID);' AS SCRIPT
    WHERE 1 = 0;

    DROP TEMPORARY TABLE IF EXISTS tbOrganization;
    CREATE TEMPORARY TABLE tbOrganization
    SELECT
    a.organization_id,
    a.fixed_asset_id
    FROM fixed_asset_ledger a
    INNER JOIN fixed_asset fa on a.organization_id = fa.organization_id and a.fixed_asset_id = fa.fixed_asset_id
    WHERE a.voucher_type IN (1,8) AND  ifnull(a.orgprice,0) = 0 AND IFNULL(fa.remaining_amount,0) < 0 
    GROUP BY a.organization_id, a.fixed_asset_id;
                                 
    SELECT
        COUNT(1) INTO $count
    FROM tbOrganization;

    WHILE $i < $count DO
        SELECT
            organization_id, fixed_asset_id INTO $organID,  $fixedAssetID
        FROM tbOrganization
        LIMIT $i, 1;

        CALL Proc_Jira_GetScriptUpdateOrgprice($organID, $fixedAssetID);

        SET $i = $i + 1;
    END WHILE;

    SELECT * FROM tbOrginDataSum;

    DROP TEMPORARY TABLE IF EXISTS tbOrganization;
    DROP TEMPORARY TABLE IF EXISTS tbOrginDataSum;

END;

CALL Proc_Jira_GetScriptUpdateOrgpriceTenant();