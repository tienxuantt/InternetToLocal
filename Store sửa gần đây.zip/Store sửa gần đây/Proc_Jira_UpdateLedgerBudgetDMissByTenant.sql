﻿SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_UpdateLedgerBudgetDMissByTenant;

CREATE PROCEDURE Proc_Jira_UpdateLedgerBudgetDMissByTenant ()
SQL SECURITY INVOKER
BEGIN
    DECLARE $i int DEFAULT 0;
    DECLARE $count int DEFAULT 0;
    DECLARE $organID varchar(36) DEFAULT '';
    DECLARE $fixedAssetID varchar(36) DEFAULT '';

    DROP TEMPORARY TABLE IF EXISTS tbOrganization;
    CREATE TEMPORARY TABLE tbOrganization
    SELECT
    a.organization_id,
    a.fixed_asset_id
    FROM fixed_asset a
    LEFT JOIN
    (
        SELECT fixed_asset_id
         FROM ledger_budget
         GROUP BY fixed_asset_id
    ) b ON a.fixed_asset_id = b.fixed_asset_id
    WHERE IFNULL(a.is_parent,0) = 0 AND b.fixed_asset_id IS NULL AND a.status_id <> 2
    GROUP BY a.organization_id, a.fixed_asset_id;
                                 
    SELECT
        COUNT(1) INTO $count
    FROM tbOrganization;

    WHILE $i < $count DO
        SELECT
            organization_id, fixed_asset_id INTO $organID,  $fixedAssetID
        FROM tbOrganization
        LIMIT $i, 1;

        CALL Proc_Jira_UpdateLedgerBudgetDMiss($organID, $fixedAssetID);

        SET $i = $i + 1;
    END WHILE;

    DROP TEMPORARY TABLE IF EXISTS tbOrganization;

END;

CALL Proc_Jira_UpdateLedgerBudgetDMissByTenant();

