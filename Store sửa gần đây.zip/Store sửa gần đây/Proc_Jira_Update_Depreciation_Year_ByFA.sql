﻿SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_Update_Depreciation_Year_ByFA;

CREATE PROCEDURE Proc_Jira_Update_Depreciation_Year_ByFA (IN $fixed_asset_id varchar(36))
SQL SECURITY INVOKER
BEGIN
  
        UPDATE  fixed_asset fa
        INNER JOIN 
        (
              SELECT
              fal.organization_id,
              fal.fixed_asset_id,
              fal.voucher_id,
              fal.depreciation_year,
              ROW_NUMBER() OVER (PARTITION BY  fixed_asset_id ORDER BY fal.change_date DESC, fal.created_date DESC) rn
            FROM fixed_asset_ledger fal
            WHERE voucher_type = 2
        ) B on B.organization_id = fa.organization_id AND fa.fixed_asset_id = B.fixed_asset_id AND B.rn = 1
        INNER JOIN fixed_asset_revaluation far ON fa.fixed_asset_id = far.fixed_asset_id AND B.voucher_id = far.voucher_id
        set fa.depreciation_year =  far.fixed_asset_revaluation_list ->> '$[0].new_data[0].depreciation_year'
        WHERE fa.fixed_asset_id = $fixed_asset_id  AND  YEAR(far.revaluation_date) = 2023 AND JSON_VALID(far.fixed_asset_revaluation_list) = 1 AND fa.depreciation_year <> far.fixed_asset_revaluation_list ->> '$[0].new_data[0].depreciation_year';
        
END;

SELECT concat("CALL Proc_Jira_Update_Depreciation_Year_ByFA('",fa.fixed_asset_id,"');") as Data 
FROM  fixed_asset fa
INNER JOIN dic_organization do on fa.organization_id = do.organization_id
INNER JOIN 
(
      SELECT
      fal.organization_id,
      fal.fixed_asset_id,
      fal.voucher_id,
      fal.depreciation_year,
      ROW_NUMBER() OVER (PARTITION BY  fixed_asset_id ORDER BY fal.change_date DESC, fal.created_date DESC) rn
    FROM fixed_asset_ledger fal
    WHERE voucher_type = 2
) B on B.organization_id = fa.organization_id AND fa.fixed_asset_id = B.fixed_asset_id AND B.rn = 1
INNER JOIN fixed_asset_revaluation far ON fa.fixed_asset_id = far.fixed_asset_id AND B.voucher_id = far.voucher_id
WHERE YEAR(far.revaluation_date) = 2023 AND fa.depreciation_year <> far.fixed_asset_revaluation_list ->> '$[0].new_data[0].depreciation_year'
ORDER BY do.organization_code;