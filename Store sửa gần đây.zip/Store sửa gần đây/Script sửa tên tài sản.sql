﻿DROP TEMPORARY TABLE IF EXISTS tempFA;

CREATE TEMPORARY TABLE tempFA (
  oldcode nvarchar(100),
  name nvarchar(100)
);

INSERT INTO tempFA
VALUES ('TV.03', 'Máy tính HPPro400G2 - Máy tính HPPro400G3'),
('TV.04', 'Máy tính HP3330');


SELECT CONCAT("UPDATE ",c.TABLE_NAME," fa SET fa.fixed_asset_name = '",r.name,"' where fa.fixed_asset_id ='", r.fixed_asset_id,"';") AS Data
FROM information_schema.COLUMNS c
CROSS JOIN (
SELECT
  fa.fixed_asset_id,name
FROM fixed_asset fa
  INNER JOIN tempFA f
    ON f.oldcode = fa.fixed_asset_code
WHERE fa.organization_id ='816f7ab2-ed76-4495-966e-7d5cd27a7b5d'
) AS r
WHERE c.TABLE_SCHEMA = 'qlts_hanoi_asset' AND c.COLUMN_NAME = 'fixed_asset_name'
AND (SELECT TRUE FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = c.TABLE_NAME AND COLUMN_NAME = "fixed_asset_id" LIMIT 1) = TRUE;

