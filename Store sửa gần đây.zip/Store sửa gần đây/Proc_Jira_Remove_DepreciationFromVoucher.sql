﻿SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_Remove_DepreciationFromVoucher;

CREATE PROCEDURE Proc_Jira_Remove_DepreciationFromVoucher (IN $voucher_id varchar(36), IN $fixed_asset_id varchar(36))
SQL SECURITY INVOKER
BEGIN

    DECLARE $organ_id varchar(36);

    SELECT
        fa.organization_id INTO $organ_id
    FROM fixed_asset fa
    WHERE fa.fixed_asset_id = $fixed_asset_id LIMIT 1;

    DELETE A FROM
    fixed_asset_depreciation_detail A
    WHERE organization_id = $organ_id AND voucher_id = $voucher_id and fixed_asset_id = $fixed_asset_id;

    DELETE A FROM
    fixed_asset_ledger A
    WHERE organization_id = $organ_id AND voucher_id = $voucher_id and fixed_asset_id = $fixed_asset_id;

    DELETE A FROM
    fa_ledger_depreciation A
    WHERE organization_id = $organ_id AND voucher_id = $voucher_id and fixed_asset_id = $fixed_asset_id;

    CALL Proc_Jira_ReCallUpdateFAData($fixed_asset_id);

END  ;

SELECT CONCAT("CALL Proc_Jira_Remove_DepreciationFromVoucher('",fal.voucher_id,"','",fal.fixed_asset_id,"');") as script
FROM fixed_asset_ledger fal 
WHERE fal.remaining_amount < 0 AND fal.voucher_type = 5 AND fal.fixed_asset_id = 'ca687c3d-cd4c-426a-b202-64f317b5020b';
