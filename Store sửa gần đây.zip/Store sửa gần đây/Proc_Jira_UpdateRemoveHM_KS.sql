﻿SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_UpdateRemoveHM_KS;

CREATE PROCEDURE Proc_Jira_UpdateRemoveHM_KS (
IN $OrganID varchar(36)
)
SQL SECURITY INVOKER
BEGIN
    DECLARE $i int DEFAULT 0;
    DECLARE $count int DEFAULT 0;
    DECLARE $organCode varchar(100) DEFAULT '';
    DECLARE $fixedAssetCode varchar(100) DEFAULT '';
    DECLARE $orgprice decimal(19,4) DEFAULT 0;
    DECLARE $accum decimal(19,4) DEFAULT 0;

    -- Các chứng từ đánh giá lại của đơn vị
--     DROP TEMPORARY TABLE IF EXISTS tbOrganizationLedgerDGL;
--     CREATE TEMPORARY TABLE tbOrganizationLedgerDGL
--     SELECT fal.organization_id, fal.fixed_asset_id
--     FROM fixed_asset_ledger fal
--     WHERE  (fal.organization_id = $OrganID OR $OrganID IS NULL) AND fal.voucher_type = 2
--     GROUP BY fal.organization_id, fal.fixed_asset_id;

     -- Các chứng từ hao mòn của đơn vị
    DROP TEMPORARY TABLE IF EXISTS tbOrganizationLedgerHM;
    CREATE TEMPORARY TABLE tbOrganizationLedgerHM
    SELECT fal.organization_id, fal.fixed_asset_id, fal.voucher_id, fal.depreciation_value,fal.orgprice, 1 AS status
    FROM fixed_asset_ledger fal
    WHERE  (fal.organization_id = $OrganID OR $OrganID IS NULL) AND fal.voucher_type = 5 AND fal.remaining_amount < 0;

    -- Xóa bỏ các tài sản có đánh giá lại
--     DELETE A FROM  tbOrganizationLedgerHM  A
--     INNER JOIN  tbOrganizationLedgerDGL B 
--     ON A.organization_id = B.organization_id AND A.fixed_asset_id = B.fixed_asset_id;
                         
    INSERT fa_jira_execute (organization_id, fixed_asset_id)
    SELECT do.organization_id, fa.fixed_asset_id
    FROM tbOrganizationLedgerHM A 
    INNER JOIN dic_organization do on A.organization_id = do.organization_id
    INNER JOIN fixed_asset fa ON A.organization_id = fa.organization_id and A.fixed_asset_id = fa.fixed_asset_id
    GROUP BY do.organization_id, fa.fixed_asset_id;

  -- DROP TEMPORARY TABLE IF EXISTS tbOrganizationLedgerDGL;
   DROP TEMPORARY TABLE IF EXISTS tbOrganizationLedgerHM;
   DROP TEMPORARY TABLE IF EXISTS tbOrganizationFA;


END;

