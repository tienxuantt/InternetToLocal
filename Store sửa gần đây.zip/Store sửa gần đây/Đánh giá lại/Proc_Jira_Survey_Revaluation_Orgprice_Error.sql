﻿SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_Survey_Revaluation_Orgprice_Error;

CREATE PROCEDURE Proc_Jira_Survey_Revaluation_Orgprice_Error ()
BEGIN

  SET group_concat_max_len = 18446744073709551615;

  DROP TEMPORARY TABLE IF EXISTS a1_tmp;
  CREATE TEMPORARY TABLE a1_tmp AS
  SELECT
    r.orgprice_info,
    r.orgprice,
    fa.voucher_id,
    fa.fixed_asset_id,
    fa.fixed_asset_code,
    fa.organization_id
  FROM fixed_asset_revaluation fa
  INNER JOIN fixed_asset fa1 ON fa.fixed_asset_id = fa1.fixed_asset_id,
  JSON_TABLE (fa.fixed_asset_revaluation_list,
       '$[*]'
       COLUMNS (
       orgprice decimal(19, 4) PATH '$.new_data[*].orgprice',
       orgprice_info text PATH '$.new_data[*].orgprice_info'
       )) AS r
  WHERE
  (fa1.is_parent IS NULL
  OR fa1.is_parent = FALSE);

  DROP TEMPORARY TABLE IF EXISTS a1_tmp_group;
  CREATE TEMPORARY TABLE a1_tmp_group AS
  SELECT
    SUM(orgprice) orgprice,
    voucher_id,
    fixed_asset_id,
    organization_id,
    at.fixed_asset_code
  FROM a1_tmp at
  GROUP BY voucher_id,
           fixed_asset_id,
           fixed_asset_code,
           organization_id ;

  DROP TEMPORARY TABLE IF EXISTS a2_tmp;
  CREATE TEMPORARY TABLE a2_tmp AS
  SELECT
    SUM(r.amount) amount,
    fa.voucher_id,
    fa.fixed_asset_id,
    fa.fixed_asset_code,
    r.budget_category_id
  FROM a1_tmp fa,
       JSON_TABLE (fa.orgprice_info,
       '$[*]'
       COLUMNS (
       budget_category_id varchar(36) PATH '$.budget_category_id',
       budget_category_code varchar(50) PATH '$.budget_category_code',
       budget_category_name varchar(500) PATH '$.budget_category_name',
       budget_type int PATH '$.budget_type',
       is_budget bit(1) PATH '$.is_budget',
       amount decimal(19, 4) PATH '$.amount',
       depreciation_for_business_price decimal(19, 4) PATH '$.depreciation_for_business_price'
       )) AS r
  GROUP BY fa.voucher_id,
           fa.fixed_asset_id,
           r.budget_category_id,
           fa.fixed_asset_code;

  DROP TEMPORARY TABLE IF EXISTS a2_tmp_group;
  CREATE TEMPORARY TABLE a2_tmp_group AS
  SELECT
    SUM(amount) amount,
    fa.voucher_id,
    fa.fixed_asset_id
  FROM a2_tmp fa
  GROUP BY voucher_id,
           fixed_asset_id;

  INSERT jira_fa_focus (ID, organization_id, voucher_id, fixed_asset_id, TYPE)
  SELECT
    UUID(),
    d.organization_id,
    a.voucher_id,
    a.fixed_asset_id,
    0 AS type
  FROM a1_tmp_group a
    INNER JOIN a2_tmp_group b
      ON a.voucher_id = b.voucher_id
      AND a.fixed_asset_id = b.fixed_asset_id
    INNER JOIN dic_organization d
      ON a.organization_id = d.organization_id
      AND a.orgprice <> b.amount
    ORDER BY a.organization_id;


  DROP TEMPORARY TABLE IF EXISTS a1_tmp;
  DROP TEMPORARY TABLE IF EXISTS a2_tmp;
  DROP TEMPORARY TABLE IF EXISTS a2_tmp_group;
  DROP TEMPORARY TABLE IF EXISTS a1_tmp_group;
END;

CALL Proc_Jira_Survey_Revaluation_Orgprice_Error();