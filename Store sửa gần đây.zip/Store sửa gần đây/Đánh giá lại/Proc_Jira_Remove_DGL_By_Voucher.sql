﻿SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_Remove_DGL_By_Voucher;

CREATE PROCEDURE Proc_Jira_Remove_DGL_By_Voucher (IN $voucher_id varchar(36), IN $fixed_asset_id varchar(36))
SQL SECURITY INVOKER
BEGIN

    DELETE FROM fixed_asset_revaluation WHERE voucher_id = $voucher_id AND fixed_asset_id = $fixed_asset_id;
    DELETE FROM fixed_asset_ledger WHERE voucher_id = $voucher_id AND fixed_asset_id = $fixed_asset_id;
    DELETE FROM fa_ledger_revaluation_detail WHERE voucher_id = $voucher_id and fixed_asset_id = $fixed_asset_id;
    DELETE FROM fa_ledger_change_info WHERE voucher_id = $voucher_id and fixed_asset_id = $fixed_asset_id;

    CALL Proc_Jira_ReCallUpdateFAData($fixed_asset_id);

END ;

SELECT CONCAT("CALL Proc_Jira_Remove_DGL_By_Voucher('",fal.voucher_id,"','",fal.fixed_asset_id,"');") as Data
FROM fixed_asset_ledger fal 
WHERE fal.voucher_type = 2 AND YEAR(fal.change_date) = 2023 AND 
fal.fixed_asset_id IN  ('cf722045-7e9a-4217-b1df-16c51e7602ba','e942b30f-17fa-4876-b95d-b342c213f1ee','68a0ac37-bd36-46bc-8bfd-6b2795eff1b5');