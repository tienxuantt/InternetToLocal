﻿SELECT fa.fixed_asset_code, d.organization_code,fa.voucher_code, COALESCE(v1.depreciation_amount_new, 0),COALESCE(r.depreciation_amount_new, 0), concat("CALL Proc_Jira_Update_Revaluation_AccumOldByFA_ConvertV1('",fa.voucher_id,"', '",fa.fixed_asset_id,"', 0);") as Data
FROM fixed_asset_revaluation fa
      INNER JOIN dic_organization d ON fa.organization_id = d.organization_id
      INNER JOIN fixed_asset f ON fa.fixed_asset_id = f.fixed_asset_id
      INNER JOIN data_v1_revaluation_v2 v1 ON fa.voucher_id = v1.voucher_id AND fa.organization_id = v1.organization_id AND v1.fixed_asset_id = fa.fixed_asset_id,
       JSON_TABLE (fa.fixed_asset_revaluation_list,
       '$[*]'
       COLUMNS (
       depreciation_amount_new decimal(19, 4) PATH '$.new_data[*].depreciation_amount',
       depreciation_amount_old decimal(19, 4) PATH '$.old_data[*].depreciation_amount',
       depreciation_amount_change decimal(19, 4) PATH '$.change_data[*].depreciation_amount',
       orgprice decimal(19, 4) PATH '$.new_data[*].orgprice',
       accum_depreciation_amount decimal(19, 4) PATH '$.new_data[*].accum_depreciation_amount',
       remaining_amount decimal(19, 4) PATH '$.new_data[*].remaining_amount'
       )) AS r
  WHERE
 ( (abs(ROUND(COALESCE(v1.depreciation_amount_new, 0)) - ROUND(COALESCE(r.depreciation_amount_new, 0))) > 1 AND f.fixed_asset_type = 1)
  OR (abs(ROUND(COALESCE(v1.depreciationfor_business_amount_new, 0)) - ROUND(COALESCE(r.depreciation_amount_new, 0))) > 1 AND f.fixed_asset_type = 2)
  )
AND r.depreciation_amount_change <> 0
AND f.fixed_asset_type IN (1, 2)
ORDER BY d.organization_code ASC;


SELECT  concat("CALL Proc_Jira_Update_Revaluation_AccumOldByFA_ConvertV1('",fa.voucher_id,"', '",fa.fixed_asset_id,"', 0);") as Data
FROM fixed_asset_revaluation fa
INNER JOIN dic_organization d ON fa.organization_id = d.organization_id
INNER JOIN fixed_asset f ON fa.fixed_asset_id = f.fixed_asset_id
INNER JOIN data_v1_revaluation_v2 v1 ON fa.voucher_id = v1.voucher_id AND fa.organization_id = v1.organization_id AND v1.fixed_asset_id = fa.fixed_asset_id,
JSON_TABLE (fa.fixed_asset_revaluation_list,
'$[*]'
COLUMNS (
    depreciation_amount_new decimal(19, 4) PATH '$.new_data[*].depreciation_amount',
    depreciation_amount_old decimal(19, 4) PATH '$.old_data[*].depreciation_amount',
    depreciation_amount_change decimal(19, 4) PATH '$.change_data[*].depreciation_amount',
    orgprice decimal(19, 4) PATH '$.new_data[*].orgprice',
    accum_depreciation_amount decimal(19, 4) PATH '$.new_data[*].accum_depreciation_amount',
    remaining_amount decimal(19, 4) PATH '$.new_data[*].remaining_amount'
)) AS r
WHERE
( (abs(ROUND(COALESCE(v1.depreciation_amount_new, 0)) - ROUND(COALESCE(r.depreciation_amount_new, 0))) > 1 AND f.fixed_asset_type = 1)
OR (abs(ROUND(COALESCE(v1.depreciationfor_business_amount_new, 0)) - ROUND(COALESCE(r.depreciation_amount_new, 0))) > 1 AND f.fixed_asset_type = 2)
)
AND r.depreciation_amount_change <> 0
AND f.fixed_asset_type IN (1, 2)
ORDER BY d.organization_code ASC;

UPDATE fixed_asset fa
set fa.remaining_number_of_year = 6 , fa.depreciation_year = 1311794
WHERE fa.fixed_asset_id = '392fa354-774f-4082-b2f4-4bfe604568f1';

SELECT count(*), faug.organization_id, do.organization_name FROM fixed_asset_using_general faug
INNER JOIN dic_organization do ON  faug.organization_id = do.organization_id GROUP BY faug.organization_id,  do.organization_name;

SELECT count(*), do.organization_name, faem.exploitation_type, YEAR(faem.approval_date)
FROM fixed_asset_exploitation_master faem INNER JOIN dic_organization do ON faem.organization_id = do.organization_id
GROUP BY do.organization_name, faem.exploitation_type,YEAR(faem.approval_date)
ORDER BY do.organization_name;