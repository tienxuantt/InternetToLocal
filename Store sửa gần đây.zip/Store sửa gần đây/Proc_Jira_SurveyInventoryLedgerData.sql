﻿SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_SurveyInventoryLedgerData;

CREATE PROCEDURE Proc_Jira_SurveyInventoryLedgerData ()
SQL SECURITY INVOKER
BEGIN

  DROP TEMPORARY TABLE IF EXISTS tbOrginData;
  CREATE TEMPORARY TABLE tbOrginData
  SELECT
    *,
    ROW_NUMBER() OVER (PARTITION BY fixed_asset_id ORDER BY A.change_date, A.created_date, A.fixed_asset_ledger_id) AS STT
  FROM (
  SELECT
      fixed_asset_ledger_id,
      fixed_asset_id,
      voucher_id,
      voucher_code,
      voucher_type,
      change_date,
      created_date,
      orgprice,
      accum_depreciation_amount,
      remaining_amount
    FROM fixed_asset_ledger
    WHERE voucher_type <> 17
    UNION ALL
    SELECT
      fixed_asset_ledger_id,
      fixed_asset_id,
      voucher_id,
      voucher_code,
      voucher_type,
      change_date,
      created_date,
      orgprice,
      accum_depreciation_amount,
      remaining_amount
    FROM fa_ledger_inventory
    ) A;

    DROP TEMPORARY TABLE IF EXISTS tbOrginData;

END;