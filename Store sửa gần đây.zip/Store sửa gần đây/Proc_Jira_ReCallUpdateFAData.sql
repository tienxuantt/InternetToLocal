SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_ReCallUpdateFAData;

CREATE PROCEDURE Proc_Jira_ReCallUpdateFAData (IN $fixed_asset_id varchar(36))
SQL SECURITY INVOKER
BEGIN
  DECLARE $i int DEFAULT 0;
  DECLARE $count int DEFAULT 0;
  DECLARE $orgprice decimal(19, 4) DEFAULT 0;
  DECLARE $accum decimal(19, 4) DEFAULT 0;
  DECLARE $fixed_asset_type int DEFAULT 0;
  DECLARE $depreciation_amount decimal(19, 4) DEFAULT 0;
  DECLARE $depreciation_for_business_amount decimal(19, 4) DEFAULT 0;
  DECLARE $organID varchar(36);

  DROP TEMPORARY TABLE IF EXISTS tbOrganizationFA;
  CREATE TEMPORARY TABLE tbOrganizationFA (
    fixed_asset_id varchar(36)
  );

  IF ($fixed_asset_id IS NOT NULL) THEN
  BEGIN

      SELECT fa.organization_id INTO $organID FROM fixed_asset fa WHERE fa.fixed_asset_id = $fixed_asset_id LIMIT 1;

      INSERT tbOrganizationFA
      VALUES ($fixed_asset_id);

    -- Lay ra gia tri truoc do cua DGL
    DROP TEMPORARY TABLE IF EXISTS tempFA_DGL;
    CREATE TEMPORARY TABLE tempFA_DGL AS
    SELECT *
    FROM (
      SELECT
         a.organization_id,
         a.fixed_asset_id,
         a.voucher_id,
         b.accum_depreciation_amount,
         b.depreciation_for_business_amount,
         b.depreciation_rate,
         ROW_NUMBER() OVER(PARTITION BY a.voucher_id ORDER BY b.change_date DESC, b.created_date DESC, b.fixed_asset_ledger_id DESC) AS rnumber
      FROM (
        SELECT
          fal.organization_id,
          fal.fixed_asset_id,
          fal.voucher_id,
          fal.change_date,
          fal.created_date,
          fal.fixed_asset_ledger_id
        FROM fixed_asset_ledger fal
        WHERE fal.organization_id = $organID AND fal.fixed_asset_id = $fixed_asset_id AND fal.voucher_type = 2
      ) a INNER JOIN fixed_asset_ledger b
        ON a.organization_id = b.organization_id 
          AND a.fixed_asset_id = b.fixed_asset_id
          AND b.voucher_type <> 17
          AND (a.change_date > b.change_date 
          OR (a.change_date = b.change_date AND a.created_date > b.created_date) 
          OR (a.change_date = b.change_date AND a.created_date = b.created_date AND a.fixed_asset_ledger_id > b.fixed_asset_ledger_id)
          )
    ) c
    WHERE c.rnumber = 1;

    -- Update thong tin old cho DGL
    UPDATE  fixed_asset_revaluation fal
    INNER JOIN fixed_asset fa ON fa.organization_id = $organID AND fal.organization_id = fa.organization_id and fal.fixed_asset_id = fa.fixed_asset_id
    INNER JOIN tempFA_DGL B on fal.organization_id = B.organization_id AND fal.voucher_id = B.voucher_id and fal.fixed_asset_id = B.fixed_asset_id
    SET fal.fixed_asset_revaluation_list = JSON_SET(fal.fixed_asset_revaluation_list,
     '$[0].old_data[0].depreciation_amount',  ifnull(B.accum_depreciation_amount,0),
     '$[0].old_data[0].depreciation_for_business_amount', IF(fa.fixed_asset_type = 1, 0,  if(fa.fixed_asset_type = 2,  ifnull(B.accum_depreciation_amount,0), ifnull(B.depreciation_for_business_amount,0))),
     '$[0].old_data[0].accum_depreciation_amount',  ifnull(B.accum_depreciation_amount,0),
     '$[0].old_data[0].depreciation_rate',  ifnull(B.depreciation_rate,0),
     '$[0].old_data[0].remaining_amount', ifnull(fal.fixed_asset_revaluation_list ->>  '$[0].old_data[0].orgprice',0) -  ifnull(B.accum_depreciation_amount,0)
     );

    -- Update thong tin new cho DGL sinh ra tu cap nhat thong tu
--     UPDATE fixed_asset_revaluation fal
--     INNER JOIN fixed_asset fa ON fa.organization_id = $organID AND fal.organization_id = fa.organization_id and fal.fixed_asset_id = fa.fixed_asset_id
--     INNER JOIN tempFA_DGL B on fal.organization_id = B.organization_id AND fal.voucher_id = B.voucher_id and fal.fixed_asset_id = B.fixed_asset_id
--     SET fal.fixed_asset_revaluation_list = JSON_SET(fal.fixed_asset_revaluation_list,
--      '$[0].new_data[0].depreciation_amount', ifnull(B.accum_depreciation_amount,0),
--      '$[0].new_data[0].depreciation_for_business_amount', IF(fa.fixed_asset_type = 1, 0, if(fa.fixed_asset_type = 2, ifnull(B.accum_depreciation_amount,0), ifnull(B.depreciation_for_business_amount,0))),
--      '$[0].new_data[0].accum_depreciation_amount', ifnull(B.accum_depreciation_amount,0),
--      '$[0].new_data[0].remaining_amount', ifnull(fal.fixed_asset_revaluation_list ->> '$[0].new_data[0].orgprice',0) - ifnull(B.accum_depreciation_amount,0)
--      )
--      WHERE fal.revaluation_type = 3 AND YEAR(fal.revaluation_date) >= 2021 AND MONTH(fal.revaluation_date) = 1 AND DAY(fal.revaluation_date) = 1 AND fal.description LIKE '%i do thay %' ;

     -- Update thong tin change data cho DGL
     UPDATE fixed_asset_revaluation fal
     SET fal.fixed_asset_revaluation_list = JSON_SET(fal.fixed_asset_revaluation_list,
     '$[0].change_data[0].orgprice', ifnull(fal.fixed_asset_revaluation_list ->>  '$[0].new_data[0].orgprice',0) -  ifnull(fal.fixed_asset_revaluation_list ->>  '$[0].old_data[0].orgprice',0)  ,
     '$[0].change_data[0].depreciation_amount', ifnull(fal.fixed_asset_revaluation_list ->>  '$[0].new_data[0].depreciation_amount',0) -  ifnull(fal.fixed_asset_revaluation_list ->>  '$[0].old_data[0].depreciation_amount',0)  ,
     '$[0].change_data[0].accum_depreciation_amount',  ifnull(fal.fixed_asset_revaluation_list ->>  '$[0].new_data[0].accum_depreciation_amount',0) -  ifnull(fal.fixed_asset_revaluation_list ->>  '$[0].old_data[0].accum_depreciation_amount',0) ,
     '$[0].change_data[0].depreciation_for_business_amount',  ifnull(fal.fixed_asset_revaluation_list ->>  '$[0].new_data[0].depreciation_for_business_amount',0) -  ifnull(fal.fixed_asset_revaluation_list ->>  '$[0].old_data[0].depreciation_for_business_amount',0) ,
     '$[0].change_data[0].depreciation_rate', ifnull(fal.fixed_asset_revaluation_list ->>  '$[0].new_data[0].depreciation_rate',0) -  ifnull(fal.fixed_asset_revaluation_list ->>  '$[0].old_data[0].depreciation_rate',0)  ,
     '$[0].change_data[0].remaining_amount',  ifnull(fal.fixed_asset_revaluation_list ->>  '$[0].new_data[0].remaining_amount',0) -  ifnull(fal.fixed_asset_revaluation_list ->>  '$[0].old_data[0].remaining_amount',0) ,
     '$[0].change_data[0].remaining_number_of_year', ifnull(fal.fixed_asset_revaluation_list ->>  '$[0].new_data[0].remaining_number_of_year',0) -  ifnull(fal.fixed_asset_revaluation_list ->>  '$[0].old_data[0].remaining_number_of_year',0)  ,
     '$[0].change_data[0].depreciation_year',  ifnull(fal.fixed_asset_revaluation_list ->>  '$[0].new_data[0].depreciation_year',0) -  ifnull(fal.fixed_asset_revaluation_list ->>  '$[0].old_data[0].depreciation_year',0),
     '$[0].change_data[0].quantity',  ifnull(fal.fixed_asset_revaluation_list ->>  '$[0].new_data[0].quantity',0) -  ifnull(fal.fixed_asset_revaluation_list ->>  '$[0].old_data[0].quantity',0)
     )
     WHERE fal.organization_id = $organID AND fal.fixed_asset_id = $fixed_asset_id;

      -- Update ledger DGL for TS
      UPDATE fixed_asset_ledger fal
      INNER JOIN fixed_asset fa ON fal.organization_id = $organID AND fal.organization_id = fa.organization_id AND fal.fixed_asset_id = fa.fixed_asset_id
      INNER JOIN fixed_asset_revaluation far ON fal.organization_id = far.organization_id AND fal.voucher_id = far.voucher_id and fal.fixed_asset_id = far.fixed_asset_id
      SET fal.depreciation_amount = CASE 
                                                                            WHEN fa.fixed_asset_type = 2 THEN 0 
                                                                            WHEN fa.fixed_asset_type = 1 THEN IFNULL(far.fixed_asset_revaluation_list ->> '$[0].new_data[0].depreciation_amount', 0)
                                                                            ELSE IFNULL(far.fixed_asset_revaluation_list ->> '$[0].new_data[0].depreciation_amount', 0) - IFNULL(far.fixed_asset_revaluation_list ->> '$[0].new_data[0].depreciation_for_business_amount', 0) 
                                                                 END,
      fal.depreciation_for_business_amount = CASE 
                                                                                            WHEN fa.fixed_asset_type = 1 THEN 0 
                                                                                            WHEN fa.fixed_asset_type = 2 THEN IFNULL(far.fixed_asset_revaluation_list ->> '$[0].new_data[0].depreciation_amount', 0)
                                                                                            ELSE IFNULL(far.fixed_asset_revaluation_list ->> '$[0].new_data[0].depreciation_for_business_amount', 0) 
                                                                                     END,
      fal.accum_depreciation_amount = IFNULL(far.fixed_asset_revaluation_list ->> '$[0].new_data[0].depreciation_amount', 0),
      fal.remaining_amount = IFNULL(far.fixed_asset_revaluation_list ->> '$[0].new_data[0].orgprice', 0) - IFNULL(far.fixed_asset_revaluation_list ->> '$[0].new_data[0].depreciation_amount', 0),
      fal.depreciation_value = 0,
      fal.depreciation_for_business_value = 0,
      fal.orgprice = IFNULL(far.fixed_asset_revaluation_list ->> '$[0].new_data[0].orgprice', 0),

      fal.difference_quantity = IFNULL(far.fixed_asset_revaluation_list ->> '$[0].change_data[0].quantity', 0),
      fal.difference_orgprice = IFNULL(far.fixed_asset_revaluation_list ->> '$[0].change_data[0].orgprice', 0),
      fal.difference_remaining_amount = IFNULL(far.fixed_asset_revaluation_list ->> '$[0].change_data[0].remaining_amount', 0),
      fal.difference_depreciation_amount = CASE 
                                                                                            WHEN fa.fixed_asset_type = 2 THEN 0 
                                                                                            WHEN fa.fixed_asset_type = 1 THEN IFNULL(far.fixed_asset_revaluation_list ->> '$[0].change_data[0].depreciation_amount', 0)
                                                                                            ELSE IFNULL(far.fixed_asset_revaluation_list ->> '$[0].change_data[0].depreciation_amount', 0) - IFNULL(far.fixed_asset_revaluation_list ->> '$[0].change_data[0].depreciation_for_business_amount', 0) 
                                                                                END,
      fal.difference_depreciation_for_business_amount =  CASE 
                                                                                                                    WHEN fa.fixed_asset_type = 2 THEN IFNULL(far.fixed_asset_revaluation_list ->> '$[0].change_data[0].depreciation_amount', 0) 
                                                                                                                    WHEN fa.fixed_asset_type = 1 THEN 0 
                                                                                                                    ELSE  IFNULL(far.fixed_asset_revaluation_list ->> '$[0].change_data[0].depreciation_for_business_amount', 0) 
                                                                                                            END
      WHERE fal.organization_id = $organID AND fal.fixed_asset_id = $fixed_asset_id and fal.voucher_type = 2;

      DROP TEMPORARY TABLE IF EXISTS tempFA_DGL;
  END;
  END IF;

  DROP TEMPORARY TABLE IF EXISTS tbOrganizationTemFA;
  CREATE TEMPORARY TABLE tbOrganizationTemFA
  SELECT
    do.organization_code,
    fa.fixed_asset_code,
    fal.orgprice,
    fal.accum_depreciation_amount,
    fal.depreciation_amount,
    fal.depreciation_for_business_amount,
    fa.fixed_asset_type
  FROM tbOrganizationFA A
    INNER JOIN fixed_asset fa
      ON A.fixed_asset_id = fa.fixed_asset_id
    INNER JOIN dic_organization do
      ON fa.organization_id = do.organization_id
    INNER JOIN fixed_asset_ledger fal
      ON fal.voucher_type IN (1, 8)
      AND fal.organization_id = do.organization_id
      AND A.fixed_asset_id = fal.fixed_asset_id;

  SELECT
    COUNT(1) INTO $count
  FROM tbOrganizationTemFA;

  WHILE $i < $count DO
    SELECT
      orgprice,
      accum_depreciation_amount,
      fixed_asset_type,
      depreciation_amount,
      depreciation_for_business_amount INTO $orgprice, $accum, $fixed_asset_type, $depreciation_amount, $depreciation_for_business_amount
    FROM tbOrganizationTemFA
    LIMIT $i, 1;

                IF ($fixed_asset_type = 3) THEN
                        CALL Proc_Jira_Update_Depreciation_FixedAsset_From_GT_ALL($fixed_asset_id, IFNULL($orgprice, 0), IFNULL($depreciation_amount, 0), IFNULL($depreciation_for_business_amount, 0));
                ELSE
                         CALL Proc_Jira_Update_Depreciation_FixedAsset_From_GT($fixed_asset_id, IFNULL($orgprice, 0), IFNULL($accum, 0));
                end if;

    SET $i = $i + 1;
  END WHILE;

  DROP TEMPORARY TABLE IF EXISTS tbOrganizationTemFA;
  DROP TEMPORARY TABLE IF EXISTS tempReCallUpdateFAData;

END;
