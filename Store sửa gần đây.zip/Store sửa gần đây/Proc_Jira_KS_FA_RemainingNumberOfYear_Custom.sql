﻿SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_KS_FA_RemainingNumberOfYear_Custom;

CREATE PROCEDURE Proc_Jira_KS_FA_RemainingNumberOfYear_Custom (IN $FixedAssetID varchar(36), IN $Type int, IN $number_use_first int)
SQL SECURITY INVOKER
BEGIN
  DECLARE $Count int DEFAULT 0;
  DECLARE $i int DEFAULT 1;
  DECLARE $STT_GT int DEFAULT 100;
  DECLARE $VoucherType int DEFAULT 0;
  DECLARE $OrganizationID varchar(36);

  DECLARE $number_use decimal(19, 4) DEFAULT 0;
  DECLARE $year_GT int DEFAULT 0;
  DECLARE $year_HM int DEFAULT 0;
  DECLARE $remaining_old decimal(19, 4) DEFAULT 0;
  DECLARE $remaining_new decimal(19, 4) DEFAULT 0;
  DECLARE $number_of_year decimal(19, 4) DEFAULT 0;
  DECLARE $number_of_year_previos decimal(19, 4) DEFAULT 0;
  DECLARE $depreciation_rate decimal(19, 4) DEFAULT 0;

  DECLARE $Stt_last_DGL int DEFAULT 0;
  DECLARE $depreciation_year_now decimal(19, 4) DEFAULT 0;

  SELECT
    fa.organization_id INTO $OrganizationID
  FROM fixed_asset fa
  WHERE fa.fixed_asset_id = $FixedAssetID LIMIT 1;

  DROP TEMPORARY TABLE IF EXISTS tbOrginData2;
  CREATE TEMPORARY TABLE tbOrginData2
  SELECT
    fal.fixed_asset_id,
    fal.fixed_asset_code,
    fal.voucher_type,
    fal.change_date,
    fal.voucher_code,
    fal.voucher_id,
    fal.created_date,
    YEAR(fal.change_date) AS year_voucher,
    COALESCE(fadd.depreciation_rate, far.fixed_asset_revaluation_list -> "$[0].new_data[0].depreciation_rate", fal.depreciation_rate) AS depreciation_rate,
    far.fixed_asset_revaluation_list -> "$[0].old_data[0].remaining_number_of_year" AS number_of_year_old,
    far.fixed_asset_revaluation_list -> "$[0].new_data[0].remaining_number_of_year" AS number_of_year_new,
    1 AS status,
    ROW_NUMBER() OVER (PARTITION BY fal.fixed_asset_id
    ORDER BY fal.change_date, fal.created_date) AS STT
  FROM fixed_asset_ledger fal
    LEFT JOIN fixed_asset_depreciation_detail fadd
      ON fal.voucher_id = fadd.voucher_id
      AND fal.fixed_asset_id = fadd.fixed_asset_id
    LEFT JOIN fixed_asset_revaluation far
      ON fal.voucher_id = far.voucher_id
      AND fal.fixed_asset_id = far.fixed_asset_id
  WHERE fal.organization_id = $OrganizationID
  AND fal.fixed_asset_id = $FixedAssetID
  AND fal.voucher_type IN (1, 8, 2, 5)
  ORDER BY fal.change_date, fal.created_date;

  SET $STT_GT = (SELECT
      STT
    FROM tbOrginData2
    WHERE voucher_type IN (1, 8)
    ORDER BY STT LIMIT 1);

  -- Xóa b? ch?ng t? tru?c ghi tang
  DELETE
    FROM tbOrginData2
  WHERE STT < $STT_GT;

  -- Neu ti le hao mon = 0 => stop
  IF EXISTS (SELECT
        1
      FROM tbOrginData2 od
      WHERE od.depreciation_rate = 0) THEN
  BEGIN
        DELETE FROM tbOrginData2;
  end;
  end if;

  DROP TEMPORARY TABLE IF EXISTS tbOrginData;
  CREATE TEMPORARY TABLE tbOrginData
  SELECT
    A.fixed_asset_id,
    A.fixed_asset_code,
    A.voucher_type,
    A.change_date,
    A.voucher_code,
    A.voucher_id,
    A.year_voucher,
    A.depreciation_rate,
    A.number_of_year_old,
    A.number_of_year_new,
    CAST(0.0000 AS decimal(19, 4)) AS remain_number_old_correct,
    CAST(0.0000 AS decimal(19, 4)) AS remain_number_new_correct,
    CAST(0.0000 AS decimal(19, 4)) AS depreciation_rate_old_correct,
    A.status,
    ROUND(1 / A.depreciation_rate) AS number_of_year,
    ROW_NUMBER() OVER (PARTITION BY fixed_asset_id
    ORDER BY A.change_date, A.created_date) AS STT
  FROM tbOrginData2 A;

  -- SELECT * FROM tbOrginData;

  IF EXISTS (SELECT
        1
      FROM tbOrginData od
      WHERE od.voucher_type IN (1, 8)
      AND od.STT = 1) THEN
  BEGIN

    SELECT
      COUNT(1) INTO $Count
    FROM tbOrginData;

    WHILE $i <= $Count DO

      SELECT
        voucher_type,
        od.year_voucher,
        od.number_of_year INTO $VoucherType, $year_GT, $number_of_year
      FROM tbOrginData od
      WHERE od.STT = $i LIMIT 1;

      IF ($i = 1) THEN
        IF ($VoucherType = 1) THEN
          SET $number_use = 0;
        ELSE
          SELECT
            voucher_type,
            od.year_voucher INTO $VoucherType, $year_HM
          FROM tbOrginData od
          WHERE od.STT = $i + 1 LIMIT 1;

          IF ($VoucherType = 2) THEN
            SET $number_use = 0;
          ELSE
            SET $number_use = $year_HM - $year_GT;

                IF ($number_use_first is not null) THEN
                    set $number_use = $number_use_first;
                end if;
          END IF;
        END IF;
      END IF;

      IF ($i > 1
        AND $VoucherType = 5) THEN
        SET $number_use = $number_use + 1;

        -- Cập nhật vào chứng từ hao mòn
        IF ($Type = 1
          AND $depreciation_year_now > 0) THEN
          UPDATE fixed_asset_depreciation_detail a
          INNER JOIN tbOrginData B
            ON a.voucher_id = B.voucher_id
            AND a.fixed_asset_id = B.fixed_asset_id
          SET a.depreciation_year = $depreciation_year_now
          WHERE B.STT = $i;

          UPDATE fixed_asset_ledger a
          INNER JOIN tbOrginData B
            ON a.voucher_id = B.voucher_id
            AND a.fixed_asset_id = B.fixed_asset_id
          SET a.depreciation_year = $depreciation_year_now
          WHERE a.voucher_type = 5
          AND B.STT = $i;
        END IF;
      END IF;

      IF ($i > 1
        AND $VoucherType = 2) THEN
        SELECT
          od.number_of_year,
          od.depreciation_rate INTO $number_of_year_previos, $depreciation_rate
        FROM tbOrginData od
        WHERE od.STT = $i - 1 LIMIT 1;

        UPDATE tbOrginData a
        SET a.status = 0,
            a.remain_number_old_correct = IF($number_of_year_previos - $number_use < 0, 0, $number_of_year_previos - $number_use),
            a.remain_number_new_correct = IF($number_of_year - $number_use < 0, 0, $number_of_year - $number_use),
            a.depreciation_rate_old_correct = $depreciation_rate
        WHERE a.STT = $i
        AND (a.number_of_year_old <> $number_of_year_previos - $number_use
        OR a.number_of_year_new <> $number_of_year - $number_use);

        -- Lấy ra hao mòn năm hiện tại
        IF ($Type = 1) THEN
          SELECT
            IF(cr.remain_number_new_correct <= 1, A.remaining_amount, ROUND(A.remaining_amount / cr.remain_number_new_correct)) INTO $depreciation_year_now
          FROM fixed_asset_revaluation far
            INNER JOIN fixed_asset_ledger A
              ON far.organization_id = A.organization_id
              AND far.voucher_id = A.voucher_id
              AND far.fixed_asset_id = A.fixed_asset_id
            INNER JOIN tbOrginData cr
              ON far.voucher_id = cr.voucher_id
              AND far.fixed_asset_id = cr.fixed_asset_id
          WHERE cr.status = 0
          AND cr.STT = $i;
        END IF;

        SET $Stt_last_DGL = $i;
      END IF;

      SET $i = $i + 1;
      SET $VoucherType = 0;
    END WHILE;

  END;
  END IF;

  -- Khao Sat
  IF ($Type = 0) THEN
-- SELECT
-- fixed_asset_code,
-- voucher_type,
-- change_date,
-- voucher_code,
-- number_of_year_old,
-- number_of_year_new,
-- remain_number_old_correct,
-- remain_number_new_correct,
-- depreciation_rate_old_correct,
-- number_of_year
-- FROM tbOrginData
-- WHERE status = 0;

    INSERT tempFAKS_Remaining_result
    SELECT fixed_asset_id
    FROM tbOrginData
    WHERE status = 0;
  END IF;

  -- Khac phuc
  IF ($Type = 1 AND EXISTS (SELECT 1 FROM tbOrginData od WHERE od.status = 0)) THEN
    -- Cập nhật ĐGL
    UPDATE fixed_asset_revaluation far
    INNER JOIN fixed_asset_ledger A
      ON far.organization_id = A.organization_id
      AND far.voucher_id = A.voucher_id
      AND far.fixed_asset_id = A.fixed_asset_id
    INNER JOIN tbOrginData cr
      ON far.voucher_id = cr.voucher_id
      AND far.fixed_asset_id = cr.fixed_asset_id
    SET far.fixed_asset_revaluation_list = JSON_SET(
    far.fixed_asset_revaluation_list,
    '$[0].new_data[0].remaining_number_of_year', cr.remain_number_new_correct,
    '$[0].old_data[0].remaining_number_of_year', cr.remain_number_old_correct,
    '$[0].change_data[0].remaining_number_of_year', cr.remain_number_new_correct - cr.remain_number_old_correct,

    '$[0].new_data[0].depreciation_year', IF(cr.remain_number_new_correct <= 1, A.remaining_amount, ROUND(A.remaining_amount / cr.remain_number_new_correct)),
    '$[0].change_data[0].depreciation_year',
    IF(cr.remain_number_new_correct <= 1, A.remaining_amount, ROUND(A.remaining_amount / cr.remain_number_new_correct)) - (far.fixed_asset_revaluation_list -> '$[0].old_data[0].depreciation_year'),

    '$[0].old_data[0].depreciation_rate', cr.depreciation_rate_old_correct,
    '$[0].change_data[0].depreciation_rate',
    (far.fixed_asset_revaluation_list -> '$[0].new_data[0].depreciation_rate') - cr.depreciation_rate_old_correct)
    WHERE cr.status = 0;

    -- Cập nhật ledger
    UPDATE fixed_asset_ledger fal
    INNER JOIN fixed_asset_revaluation B
      ON fal.voucher_id = B.voucher_id
      AND fal.fixed_asset_id = B.fixed_asset_id
    INNER JOIN tbOrginData C
      ON fal.voucher_id = C.voucher_id
      AND fal.fixed_asset_id = C.fixed_asset_id
    SET fal.remaining_number_of_year = C.remain_number_new_correct,
        fal.difference_depreciation_rate = (B.fixed_asset_revaluation_list -> '$[0].new_data[0].depreciation_rate') - C.depreciation_rate_old_correct,
        fal.depreciation_year = (B.fixed_asset_revaluation_list -> '$[0].new_data[0].depreciation_year'),
        fal.difference_depreciation_year = (B.fixed_asset_revaluation_list -> '$[0].change_data[0].depreciation_year')
    WHERE C.status = 0;

    -- Cập nhật tài sản
    UPDATE fixed_asset fa
    INNER JOIN tbOrginData B
      ON fa.fixed_asset_id = B.fixed_asset_id
    SET fa.remaining_number_of_year = IF(B.number_of_year - $number_use < 0, 0, B.number_of_year - $number_use)
    WHERE B.STT = $Count;

    -- Cập nhật thông tin hao mòn năm
    UPDATE fixed_asset fa
    INNER JOIN fixed_asset_revaluation far
      ON fa.fixed_asset_id = far.fixed_asset_id
    INNER JOIN tbOrginData cr
      ON far.voucher_id = cr.voucher_id
      AND far.fixed_asset_id = cr.fixed_asset_id
    SET fa.depreciation_year = (far.fixed_asset_revaluation_list -> '$[0].new_data[0].depreciation_year')
    WHERE cr.status = 0
    AND cr.STT = $Stt_last_DGL;

    -- Tính lại tài sản
    CALL Proc_Jira_ReCallUpdateFAData($FixedAssetID);

  END IF;

END;

CALL  Proc_Jira_KS_FA_RemainingNumberOfYear_Custom('96021d70-f32c-4cfb-a945-00398ca208b4', 1, 0);