﻿SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_RemoveHMDuplicateLedger;

CREATE PROCEDURE Proc_Jira_RemoveHMDuplicateLedger (
)
SQL SECURITY INVOKER
BEGIN

      -- Các chứng từ hao mòn của đơn vị
      DROP TEMPORARY TABLE IF EXISTS tbRemoveHMDuplicateLedger;
      CREATE TEMPORARY TABLE tbRemoveHMDuplicateLedger
     SELECT * FROM 
     (
        SELECT fal.organization_id, fal.fixed_asset_ledger_id, fal.fixed_asset_id, fal.voucher_id, fal.change_date, fal.voucher_code, 
        row_number() OVER(PARTITION BY fal.fixed_asset_id, fal.voucher_id ORDER BY fal.change_date) AS STT 
        FROM fixed_asset_ledger fal
        INNER JOIN fa_jira_execute fje on fal.organization_id = fje.organization_id AND fal.fixed_asset_id = fje.fixed_asset_id AND fal.voucher_type = 5
     ) B WHERE B.STT > 1;

    DELETE A 
    FROM fixed_asset_ledger A 
    INNER JOIN tbRemoveHMDuplicateLedger B 
    ON A.organization_id = B.organization_id AND A.fixed_asset_ledger_id = B.fixed_asset_ledger_id
    WHERE A.voucher_type = 5;

    DROP TEMPORARY TABLE IF EXISTS tbOrganizationFA;
    CREATE TEMPORARY TABLE tbOrganizationFA
    SELECT organization_id, fixed_asset_id 
    FROM tbRemoveHMDuplicateLedger
    GROUP BY organization_id, fixed_asset_id;

    DROP TEMPORARY TABLE IF EXISTS Temp_Jira_ReCallUpdateFAData;
    CREATE TEMPORARY TABLE Temp_Jira_ReCallUpdateFAData
    SELECT do.organization_code, fa.fixed_asset_code, fal.orgprice, fal.accum_depreciation_amount
    FROM tbOrganizationFA A
    INNER JOIN fixed_asset fa on A.organization_id = fa.organization_id and A.fixed_asset_id = fa.fixed_asset_id
    INNER JOIN dic_organization do on A.organization_id = do.organization_id
    INNER JOIN fixed_asset_ledger fal ON fal.voucher_type IN (1,8) AND fal.organization_id = do.organization_id AND A.fixed_asset_id = fal.fixed_asset_id;
       
    CALL Proc_Jira_ReCallUpdateFAData();

    DROP TEMPORARY TABLE IF EXISTS tbRemoveHMDuplicateLedger;
    DROP TEMPORARY TABLE IF EXISTS tbOrganizationFA;

END;


CALL Proc_Jira_RemoveHMDuplicateLedger();