﻿SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_UpdateInventoryOrgpriceTenant;

CREATE PROCEDURE Proc_Jira_UpdateInventoryOrgpriceTenant ()
SQL SECURITY INVOKER
BEGIN
    DECLARE $i int DEFAULT 0;
    DECLARE $count int DEFAULT 0;
    DECLARE $organID varchar(36) DEFAULT '';
    DECLARE $fixedAssetID varchar(36) DEFAULT '';

    DROP TEMPORARY TABLE IF EXISTS tbOrganization;
    CREATE TEMPORARY TABLE tbOrganization
    SELECT
    a.organization_id,
    a.fixed_asset_id
    FROM fa_ledger_inventory a
    WHERE ifnull(a.orgprice,0) = 0
    GROUP BY a.organization_id, a.fixed_asset_id;
                                 
    SELECT
        COUNT(1) INTO $count
    FROM tbOrganization;

    WHILE $i < $count DO
        SELECT
            organization_id, fixed_asset_id INTO $organID,  $fixedAssetID
        FROM tbOrganization
        LIMIT $i, 1;

        CALL Proc_Jira_UpdateInventoryOrgpriceOrgan($organID, $fixedAssetID);

        SET $i = $i + 1;
    END WHILE;

    DROP TEMPORARY TABLE IF EXISTS tbOrganization;

END;



CALL Proc_Jira_UpdateInventoryOrgpriceTenant();

