﻿SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_UpdateLedgerBudgetDMiss;

CREATE PROCEDURE Proc_Jira_UpdateLedgerBudgetDMiss (IN $OrganizationID char(36), IN $FixedAssetID char(36))
BEGIN

     DROP TEMPORARY TABLE IF EXISTS tblVoucherNew;
     CREATE TEMPORARY TABLE tblVoucherNew
     SELECT fal.voucher_id, fal.voucher_code, fal.voucher_type,fal.public_asset_type, fal.organization_id, fal.fixed_asset_id, fal.orgprice, fal.change_date
     FROM fixed_asset_ledger fal 
     WHERE fal.organization_id = $OrganizationID and fal.fixed_asset_id = $FixedAssetID AND fal.voucher_type IN (1,8,2)
     ORDER BY DATE(fal.change_date) DESC, fal.created_date DESC
     LIMIT 1;
            
     DROP TEMPORARY TABLE IF EXISTS tblLedgerBudgetNew;
     CREATE TEMPORARY TABLE tblLedgerBudgetNew
     SELECT
          lb.budget_category_id, lb.budget_category_code, lb.budget_category_name, lb.organization_id , lb.is_budget, lb.budget_type, $FixedAssetID AS fixed_asset_id
      FROM ledger_budget lb
      WHERE lb.organization_id = $OrganizationID AND lb.amount > 0
      LIMIT 1;

     IF NOT EXISTS (SELECT 1 FROM tblLedgerBudgetNew) THEN 

           INSERT  tblLedgerBudgetNew (budget_category_id, budget_category_code, budget_category_name, organization_id, is_budget, budget_type, fixed_asset_id)
           SELECT budget_category_id, budget_category_code, budget_category_name, organization_id, is_budget, budget_type, $FixedAssetID AS  fixed_asset_id
           FROM dic_budget_category dbc WHERE dbc.organization_id = $OrganizationID
           LIMIT 1;

     END IF;

     INSERT INTO ledger_budget (
      organization_id,
      change_date,
      fixed_asset_id,
      budget_category_id,
      budget_category_code,
      budget_category_name,
      amount,
      created_date,
      created_by,
      modified_date,
      modified_by,
      is_data_convert,
      voucher_id,
      voucher_code,
      voucher_type,
      public_asset_type,
      parent_id,
      is_budget,
      difference_amount,
      budget_type,
      depreciation_for_business_price,
      difference_depreciation_for_business_price)
      SELECT
        B.organization_id,
        B.change_date,
        B.fixed_asset_id,
        A.budget_category_id,
        A.budget_category_code,
        A.budget_category_name,
        B.orgprice as amount,
        NULL AS created_date,
        NULL AS created_by,
        NULL AS modified_date,
        NULL AS modified_by,
        0 AS is_data_convert,
        B.voucher_id,
        B.voucher_code,
        B.voucher_type,
        B.public_asset_type,
        null AS parent_id,
        A.is_budget,
        0 AS difference_amount,
        A.budget_type,
        0 AS depreciation_for_business_price,
        0 AS difference_depreciation_for_business_price
      FROM tblLedgerBudgetNew   A INNER JOIN tblVoucherNew B ON A.organization_id = B.organization_id and A.fixed_asset_id = B.fixed_asset_id;

      DROP TEMPORARY TABLE IF EXISTS tblLedgerBudgetNew;
      DROP TEMPORARY TABLE IF EXISTS tblVoucherNew;

END;

CALL Proc_Jira_UpdateLedgerBudgetDMiss('59107276-9efc-4442-9ce8-1073e1bee372','aaaaaaa');
      