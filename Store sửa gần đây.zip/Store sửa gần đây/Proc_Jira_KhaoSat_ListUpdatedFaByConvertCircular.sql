﻿DROP PROCEDURE IF EXISTS Proc_Jira_KhaoSat_ListUpdatedFaByConvertCircular;

CREATE PROCEDURE Proc_Jira_KhaoSat_ListUpdatedFaByConvertCircular (IN $orgId varchar(36))
BEGIN

    SELECT
      DATABASE() AS 'Tỉnh',
      fa.fixed_asset_id,
      do.organization_code AS `Mã QHNS`,
      do.organization_name AS `Tên đơn vị`,
      fa.fixed_asset_code AS `Mã tài sản`,
      fa.fixed_asset_name AS `Tên tài sản`,
      fa.fixed_asset_category_name AS `Tên loại`,
      CASE WHEN fa.fixed_asset_type = 1 THEN 'Chỉ tính hao mòn' WHEN fa.fixed_asset_type = 2 THEN 'Chỉ trích khấu hao' ELSE 'Vừa hao mòn, vừa khấu hao' END AS `Cách tính hao mòn`,
      fa.orgprice - COALESCE(fa.depreciation_for_business_price, 0) AS `Giá trị tính hao mòn`,
      fa.depreciation_for_business_price AS `Giá trị trích khấu hao`,
      cch.number_of_year AS `Số năm sử dụng cũ`,
      far.fixed_asset_revaluation_list ->> '$[0].old_data[0].remaining_number_of_year' AS `Số năm sử dụng còn lại cũ`,
      fa.number_of_year AS `Số năm sử dụng mới`,
      far.fixed_asset_revaluation_list ->> '$[0].new_data[0].remaining_number_of_year' AS `Số năm sử dụng còn lại mới`,
      far.fixed_asset_revaluation_list ->> '$[0].new_data[0].remaining_amount' AS `Giá trị còn lại`,
      SUM(IF(fal.voucher_type = 1, 1, 0)) AS `Ghi tăng`,
      SUM(IF(fal.voucher_type = 2, 1, 0)) AS `Đánh giá lại`,
      SUM(IF(fal.voucher_type = 4, 1, 0)) AS `Thay đổi thông tin`,
      SUM(IF(fal.voucher_type IN (3, 7), 1, 0)) AS `Điều chuyển`,
      SUM(IF(fal.voucher_type = 5, 1, 0)) AS `Tính hao mòn`,
      SUM(IF(fal.voucher_type = 9, 1, 0)) AS `Tính khấu hao`,
      SUM(IF(fli.voucher_type = 10, 1, 0)) AS `Kiểm kê`
    FROM fixed_asset fa
      INNER JOIN dic_organization do
        ON do.organization_id = $orgId
        AND fa.organization_id = $orgId
        AND fa.organization_id = do.organization_id
      INNER JOIN convert_circular_history cch
        ON cch.organization_id = $orgId
        AND fa.organization_id = $orgId
        AND fa.fixed_asset_id = cch.fixed_asset_id
        AND fa.organization_id = cch.organization_id
        AND cch.effect_year = 2023
      INNER JOIN convert_circular cc
        ON cch.convert_circular_id = cc.convert_circular_id
        AND cc.convert_circular_name = 'Thông tư 23'
        AND cc.effect_year = 2023
      INNER JOIN fixed_asset_revaluation far
        ON fa.organization_id = $orgId
        AND far.organization_id = $orgId
        AND cch.fixed_asset_revaluation_id = far.voucher_id
        AND fa.organization_id = far.organization_id
      LEFT JOIN fixed_asset_ledger fal
        ON fa.organization_id = $orgId
        AND fal.organization_id = $orgId
        AND fa.fixed_asset_id = fal.fixed_asset_id
        AND fa.organization_id = fal.organization_id
        AND YEAR(fal.change_date) = 2023
        AND fal.voucher_type IN (1, 2, 4, 7, 3, 5, 9)
      LEFT JOIN fa_ledger_inventory fli
        ON fa.organization_id = $orgId
        AND fli.organization_id = $orgId
        AND fa.fixed_asset_id = fli.fixed_asset_id
        AND fa.organization_id = fli.organization_id
        AND YEAR(fli.change_date) = 2023
        AND fli.voucher_type = 10
    GROUP BY fa.fixed_asset_id,
             do.organization_code,
             do.organization_name,
             fa.fixed_asset_code,
             fa.fixed_asset_name,
             fa.fixed_asset_category_name,
             `Cách tính hao mòn`,
             `Giá trị tính hao mòn`,
             `Giá trị trích khấu hao`,
             `Số năm sử dụng cũ`,
             `Số năm sử dụng còn lại cũ`,
             `Số năm sử dụng mới`,
             `Số năm sử dụng còn lại mới`,
             `Giá trị còn lại`;

END  ;

SELECT concat("CALL Proc_Jira_KhaoSat_ListUpdatedFaByConvertCircular('",fal.organization_id,"');") as Data 
FROM fixed_asset  fal
GROUP BY fal.organization_id
ORDER BY fal.organization_id;

CALL Proc_Jira_KhaoSat_ListUpdatedFaByConvertCircular('44db30fd-b15c-4eb7-b813-4d2bcfc2fdea');