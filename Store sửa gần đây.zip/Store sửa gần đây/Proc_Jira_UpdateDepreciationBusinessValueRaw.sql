﻿SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_UpdateDepreciationBusinessValueRaw;

CREATE PROCEDURE Proc_Jira_UpdateDepreciationBusinessValueRaw (IN $voucher_id varchar(36), IN $fixed_asset_id varchar(36), IN $depreciation_for_business_value decimal(19, 4))
SQL SECURITY INVOKER
BEGIN

    DECLARE $organ_id varchar(36);

    SELECT
        fa.organization_id INTO $organ_id
    FROM fixed_asset fa
    WHERE fa.fixed_asset_id = $fixed_asset_id LIMIT 1;

    UPDATE fixed_asset_depreciation_business_detail  A
    SET A.depreciation_for_business_value = $depreciation_for_business_value
    WHERE A.voucher_id = $voucher_id
    AND A.fixed_asset_id = $fixed_asset_id
    AND A.depreciation_for_business_value <> $depreciation_for_business_value;

    UPDATE fixed_asset_ledger A
    SET A.depreciation_for_business_value = $depreciation_for_business_value
    WHERE A.voucher_id = $voucher_id
    AND A.fixed_asset_id = $fixed_asset_id
    AND A.voucher_type = 9
    AND A.depreciation_for_business_value <> $depreciation_for_business_value;

    UPDATE fixed_asset_depreciation_business fad
    INNER JOIN (SELECT
            fadd.organization_id,
            fadd.voucher_id,
            SUM(ROUND(fadd.depreciation_for_business_value)) AS TotalMoney
        FROM fixed_asset_depreciation_business_detail fadd
        WHERE fadd.organization_id = $organ_id AND fadd.voucher_id = $voucher_id AND IFNULL(fadd.is_parent,0) = 0
        GROUP BY fadd.organization_id,
                 fadd.voucher_id) B
        ON B.organization_id = fad.organization_id
        AND B.voucher_id = fad.voucher_id
    SET fad.total_price = B.TotalMoney
    WHERE fad.organization_id = $organ_id AND fad.voucher_id = $voucher_id
    AND fad.total_price <> B.TotalMoney;

    CALL Proc_Jira_ReCallUpdateFAData($fixed_asset_id);

    DROP TEMPORARY TABLE IF EXISTS tblFaUpdateValue;

END ;

SELECT fadd.fixed_asset_code,  CONCAT("CALL Proc_Jira_UpdateDepreciationBusinessValueRaw('",fadd.voucher_id,"','",fadd.fixed_asset_id,"', ",fadd.depreciation_for_business_remaining_amount,");") as Data
FROM fixed_asset_depreciation_business_detail fadd
INNER JOIN fixed_asset fa ON fadd.organization_id = fa.organization_id and fadd.fixed_asset_id = fa.fixed_asset_id 
WHERE fa.convert_circular_id = 4 
AND fadd.organization_id = '289800af-cf21-4742-b5f8-d8bfdad2627a'
AND fadd.depreciation_for_business_remaining_amount < fadd.depreciation_for_business_value;

SELECT CONCAT("CALL Proc_Jira_Update_Revaluation_NewEqualOld_ByFA('",fal.voucher_id,"','",fal.fixed_asset_id,"');") as Data
FROM fixed_asset_ledger fal 
INNER JOIN fixed_asset_revaluation far on fal.organization_id = far.organization_id AND fal.voucher_id = far.voucher_id AND fal.fixed_asset_id = far.fixed_asset_id
WHERE fal.remaining_amount < 0 
and fal.voucher_type = 2
AND fal.convert_circular_id = 4
and fal.organization_id ='289800af-cf21-4742-b5f8-d8bfdad2627a';

SELECT fadd.fixed_asset_code,  CONCAT("CALL Proc_Jira_UpdateDepreciationValueRaw('",fadd.voucher_id,"','",fadd.fixed_asset_id,"', ",fadd.first_remaining_amount,");") as Data
FROM fixed_asset_depreciation_detail fadd
INNER JOIN fixed_asset fa ON fadd.organization_id = fa.organization_id and fadd.fixed_asset_id = fa.fixed_asset_id 
WHERE fa.convert_circular_id = 4 
AND fadd.organization_id = '289800af-cf21-4742-b5f8-d8bfdad2627a'
AND fadd.first_remaining_amount < fadd.depreciation_value;

update fixed_asset fa
INNER JOIN(
    SELECT organization_id, fixed_asset_id, depreciation_amount, accum_depreciation_amount, depreciation_for_business_amount,remaining_amount, 
    ROW_NUMBER() OVER(PARTITION BY fixed_asset_id ORDER BY fal.change_date DESC, fal.created_date DESC, fal.fixed_asset_ledger_id DESC) rn
    FROM fixed_asset_ledger fal
    WHERE fal.voucher_type <> 17 AND fal.organization_id = 'bdea6b62-8d3b-404f-b4d8-722b5e72aa01'
) tm ON fa.organization_id = tm.organization_id AND fa.fixed_asset_id = tm.fixed_asset_id AND tm.rn = 1
set 
fa.depreciation_amount = IF(fa.fixed_asset_type = 2, 0, ifnull(tm.depreciation_amount,0)),
fa.accum_depreciation_amount = ifnull(tm.accum_depreciation_amount,0),
fa.depreciation_for_business_amount = IF(fa.fixed_asset_type = 1, 0, ifnull(tm.depreciation_for_business_amount,0)),
fa.remaining_amount = ifnull(tm.remaining_amount,0)
WHERE IFNULL(fa.remaining_amount, 0) <> IFNULL(tm.remaining_amount, 0) and ifnull(fa.is_parent, 0) = 0;

SELECT * FROM fixed_asset fa WHERE fa.fixed_asset_id = '81cec0dd-bd08-41ac-a6f8-e64cae52635a';
SELECT * FROM fixed_asset fa WHERE fa.fixed_asset_id = '8820e0f3-3c28-47c1-a35d-2e3810ce081d';

SELECT fa.fixed_asset_id 
FROM fixed_asset fa
WHERE 
IFNULL(fa.is_parent,0)= 0 
AND fa.remaining_amount < 0;
-- âm giá trị còn lại 4339
-- có lịch sử hao mòn nhưng mất trong detail 97782

SELECT A.fixed_asset_id 
FROM 
(
    SELECT fal.organization_id, fal.voucher_id, fal.fixed_asset_id FROM fixed_asset_ledger fal WHERE fal.voucher_type = 5
) A  LEFT JOIN  fixed_asset_depreciation_detail fadd  ON A.organization_id = fadd.organization_id AND A.voucher_id = fadd.voucher_id AND A.fixed_asset_id = fadd.fixed_asset_id
WHERE fadd.fixed_asset_id IS NULL;


SELECT * FROM user u WHERE u.organization_code = '1049893';

UPDATE user u 
set u.status = 1 
WHERE u.status = 2;
