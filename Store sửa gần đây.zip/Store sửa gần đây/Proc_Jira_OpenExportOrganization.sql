﻿SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_OpenExportOrganization;

CREATE PROCEDURE Proc_Jira_OpenExportOrganization (IN $organization_code varchar(100), IN $isOpen int)
SQL SECURITY INVOKER
BEGIN
  DECLARE $i int DEFAULT 0;
  DECLARE $count int DEFAULT 0;
  DECLARE $organID varchar(36) DEFAULT '';

  SET $organID = (select organization_id from dic_organization where organization_code = $organization_code LIMIT 1);

  DELETE FROM db_option WHERE organization_id = $organID AND option_id = 'IsExportFixedAsset';

  INSERT INTO db_option (user_id, option_id, option_value, value_type, is_system, description, is_branch, is_user_option, organization_id, modified_date, is_data_convert, created_date, created_by, modified_by) VALUES
  (NULL, 'IsExportFixedAsset', IF($isOpen = 1,'1','0'), 1, False, 'Cho phép đơn vị có sử dụng tính năng xuất khẩu', True, FALSE, $organID, NOW(), False, NOW(), NULL, NULL);

END;

CALL Proc_Jira_OpenExportOrganization('1008116', 0);