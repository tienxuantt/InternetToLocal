﻿SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_UpdateCustomOrgan;

CREATE PROCEDURE Proc_Jira_UpdateCustomOrgan (IN $maxFA int)
SQL SECURITY INVOKER
BEGIN
    DECLARE $i int DEFAULT 0;
    DECLARE $count int DEFAULT 0;
    DECLARE $FaID varchar(36) DEFAULT '';
    DECLARE $fixedAssetCode varchar(100) DEFAULT '';
    DECLARE $orgprice decimal(19,4) DEFAULT 0;
    DECLARE $accum decimal(19,4) DEFAULT 0;

    DROP TEMPORARY TABLE IF EXISTS tbOrganization;
    CREATE TEMPORARY TABLE tbOrganization
    SELECT A1.fixed_asset_id
    FROM fa_jira_execute A1
    WHERE A1.type = 0
    LIMIT $maxFA;

    UPDATE fa_jira_execute fje
    INNER JOIN tbOrganization o ON fje.fixed_asset_id = o.fixed_asset_id
    set fje.type = 1;
                                 
    SELECT
        COUNT(1) INTO $count
    FROM tbOrganization;

    WHILE $i < $count DO
        SELECT  fixed_asset_id INTO $FaID
        FROM tbOrganization
        LIMIT $i, 1;

            CALL Proc_Jira_ReCallUpdateFAData($FaID);

        SET $i = $i + 1;
    END WHILE;

    DROP TEMPORARY TABLE IF EXISTS tbOrganization;

END;