﻿SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_ResetData_CCDC_ByOrganID;

CREATE PROCEDURE Proc_ResetData_CCDC_ByOrganID (IN $OrganID varchar(36))
COMMENT 'Store xóa dữ liệu của một đơn vị'
BEGIN

    DELETE
        FROM eq_document_member
    WHERE organization_id = $OrganID;
    DELETE
        FROM eq_scanner_inventory
    WHERE organization_id = $OrganID;
    DELETE
        FROM equipment
    WHERE organization_id = $OrganID;
    DELETE
        FROM equipment_decrement
    WHERE organization_id = $OrganID;
    DELETE
        FROM equipment_decrement_detail
    WHERE organization_id = $OrganID;
    DELETE
        FROM equipment_distribution
    WHERE organization_id = $OrganID;
    DELETE
        FROM equipment_distribution_detail
    WHERE organization_id = $OrganID;
    DELETE
        FROM equipment_increment
    WHERE organization_id = $OrganID;
    DELETE
        FROM equipment_increment_detail
    WHERE organization_id = $OrganID;
    DELETE
        FROM equipment_inventory
    WHERE organization_id = $OrganID;
    DELETE
        FROM equipment_ledger
    WHERE organization_id = $OrganID;
    DELETE
        FROM equipment_ledger_change_info
    WHERE organization_id = $OrganID;
    DELETE
        FROM equipment_ledger_increment_and_decrement
    WHERE organization_id = $OrganID;
    DELETE
        FROM equipment_ledger_inventory
    WHERE organization_id = $OrganID;
    DELETE
        FROM equipment_ledger_search
    WHERE organization_id = $OrganID;
    DELETE
        FROM equipment_transfer
    WHERE organization_id = $OrganID;
    DELETE
        FROM equipment_transfer_detail
    WHERE organization_id = $OrganID;  
    DELETE
        FROM rpt_accounting_eq_inventory
    WHERE organization_id = $OrganID;
    DELETE
        FROM rpt_accounting_eq_inventory_department
    WHERE organization_id = $OrganID;
    DELETE
        FROM rpt_accounting_eq_inventory_sumbycategory
    WHERE organization_id = $OrganID;
    DELETE
        FROM rpt_accounting_s32h_equipment
    WHERE organization_id = $OrganID;
    DELETE
        FROM rpt_equipment_summary_nb
    WHERE organization_id = $OrganID;
                      
END;