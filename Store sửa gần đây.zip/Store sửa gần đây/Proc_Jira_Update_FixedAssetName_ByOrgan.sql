﻿SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_Update_FixedAssetName_ByOrgan;

CREATE PROCEDURE Proc_Jira_Update_FixedAssetName_ByOrgan (IN $organization_id varchar(36))
SQL SECURITY INVOKER
BEGIN
  
        UPDATE fixed_asset_ledger fal
        INNER JOIN fixed_asset fa ON fal.organization_id = fa.organization_id AND fal.fixed_asset_id = fa.fixed_asset_id
        set fal.fixed_asset_name = fa.fixed_asset_name
        WHERE fal.organization_id = $organization_id AND IFNULL(fal.fixed_asset_name, '') = '';
        
        UPDATE fa_ledger_inventory fal
        INNER JOIN fixed_asset fa ON fal.organization_id = fa.organization_id AND fal.fixed_asset_id = fa.fixed_asset_id
        set fal.fixed_asset_name = fa.fixed_asset_name
        WHERE fal.organization_id = $organization_id AND IFNULL(fal.fixed_asset_name, '') = '';

END;

SELECT concat("CALL Proc_Jira_Update_FixedAssetName_ByOrgan('",fal.organization_id,"');") as Data 
FROM fixed_asset  fal
GROUP BY fal.organization_id;
