﻿SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_Update_OrgpriceOther_ByOrgan;

CREATE PROCEDURE Proc_Jira_Update_OrgpriceOther_ByOrgan (IN $organization_id varchar(36))
SQL SECURITY INVOKER
BEGIN
  
        UPDATE fixed_asset_ledger fal
        set fal.orgprice_from_budget = IFNULL(fal.orgprice,0) - IFNULL(fal.orgprice_from_other, 0)
        WHERE fal.organization_id = $organization_id AND  IFNULL(fal.orgprice_from_budget,0) + IFNULL(fal.orgprice_from_other, 0)  <> IFNULL(fal.orgprice,0);

       UPDATE fixed_asset fal
        set fal.orgprice_from_budget = IFNULL(fal.orgprice,0) - IFNULL(fal.orgprice_from_other, 0)
        WHERE fal.organization_id = $organization_id AND  IFNULL(fal.orgprice_from_budget,0) + IFNULL(fal.orgprice_from_other, 0)  <> IFNULL(fal.orgprice,0);

END;

SELECT concat("CALL Proc_Jira_Update_OrgpriceOther_ByOrgan('",fal.organization_id,"');") as Data 
FROM fixed_asset_ledger  fal
WHERE  IFNULL(fal.orgprice_from_budget,0) + IFNULL(fal.orgprice_from_other, 0)  <> IFNULL(fal.orgprice,0)
GROUP BY fal.organization_id;

UPDATE fixed_asset_ledger fal
set fal.orgprice_from_other = 0
WHERE fal.organization_id = $organization_id AND  IFNULL(fal.orgprice,0) = IFNULL(fal.orgprice_from_budget, 0) ;

UPDATE fixed_asset fal
set fal.orgprice_from_other = 0
WHERE fal.organization_id = $organization_id AND  IFNULL(fal.orgprice,0) = IFNULL(fal.orgprice_from_budget, 0) ;

UPDATE fixed_asset_ledger fal
set fal.orgprice_from_budget = IFNULL(fal.orgprice,0)
WHERE fal.organization_id = $organization_id AND  IFNULL(fal.orgprice_from_budget,0) = IFNULL(fal.orgprice_from_other, 0) AND IFNULL(fal.orgprice_from_budget,0) = 0 ;

UPDATE fixed_asset fal
set fal.orgprice_from_budget = IFNULL(fal.orgprice,0)
WHERE fal.organization_id = $organization_id AND   IFNULL(fal.orgprice_from_budget,0) = IFNULL(fal.orgprice_from_other, 0) AND IFNULL(fal.orgprice_from_budget,0) = 0 ;

UPDATE fixed_asset_ledger fal
set fal.orgprice_from_budget = IFNULL(fal.orgprice,0),  fal.orgprice_from_other = 0
WHERE fal.organization_id = $organization_id AND  IFNULL(fal.orgprice_from_budget,0) + IFNULL(fal.orgprice_from_other, 0)  > IFNULL(fal.orgprice,0);

UPDATE fixed_asset fal
set fal.orgprice_from_budget = IFNULL(fal.orgprice,0),  fal.orgprice_from_other = 0
WHERE fal.organization_id = $organization_id AND  IFNULL(fal.orgprice_from_budget,0) + IFNULL(fal.orgprice_from_other, 0)  > IFNULL(fal.orgprice,0);