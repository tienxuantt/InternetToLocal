﻿SET NAMES 'utf8';
DROP PROCEDURE IF EXISTS Proc_Jira_Update_DepreciationValueLedgerEqualDetail;

CREATE PROCEDURE Proc_Jira_Update_DepreciationValueLedgerEqualDetail ()
BEGIN

        DELETE FROM jira_fixed_asset_survey;

        DROP TEMPORARY TABLE IF EXISTS tbFixedAssetError;
        CREATE TEMPORARY TABLE tbFixedAssetError
        SELECT  fadd.fixed_asset_id 
        FROM fixed_asset_ledger fal
        INNER JOIN fixed_asset_depreciation_detail fadd on fal.organization_id = fadd.organization_id and fal.voucher_id = fadd.voucher_id AND fal.fixed_asset_id = fadd.fixed_asset_id
        WHERE ifnull(fal.depreciation_value,0) <> ifnull(fadd.depreciation_value,0) AND fal.voucher_type = 5
        GROUP BY fadd.fixed_asset_id;

        INSERT jira_fixed_asset_survey (fixed_asset_id)
        SELECT fixed_asset_id 
        FROM tbFixedAssetError;

        UPDATE fixed_asset_ledger fal
        INNER JOIN fixed_asset_depreciation_detail fadd on fal.organization_id = fadd.organization_id and fal.voucher_id = fadd.voucher_id AND fal.fixed_asset_id = fadd.fixed_asset_id
        INNER JOIN tbFixedAssetError B ON fal.fixed_asset_id = B.fixed_asset_id
        set fal.depreciation_value = ifnull(fadd.depreciation_value,0)
        WHERE ifnull(fal.depreciation_value,0) <> ifnull(fadd.depreciation_value,0);

        DROP TEMPORARY TABLE IF EXISTS tbFixedAssetError;

END;