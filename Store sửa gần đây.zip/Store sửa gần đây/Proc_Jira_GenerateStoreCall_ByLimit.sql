﻿SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_GenerateStoreCall_ByLimit;

CREATE PROCEDURE Proc_Jira_GenerateStoreCall_ByLimit (IN $StoreCall varchar(200), IN $NumberFA int)
SQL SECURITY INVOKER
BEGIN
  DECLARE $CountOrgan int DEFAULT 0;
  DECLARE $CountLoop int DEFAULT 0;
  DECLARE $i int DEFAULT 1;
  DECLARE $circular_id int DEFAULT 1;

  -- Lấy ra thông tư mới nhất
  SELECT max(convert_circular_id) INTO $circular_id  FROM convert_circular cc;

    SELECT
      COUNT(1) INTO $CountOrgan
    FROM fixed_asset fa
    WHERE fa.convert_circular_id = $circular_id AND fa.status_id <> 2 and IFNULL(fa.is_parent,0) = 0;

   set $CountLoop = ($CountOrgan /  $NumberFA) + 1;

   SELECT  $StoreCall AS Data
   FROM fixed_asset fa 
   LIMIT  $CountLoop;

END;

CALL Proc_Jira_GenerateStoreCall_ByLimit('CALL Proc_Jira_KS_RemainingNumberOfYear_ByLimit(300, 0);',  300);

SELECT COUNT(*) FROM fixed_asset fa;

SELECT * FROM convert_circular_history cch WHERE cch.convert_circular_id = 5 ORDER BY cch.created_date LIMIT 10;

SELECT * FROM convert_circular cc