// Thêm mới một tài sản
function addFixedAsset(obj){
    // Binding dữ liệu vào form
    bindingDataForm(obj);
}

//xóa tài sản vừa nhập
function deleteFixedAsset(obj){ 
    xoaTaiSanVuaNhap(obj.idTS);
}
// Show form
function showFormAdd(obj){
    goToLink(obj.isTangMoi, obj.DataType, false, obj.isTSQL);
}

function ajaxGet(dataURL, async) {
    return $.ajax({
        url: dataURL,
        type: "GET",
        async: async === undefined ? false : async,
    });
}

function xoaTaiSanVuaNhap(idTS) {
    var url = "/TaiSan/DeleteTaiSan?id=" + idTS;

    var taiSanDelete = ajaxGet(url);

    taiSanDelete.done(function () {
        
        let json = {
            message : "deleteSuccess"
        }
        pushNofity(JSON.stringify(json));

        setTimeout(function(){
            window.location.reload();
        }, 1000);

    }).fail(function () {
        console.error("Xóa tài sản không thành công thành công");
    });
}

//Kiểm tra thêm mới
function checkAddSuccess(name){
    if(window.location.pathname.includes("/TaiSan/List")) {
        setTimeout(function(){
            try 
            {
                var deleteEvent = $(`tr:contains(${name.substring(0, name.length - 1)})`).find('[title="Xóa"]').attr("onClick"),
                id = deleteEvent.replace(/^\D+|\D.*$/g, "");
                if(id) {
                    let json = {
                        message : "addSuccess",
                        idTS: id
                    };
                    pushNofity(JSON.stringify(json));
                } else {
                    let json = {
                        message : "addFail"
                    };
                    pushNofity(JSON.stringify(json));
                }
            }
            catch
            {
                let json = {
                    message : "addFail"
                };
                pushNofity(JSON.stringify(json));
            }
        },7000)
    } else {
        let json = {
            message : "addFail"
        };
        pushNofity(JSON.stringify(json));
    }
}

// Điều hướng tới trang thêm mới
function goToLink(isTangMoi, _loaiHinh, _isCreateTSDA, _isTSQL) {
    try {
        let _url = `/TaiSan/Create?LoaiHinhTSId=${_loaiHinh}&loailydobiendongId=1&isTangMoi=${isTangMoi}&isCreateTSDA=False&isTSQL=${_isTSQL}`;

        window.location.replace(_url);
    } catch (error) {
        console.error("Đã có lỗi xảy ra. Vui lòng nhấn F5");
    }
}

// Xử lý binding dữ liệu form
async function bindingDataForm(obj){
    try {
        if(obj){
            let columnConfig = obj.ColumnConfig,
                data = obj.Data,
                itemGTCL = {};
            
            const index = columnConfig.findIndex(item => item.Field_QLTS === 'Gia_tri_con_lai');
	    
    	    if (index !== -1) {
              // If 'Gia_tri_con_lai' is found, move it to the end of the array
      	      const itemToMove = columnConfig.splice(index, 1)[0];
              columnConfig.push(itemToMove);
    	    }
                
            // Duyệt từng control để binding
            if(columnConfig && columnConfig.length > 0){
                columnConfig.filter(function(item){
                    
                    switch(item.ControlType){
                        case 1: // String
                            bindingControlString(item, data);
                            break;
                        case 2: // Number
                            if(item.Field_QLTS == 'Gia_tri_con_lai'){
                                itemGTCL = item;
                                setTimeout(() => {	
                                   bindingControlNumber(item, data)
                                }, 1000);
                            }
                            else bindingControlNumber(item, data);
                            break;
                        case 3: // DateTime
                            bindingControlDateTime(item, data);
                            break;
                        case 4: // Combobox
                            bindingControlCombobox(item, data);
                            break;
                        case 5:
                            bindingControlRadio(item, data);
                            break;
                        case 6: // Checkbox
                            bindingControlCheckbox(item, data);
                            break;
                    }
                });
                
                
                if(data.Tinh_Thanh_pho){
                    await bindingProvince(columnConfig, data);
                }
                
                // Tự động bấm lưu
                setTimeout(function(){
                    //bindingControlNumber(itemGTCL, data);
                    $(".card-header .btnAdd:first").click();

                    setTimeout(function(){
                        
                        if($(`[data-bb-handler="confirm"]`).is(":visible")){
                            $(`[data-bb-handler="confirm"]`).click();
                            let json = {
                                message: "bindingSuccess",
                                name: data.Ten_tai_san
                            }
                            pushNofity(JSON.stringify(json));
                            
                        } else if($(`[data-bb-handler="fee"]`).is(":visible")){
                            $(`[data-bb-handler="fee"]`).click();
                            let json = {
                                message: "bindingSuccess",
                                name: data.Ten_tai_san
                            }
                            pushNofity(JSON.stringify(json));
                            
                        } else {
                            let json = {
                                message : "addFail"
                            };
                            pushNofity(JSON.stringify(json));
                        }
                    }, 600);
                    
                }, 1800);
            }
        }
    } catch (error) {
        console.error("Đã có lỗi binding xảy ra. Vui lòng nhấn F5");
    }
}

// Gửi lên để lấy tài sản tiếp theo
function pushNofity(message){
    try {
        chrome.runtime.sendMessage(message, (response) => {});
    } catch (error) {
        console.error("Đã có lỗi push xảy ra. Vui lòng nhấn F5");
    }
}

// Xử lý binding control String
function bindingControlString(config, data){
    try {
        let control = $(`#${config.Field_TSC}`);

        if(control && control.length > 0){
            let value = data[config.Field_QLTS];

            if(value){
                
                control[0].focus();
                document.execCommand('insertText', false, value );
                control[0].dispatchEvent(new Event('blur', {bubbles: true}));
            }
        }
    } catch (error) {
        console.error("Đã có lỗi binding string xảy ra. Vui lòng nhấn F5");
    }
}

// Xử lý binding control Number
function bindingControlNumber(config, data){
    try {
        let control = $(`#${config.Field_TSC}`);

        if(control && control.length > 0){
            let value = data[config.Field_QLTS];

            if(typeof value === 'number'){
                let valueFormat = value.toString().replace(/(\d)(?=(\d{3})+(?:\.\d+)?$)/g, "$1.");
                control.val(value);
                control.prev().val(valueFormat);
                control.attr("aria-valuenow", value);
                control.prev().attr("aria-valuenow", value);
                control.prev().attr("title", valueFormat+" ₫");
            }
        }
    } catch (error) {
        console.error("Đã có lỗi binding number xảy ra. Vui lòng nhấn F5");
    }
}

// Xử lý binding control Combobox
function bindingControlCombobox(config, data){
    try {
        let control = $(`ul#${config.Field_TSC}`);            
        if(control && control.length > 0){
            let value = data[config.Field_QLTS];        
            if(value){
                control.find("li").each(function(){
                    let spanText = $(this).text();

                    if(spanText.toLocaleLowerCase().trim().includes(value.toLocaleLowerCase().trim())){
                        $(this).click();
                    }
                });
            }
        }
    } catch (error) {
        console.error("Đã có lỗi binding combobox xảy ra. Vui lòng nhấn F5");
    }
}

// Xử lý binding control DateTime
function bindingControlDateTime(config, data){
    try {
        let control = $(`#${config.Field_TSC}`);

        if(control && control.length > 0){
            let value = data[config.Field_QLTS];
            value = value.split('T')[0];
            if(value){
                control.val(value);
            }
        }
    } catch (error) {
        console.error("Đã có lỗi binding datetime xảy ra. Vui lòng nhấn F5");
    }
}

// Xử lý binding control Checkbox
function bindingControlCheckbox(config, data){
    try {
        let isClick = data[config.Field_QLTS],
            control = $(`#${config.Field_TSC}`);

        if(control && control.length > 0 && !control.prop("checked")){
            if(isClick) {
                control.click();
            }
        }
    } catch (error) {
        console.error("Đã có lỗi binding checkbox xảy ra. Vui lòng nhấn F5");
    }
}

// Xử lý binding control radio
function bindingControlRadio(config, data){
    try {
        let isClick = data[config.Field_QLTS],
            control = $(`[name="${config.Field_TSC}"]:${isClick ? 'first':'last' }`);

        if(control && control.length > 0 && !control.prop("checked")){
            control.click();
        }
    } catch (error) {
        console.error("Đã có lỗi binding radio xảy ra. Vui lòng nhấn F5");
    }
}

//xử lý trường hợp có thông tin tỉnh, thành phố
bindingProvince = async (columnConfig, data) => {
    //bindingControlCombobox(config, data);   
    let url = "https://qltsc.mof.gov.vn/TaiSan/GetDataSource";
    const response1 = await fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
            },
        body: JSON.stringify({
            CapDiaBan: 2,
            str: "-- Chọn quận/huyện --"
        }),            
    });
    if(response1){
        columnConfig.filter(async (item) => {
            if(item.Field_QLTS == "Quan_Huyen"){                    
                bindingControlCombobox(item, data);     
                
            }
        })
    }

    const response = await fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            CapDiaBan: 3,
            str: "-- Chọn xã/phường --"
        }),            
    });
    if(response){
        columnConfig.filter(item => {
            if(item.Field_QLTS == "Xa_Phuong"){
                bindingControlCombobox(item, data);
            }
        }) 
    }
            
}
