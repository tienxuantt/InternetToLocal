// Tự động thêm các bản ghi
var autoAdd = true;
// Index của bản ghi hiện tại đang thực thi
var indexActive = 0;

// Xử lý khi mới mở form
getData(function (data) {
    if (data) {
        afterImportFile(data);
    }
});

// Khởi tạo sự kiện tự động nhập liệu kế tiếp
$("#autoAdd").change(function () {
    autoAdd = this.checked;
});

// Nhập khẩu file
$("#importLink").on("click", function () {
    $("#importJson").click();
});

// Sự kiện khi thay đổi
$("#importJson").on('change', function (e) {
    var file = e.target.files[0];
    var path = (window.URL || window.webkitURL).createObjectURL(file);
    console.log(file.type);
    if(file.type.includes("json")) {
      readTextFile(path, function (text) {
          try {
              var data = JSON.parse(text);
              setData(data, afterImportFile);
              $(".notification").css("display", "none");
          } catch (error) {
              alert("File dữ liệu không hợp lệ!");
          }
      });
    } else {
      showNotification();
    }
});

// Sự kiện khi kéo file
$('.container-fluid').on('drop', function(e) {
  e.preventDefault();
  var file = event.dataTransfer.files[0];
  
  var path = (window.URL || window.webkitURL).createObjectURL(file);
  if(file.type.includes("json")){
    readTextFile(path, function (text) {
        try {
            var data = JSON.parse(text);
            setData(data, afterImportFile);
            $(".notification").css("display", "none");
        } catch (error) {
            alert("File dữ liệu không hợp lệ!");
        }
    });
  } else {
    showNotification();
  }
  $('.container-fluid').removeClass('dropfile')
  
})

$('#QLTS_Extension').on('dragover', function(e) {
  e.preventDefault();
  $('.container-fluid').addClass('dropfile');
})

$('#QLTS_Extension').on('dragleave', function(e) {
  $('.container-fluid').removeClass('dropfile')
})

//Hiện thông báo sai file
function showNotification() {
  $(".notification").empty();
  let html='<img src="icon-16.png"></div><div>MISA QLTS-Input không thể nhập file</div>';
  $(".notification").css("display", "flex");
  $(".notification").append(html);
};


// Đọc nội dung file json
function readTextFile(file, callback) {
    var rawFile = new XMLHttpRequest();

    rawFile.overrideMimeType("application/json");
    rawFile.open("GET", file, true);
    rawFile.onreadystatechange = function () {
        if (rawFile.readyState === 4 && rawFile.status == "200") {
            callback(rawFile.responseText);
        }
    }

    rawFile.send(null);
}

// Chuẩn bị dữ liệu trước khi binding
function prepareData(obj) {
    addFixedAsset(obj);
}

// Mở form thêm mới
function openFormAdd(obj) {
    showFormAdd(obj);
}

// Chạy câu lệnh xóa
function runDeleteEvent(obj) {
  deleteFixedAsset(obj);
}

function checkWeb(name) {
  checkAddSuccess(name);
}

// Gọi tới bản ghi tiếp theo
function executeNextData() {
    setTimeout(function () {
        if (autoAdd) {
            $(".item-title:not(.success, .error):first").next().click();
        }
    }, 1000);
}

// Cập nhật trạng thái sau khi thành công
function updateStatusAddSuccess(idTS) {
  
  getData(function (data) {
    if (data && data.Data) {
      data.Data[indexActive].success = true;
      data.Data[indexActive].error = false;
      data.Data[indexActive].idTS = idTS;

      setData(data, (response) => {
          afterImportFile(response);

          // Gọi tới bản ghi tiếp theo
          executeNextData();
      });
    }
  });
} 

function updateStatusAddFail() {
  
  getData(function (data) {
    if (data && data.Data) {
      data.Data[indexActive].success = false;
      data.Data[indexActive].error = true;

      setData(data, (response) => {
          afterImportFile(response);

          // Gọi tới bản ghi tiếp theo
          executeNextData();
      });
    }
  });
} 

// Cập nhật trạng thái sau khi thành công
function updateStatusDeleteSuccess() {
  
  getData(function (data) {
    if (data && data.Data) {
      data.Data[indexActive].success = false;
      data.Data[indexActive].error = false;
      data.Data[indexActive].idTS = null;

      setData(data, (response) => {
          afterImportFile(response);
      });
    }
  });
} 

    
// Xử lý khi nhận được thông báo thành công
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    let json = JSON.parse(message);

    if (json.message === 'bindingSuccess') {
      setTimeout(function () {
        sendDataToWeb(json.name, checkWeb)
      }, 8000);
    } else if(json.message === 'addSuccess') {
      updateStatusAddSuccess(json.idTS);
    } else if(json.message === 'deleteSuccess') {
      updateStatusDeleteSuccess();
    } else if(json.message === 'addFail') {
      updateStatusAddFail();
    }
});

// Thêm mới một tài sản
function addFixedAssetByIndex(index) {
    // Lấy dữ liệu để binding
    getData(function (data) {
        if (data && data.Data) {
            let
                dataAsset = data.Data[index],
                dataAssetType = dataAsset.Loai_Hinh_Tai_San_Id,
                dataAssetName = '';
                for (let x in data.AssetTypeConfig) {
                  if(data.AssetTypeConfig[x] == dataAssetType)
                    dataAssetName = x;
                }
            	
            let
                valueDate = dataAsset["Ngay_tang"].split('T')[0],
                isTangMoi = new Date(valueDate) > new Date('2017-12-31') ? true : false,
                isTSQL = dataAsset["Nguyen_gia"] < 10000000 ? true: false,
                obj = {
                    Data: dataAsset,
                    isTangMoi: isTangMoi,
                    DataType: dataAssetType,
                    ColumnConfig: data.ColumnConfig[dataAssetName],
                    isTSQL: isTSQL,
                };
                
            if (obj) {
                // Mở form
                sendDataToWeb(obj, openFormAdd);

                // Truyền dữ liệu
                setTimeout(function () {
                    sendDataToWeb(obj, prepareData);
                }, 8000);
            }
        }
    });
}

function deleteFixedAssetByIndex(index) {
  getData(function (data) {
    if (data && data.Data) {
      let dataAsset = data.Data[index],
          idTS = dataAsset.idTS,
          obj = {
            idTS: idTS
          };
        if (obj) {
          sendDataToWeb(obj, runDeleteEvent);
        }
      }
  });
}

// Khởi tạo sự kiện khi click vào nhập
$(".list-item").on("click", ".action", function () {
    let index = $(this).parent().attr("index");

    // Lưu lại index đang thao tác
    indexActive = index;

    addFixedAssetByIndex(index);
});

// Khởi tạo sự kiện khi click vào nhập
$(".list-item").on("click", ".delete", function () {
    let index = $(this).parent().attr("index");

    // Lưu lại index đang thao tác
    indexActive = index;

    deleteFixedAssetByIndex(index);
    
});

// Xử lý sau khi import file
function afterImportFile(data) {
    let totalRecords = data.Data.length;

    $(".total-record").find("b").text(totalRecords);
    $(".main-content").show();

    // Render dữ liệu
    renderListData(data);
}

/**
* Xử lý render dữ liệu nhập khẩu
*/
function renderListData(data) {
    if (data && data.Data) {
        $(".list-item").empty();

        data.Data.filter(function (item, index) {
            let itemChild = `<div class="item-detail" index='${index}'>
                            <div class="item-title ${item.success ? 'success' : ''} ${item.error ? 'error' : ''}">${item.Ten_tai_san}</div>
                            <div class="action ${item.success ? 'success' : ''} ">Nhập</div>
                            <div class="delete ${item.success ? 'success' : ''} ">Xóa TS</div>
                            </div>`;

            $(".list-item").append(itemChild);
        });
    }
}

